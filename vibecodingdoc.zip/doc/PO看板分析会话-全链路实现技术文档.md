# PO 看板分析会话 全链路实现技术文档

> 面向 PO agent「看板分析」Tab：点击即跳转到最新一次 `po-dashboard-analysis` 分析会话并回放其历史输出；画像看板点「刷新」即重跑一次分析。本文档汇总该特性从会话建模、隐形会话过滤、三道加载拦截豁免到后端历史回放的完整实现链路，供后续同类「隐形会话回放后端历史」改造复用。

## 1. 需求与设计约束

- PO agent 界面左半区为看板面板（供应商画像 / 履约追踪），右半区为「对话 / 看板分析」双 Tab。
- 「看板分析」Tab 展示对 `Suppliers.md` 的结构化分析结果（调用 `po-dashboard-analysis` 技能），对用户隐藏触发提示词。
- 「刷新即重跑」：画像看板刷新按钮触发新一轮分析，覆盖旧结果；看板分析 Tab 本身不再提供「重新分析」按钮。

### 关键底层约束

1. **ACP 后端 `loadSession` 对已存在 key 是「追加」语义**，且没有清空 / 删除 transcript 的 API。因此「刷新后覆盖旧分析」只能通过**每次新建带时间戳的会话 key** 来模拟：`agent:po:dashboard-<Date.now()>`，旧 key 成为不再展示的孤儿会话。
2. **看板分析会话与对话会话共享全局单例** `useAcpChatSessionStore`，切 Tab 即切换 `activeSessionKey`。
3. **看板分析会话是「隐形会话」**：不进侧栏列表，chat store 的 `sessions` 数组据此过滤，因此**无法用 `sessions` 判断「有无历史」**。

## 2. 核心数据模型：会话 key 与隐形会话

### 2.1 会话 key 约定（[`po-dashboard-analysis.ts`](../ClawX/src/stores/po-dashboard-analysis.ts:29)）

```ts
export const PO_DASHBOARD_SESSION_PREFIX = 'agent:po:dashboard-';
export function isPoDashboardSessionKey(key: string): boolean {
  return key.startsWith(PO_DASHBOARD_SESSION_PREFIX);
}
export function createPoDashboardSessionKey(): string {
  return `${PO_DASHBOARD_SESSION_PREFIX}${Date.now()}`;
}
```

- 前缀识别 + 末尾时间戳排序，是「最新一个会话」判定的唯一依据。

### 2.2 侧栏过滤（[`session-key-utils.ts`](../ClawX/src/stores/chat/session-key-utils.ts:73)）

`shouldIncludeSessionInSidebarList` 中对 dashboard key 直接 `return false`，使其成为隐形会话：

```ts
if (isPoDashboardSessionKey(session.key)) return false;
```

### 2.3 选中修复豁免（[`chat.ts` `repairMissingCurrentSelection`](../ClawX/src/stores/chat.ts:353)）

因隐形会话永不出现在 `sessions` 数组，通用「当前选中不在列表即 fallback」逻辑会把看板分析 Tab 踢回对话 Tab。故对 dashboard key 豁免，保持选中。

## 3. 状态控制器：`usePoDashboardAnalysisStore`

文件 [`po-dashboard-analysis.ts`](../ClawX/src/stores/po-dashboard-analysis.ts:66)。用 `persist` 中间件持久化，只持久化 `sessionKey`。

| 字段 / 方法 | 作用 |
| --- | --- |
| `sessionKey: string \| null` | 当前看板分析会话 key；`null`＝无历史（需首次触发） |
| `refreshSignal: number` | 非持久化；画像刷新按钮自增，Chat 页监听以重跑 |
| `startNewSession()` | 新建时间戳 key 置为当前并返回 |
| `requestRefresh()` | 自增 `refreshSignal` |
| `discoverLatestDashboardSessionKey()` | 调 gateway `sessions.list` RPC 以**后端真实会话为准**发现最新 dashboard 会话 |

### 3.1 后端会话发现（关键：解决前端持久化 key 与后端不同步）

前端持久化的单一 `sessionKey` 在清缓存 / 多设备 / 多次分析后会与后端实际不同步，导致「有历史却显示空态」。`discoverLatestDashboardSessionKey` 直接查后端：

```ts
const data = await useGatewayStore.getState()
  .rpc('sessions.list', { includeDerivedTitles: false, includeLastMessage: false });
// 遍历 data.sessions（含被侧栏过滤的 dashboard 会话），筛 isPoDashboardSessionKey，
// 按末尾时间戳取最大者写回 store.sessionKey。
```

> 注意：`sessions.list` RPC 返回的是**后端全量**会话（含被侧栏过滤者），与前端 `sessions` 数组不同，这是能发现隐形会话的前提。

## 4. Chat 页接线（[`index.tsx`](../ClawX/src/pages/Chat/index.tsx:653)）

### 4.1 视图派生与触发

- `poRightTab` 由 `currentSessionKey` 是否命中 dashboard key 派生，视图与全局会话天然一致。
- `triggerPoDashboardAnalysis()`（[:671](../ClawX/src/pages/Chat/index.tsx:671)）：`startNewSession` 新 key → 占用 in-flight 锁 → `selectAcpSession` → `runAcpPrompt(createIfMissing:true)` 发送隐藏提示词。
- `handleSelectPoRightTab('dashboard')`（[:685](../ClawX/src/pages/Chat/index.tsx:685)）：先用前端持久化 key 立即加载兜底，再 `await discoverLatestDashboardSessionKey()` 校正；后端确实无会话才触发首次分析。
- 刷新监听（[:725](../ClawX/src/pages/Chat/index.tsx:725)）：`refreshSignal` 变化 → `triggerPoDashboardAnalysis()`。
- 空态展示（[:753](../ClawX/src/pages/Chat/index.tsx:753)）：看板视图下可见项为 0（`user` 段隐藏）时显示 `PoDashboardAnalysisState`（分析中 / 失败 / 空闲）。

### 4.2 隐藏触发提示词（[:44](../ClawX/src/pages/Chat/index.tsx:44)）

固定 `PO_DASHBOARD_ANALYSIS_PROMPT`：要求调用 `po-dashboard-analysis` 技能、按物流仓分节分析用工保障与供应商分单，不回抄原始表格。

## 5. 历史回放的三道拦截与豁免（本特性最易踩坑处）

看板分析会话经 `selectAcpSession` 会被 `ensureSessionEntry` 打上 `createdLocally: true`（隐形会话对新 key 恒打标记），但它**本质是后端已持久化的会话**，必须放行去 `loadSession` 回放历史。前端 chat store 通用逻辑对隐形会话设有三道拦截，任一未豁免都会导致 timeline 恒空。

**统一豁免条件**：

```ts
const isPersistedDashboardHistory =
  isPoDashboardSessionKey(currentSessionKey) && currentSessionKey === poDashboardSessionKey;
```

| 拦截 | 位置 | 机制 | 豁免修法 |
| --- | --- | --- |--- |
| 拦截一：`createdLocally` 打标 | [`chat.ts` `selectAcpSession`](../ClawX/src/stores/chat.ts:1237) → `ensureSessionEntry`（[:295](../ClawX/src/stores/chat.ts:295)） | 对不在列表的 key 恒打 `createdLocally: true` | 无需改标记本身，靠下两道识别豁免 |
| 拦截三：`prepareLocalSession` 抢占（最靠前执行） | [`index.tsx` :492 effect](../ClawX/src/pages/Chat/index.tsx:492) | 对 `createdLocally` 会话调 `prepareLocalAcpSession`，它 set `activeSessionKey` + 清空 timeline，**抢占** `acpActiveSessionKey`，使拦截二守卫命中 | effect 开头 `if (isPersistedDashboardHistory) return;`，依赖数组加 `poDashboardSessionKey` |
| 拦截二：加载 effect 提前 return | [`index.tsx` :506 effect](../ClawX/src/pages/Chat/index.tsx:506) | 509 行 `activeSessionKey` 守卫（被拦截三抢占后命中）；519 行 `if (currentSession?.createdLocally && ...) return` | `if (currentSession?.createdLocally && !isPersistedDashboardHistory) return;`；`createIfMissing = !currentSession && !isPersistedDashboardHistory` |

### 5.1 `prepareLocalSession` 为何是抢占元凶（[`acp-chat-session.ts` :1018](../ClawX/src/stores/acp-chat-session.ts:1018)）

它同步 `set({ activeSessionKey, timeline: createEmptyAcpTimeline(...), loading: false })`。一旦对已持久化 dashboard key 调用，`acpActiveSessionKey === currentSessionKey` 立即成立，使加载 effect 第 509 行守卫 `if (acpActiveSessionKey === currentSessionKey && ...) return;` 命中，`loadSession` 永不执行，历史永不回放。

### 5.2 正确路径：走 `loadSession` 回放（[`acp-chat-session.ts` :1040](../ClawX/src/stores/acp-chat-session.ts:1040)）

`loadSession` set `loading: true` 后 `await hostApi.chat.loadAcpSession(input)` 拉后端历史，用返回的 `sessionUpdates` 填充 timeline。三道豁免的目的就是：让已持久化 dashboard key 绕过 `prepareLocalSession` 抢占、绕过加载 effect 的 `createdLocally` return，最终以 `createIfMissing:false` 进入 `loadSession`。

## 6. 后端历史回放（[`acp-chat-service.ts`](../ClawX/electron/services/acp-chat-service.ts:190)）

- `loadSession` 用 `loadQueue` 串行化，避免并发加载互相污染状态。
- `performLoadSession`（[:210](../ClawX/electron/services/acp-chat-service.ts:210)）：
  - `createIfMissing:false` 时 `activeAcpSessionId = sessionKey`、`historicalSessionKey = sessionKey`，调 `connection.loadSession({ sessionId: sessionKey, ... })` 让 openclaw fork 回放该会话 transcript。
  - `createIfMissing:true` 时调 `connection.newSession(...)` 新建。
  - 成功时返回 `sessionUpdates`（[:329](../ClawX/electron/services/acp-chat-service.ts:329)），过滤出属于该 `acpSessionId` 的 envelope，供前端填充 timeline。

### 6.1 后端持久化路径（实证）

会话数据由 openclaw fork 子进程写入本机 `~/.openclaw/agents/<agentId>/sessions/`：

- `sessions.json`：`key → { sessionId, status, sessionFile, ... }` 索引。
- `<uuid>.jsonl`：消息序列（含 user / assistant / toolCall / toolResult）。
- `<uuid>.trajectory.jsonl`：轨迹。

实证结论：dashboard 会话在此**确实被完整持久化**（status=done，assistant 分析输出完整），排除「后端未持久化」的可能——「有历史却显示空态」根因全在前端三道拦截。

## 7. 完整时序（点击「看板分析」Tab）

```mermaid
sequenceDiagram
  participant U as 用户
  participant Tab as handleSelectPoRightTab
  participant Store as poDashboardAnalysisStore
  participant Chat as chat.selectAcpSession
  participant Eff as index.tsx 加载 effect
  participant Acp as acpChatSession.loadSession
  participant BE as acp-chat-service
  participant OC as openclaw fork

  U->>Tab: 点击「看板分析」
  Tab->>Chat: selectAcpSession(持久化 key) 兜底
  Tab->>Store: discoverLatestDashboardSessionKey()
  Store->>BE: rpc sessions.list
  BE-->>Store: 全量会话（含隐形 dashboard）
  Store->>Chat: selectAcpSession(最新 key) 校正
  Note over Eff: 拦截三豁免 → 不 prepareLocalSession
  Eff->>Acp: loadSession(createIfMissing:false)
  Acp->>BE: loadAcpSession
  BE->>OC: connection.loadSession(回放 transcript)
  OC-->>BE: sessionUpdates
  BE-->>Acp: sessionUpdates
  Acp-->>Eff: 填充 timeline（历史回放）
```

## 8. 复用清单（同类「隐形会话回放后端历史」改造）

1. 定义专属 key 前缀 + `isXxxSessionKey`，在 `shouldIncludeSessionInSidebarList` 过滤为隐形会话。
2. 在 `repairMissingCurrentSelection` 豁免该 key，避免选中被 fallback 踢走。
3. 用独立 store 持久化「当前会话 key」作为「有无历史」依据；提供基于 `sessions.list` RPC 的后端发现方法校正前端 key。
4. **三道拦截必须全部用 `isPersistedXxxHistory` 豁免**：`selectAcpSession` 打标（识别）、`prepareLocalSession` 抢占 effect、加载 effect 的 `createdLocally` return 与 `createIfMissing`。任一遗漏都会 timeline 恒空。
5. 不能破坏「新建分析」流程：新时间戳 key 仍需正常 `prepareLocalSession` + `newSession`（`createIfMissing:true`）。
6. 实测切有历史的 Tab 是否回放历史 timeline，并确认后端 `~/.openclaw/agents/<id>/sessions/` 已持久化对应 jsonl。