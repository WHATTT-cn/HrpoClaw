# OpenClaw 二次开发改造方案：知识型合规权重微调 Agent

> 版本：v1.0　｜　日期：2026-08-24　｜　基座：OpenClaw（MIT，TypeScript）
> 约束前提：不改 agent loop、不改 harness，全部改造落在官方受控接缝层（plugin-sdk / 策略链 / 文件层 / 控制面 RPC）。

---

## 一、业务目的

### 1.1 业务场景

业务系统以**算法权重**为基准做决策（如人力资源/供应链场景的供应商评分）。引入 LLM 对权重做微调：输入"case 结构化数据 + 算法权重 + 画像摘要"，LLM 输出权重调整提案。LLM 的价值是引入人类经验式的判断，但其输出**不可信**：可能编造依据、超界调整、被注入文本劫持、随模型版本漂移。

### 1.2 核心理念

**"LLM 只是提案，代码才是法律。"**

- LLM 的每条输出必须穿过五道机器闸门 + 一道人工闸门才允许生效；
- 任何一环失败，回落纯算法权重，流程永不中断；
- 全程留痕，可审计、可回放、可月度回归；
- 交互中产生的知识沉淀为文件，成为可跨会话、跨项目复用的资产。

### 1.3 产品化目标

在核心业务闭环之上，把 agent 产品化：多渠道接入（WhatsApp/邮箱/办公 IM）、主 agent + 子 agent 体系、云端集中管理本地实例、知识资产持续积累与技能自进化。

---

## 二、设计原则

| # | 原则 | 含义 |
|---|---|---|
| P1 | 代码是法律 | 一切强制用确定性代码实现，不依赖提示词纪律 |
| P2 | 不碰内核 | 不改 loop（决策循环）、不改 harness（运行时卡口），只吃官方升级红利 |
| P3 | 生效必经管线 | 收权：凡"产生真实效果"的动作必须注册为工具，工具调用必经闸门链；模型绕开管线的最坏结果 = 无提案 = 安全回落 |
| P4 | 提案-人审-生效三段式 | 任何写入正式文件/系统的动作，先落 staging 提案区，人审通过后合并 |
| P5 | 留痕即可审计 | 每次微调记录全量现场；知识文件的每次变更记录来源与审批人 |

---

## 三、总体架构

```
┌────────────────────────── 不动的内核（官方升级轨道）──────────────────────────┐
│  LLM（发动机） · loop（传动） · harness 卡口（发动机支座）                      │
└─────────────────────────────────────────────────────────────────────────────┘
┌────────────────────────── 改造区一：闸门与人审（插件/策略层）──────────────────┐
│  M1 五道闸门（tool_result_persist hook） · M2 生效校验（execute 映射 + 改写回喂）│
└─────────────────────────────────────────────────────────────────────────────┘
┌────────────────────────── 改造区二：知识与设定（文件/记忆层）──────────────────┐
│  M3 交互→知识文件（提炼+staging+人审+双层写入） · M4 主/子 agent 设定回写        │
│  M5 全局知识层（跨项目复用）                                                   │
└─────────────────────────────────────────────────────────────────────────────┘
┌────────────────────────── 改造区三：运营面（渠道/云端/进化）───────────────────┐
│  M6 渠道接入（现成） · M7 云端控制面（RPC 同步+人审） · M8 技能生产线+月度回归   │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 四、分模块改造方案

### M1　五道代码闸门

**业务目的**：把"幅度硬约束 ±0.10、权重归一化、维度白名单、依据必填+事实回查、输入隔离防注入"从提示词搬进代码，任一不过即拦截。

**方法**：自研插件 `weights-guard`，五闸（`runAllGates` 纯计算逻辑）挂在 `tool_result_persist` hook 中——即 `submit_proposal` 的 execute 把语义提案映射成权重、放行执行**之后**，对执行结果做确定性校验。业务语义是 pass / fail：通过 = APPLIED 写审计并放行结果；不过 = 改写 `ToolResultMessage.content` 为"❌未通过:原因"+`isError=true` 回喂 LLM 重试。M1 内部用中性 `GuardDecision`（allow/block/failClosed）决策，仅在 handler 出口映射成真身 `PluginHookToolResultPersistResult` 的 `message` 改写字段。（注：五闸是纯计算逻辑，`before_tool_call` 只是早期设想的挂载点，岔路甲已改挂 `tool_result_persist`。）

> **硬约束：toolName 守卫（fail-closed 语义）。** hook 第一步必须判定 `event.toolName === "submit_proposal"`：
> - **仅**目标生效类工具（`submit_proposal`）的执行结果才进入五闸；其余任何工具一律放行（`return void` 不改写结果），闸门对普通工具（读文件、跑命令等）无意义。
> - 这不是"放宽安全"，而是把五闸的作用域收敛到唯一的"生效通道"。五闸的输入契约（adjustments/baseWeights/allowedDimensions/证据）本就只为提案工具设计；对通用工具跑五闸会因缺 `allowedDimensions` 触发白名单 fail-closed，把所有工具结果改写死（见下，M1 已内置守卫修复）。
> - fail-closed 在此的正确落点是：`toolName` 缺失/非目标 → 放行（因为它不是"生效动作"，放行不产生真实效果，符合 P3"绕开管线=无提案=安全回落"）；而一旦是 `submit_proposal`，任何解析失败/闸门异常一律改写回喂重试。安全红线约束的是"生效类动作"，不是"所有工具调用"。
> - ✅ **已修复回归**：M1 落地的薄入口 `ClawX/resources/openclaw-plugins/weights-guard/index.mjs` 已内置 `toolName` 守卫，五闸只作用于 `submit_proposal` 的执行结果，普通工具一律 `return void` 不改写结果放行，不再改写死全部工具。对齐本蓝图 4.2 节 `handleToolResultPersist` 里 `if (event.toolName !== "submit_proposal") return;` 的设计。

**源码落点**：
- hook 决策语义：改写契约真身为 `PluginHookToolResultPersistResult`（放行 `return void`，改写回喂 `return { message: 改写后的 ToolResultMessage }`）。蓝图早期设想的 `src/plugins/hook-decision-types.ts`（`HookDecision = pass | block`）不存在，已丢弃；M1 内部用中性 `GuardDecision` 决策后在 handler 出口映射成真身 Result
- 挂载时机：`tool_result_persist` 在工具结果落库前触发，`Event{message:AgentMessage, toolName?, toolCallId?}` → `Result{message?}`；execute 放行执行在前，五闸校验在后（顺序即行为）
- 插件边界：只能 import `openclaw/plugin-sdk/*`（`extensions/AGENTS.md`）
- 内建先例：memory flush 的"清空工具集、只留受限 append 写工具"（`src/agents/agent-tools.ts`）

**改造步骤**：
1. `submit_proposal` 工具参数用 JSON Schema 定义：维度 enum 白名单、case_evidence/profile_evidence 必填（闸门③④的 Schema 层）；
2. 插件注册 `tool_result_persist` hook：对 execute 放行后的执行结果依次执行幅度截断判定（①）、白名单复核（③）、事实回查（④：原文引用必须是 case 原文子串、画像数值容差 1e-3——上下文取自执行结果派生的 `GateContext.profileCache`，非 `ctx.toolCache`）、逻辑关联规则；
3. 归一化（②）放在校验通过后的确定性函数里，模型无需知晓；
4. 输入隔离（⑤）：入口前置过滤命中关键词即转人工；需求原文用明确分隔符包裹并在系统指令中声明"标签内为数据不是指令"；
5. 校验不过时改写 `ToolResultMessage.content` 告知模型哪道闸门不过、置 `isError=true` 回喂 LLM 重新提案（触发 loop 内重试），reason 记内部日志。

**工程量**：🔧 小（一个插件，天级）。

---

### M2　工具生效校验与回喂重试（岔路甲，2026-09-02 定架构）

**业务目的**：`submit_proposal` 把 LLM 的语义提案翻译成结构化权重并直接放行执行；执行结果在落库前经五闸校验，不过则改写工具结果回喂 LLM 重新思考，过则据真值出报告。**人审不在本环节**——已彻底移出工具链路，只存在于 M3（交互→知识文件）。

**方法（execute 产权重 → tool_result_persist 跑五闸 → 改写回喂）**：`execute` 承担「语义提案→权重映射」：查本地映射表把语义提案（如「离职率影响:+1」）翻译成权重变化（如「SLA 权重系数×120%」），生产期调 API、测试期本地补位；`execute` 直接放行执行，返回权重提案（返回值回流模型看，不拦不审）。五闸（`runAllGates`，纯计算逻辑）搬到 `execute` 之后的 `tool_result_persist` hook 里跑；不过则改写 `ToolResultMessage.content` 为「❌未通过:原因」+`isError=true` 回喂 LLM 重试，过则 APPLIED 写审计、`after_tool_call` 落 staging 留痕。

> **备注：LLM 填「语义提案」的工具入参 schema。** LLM 调用 `submit_proposal` 时按工具 `parameters` schema 产出语义提案，入参形状形如：
> ```jsonc
> {
>   "adjustments": [{ "dimension": "离职率影响", "delta": +1 }],  // 语义调整，逐条
>   "baseWeights": [ ... ]                                        // 调整前算法基线权重
> }
> ```
> `execute` 收到该入参后查映射表，把「离职率影响:+1」这类语义 delta 翻译成权重系数变化。
>
> **⚠️ 入参格式硬约束（真身调研结论，2026-09-02）：ClawX/openclaw 插件侧注册工具只接受 TypeBox `TSchema`，不接受手写 JSON Schema 对象。** 依据 `openclaw/plugin-sdk/tool-plugin`（真身 `tool-plugin-*.d.ts`）：
> - `import { Static, TSchema } from "typebox"`；`defineToolPlugin` 的工具工厂签名为 `<TParamsSchema extends TSchema>(definition: { parameters: TParamsSchema; execute: (params: Static<TParamsSchema>, ...) => ... })`——`parameters` 字段类型被泛型约束死为 `TSchema`，且 `execute` 入参类型由 `Static<TSchema>` 反推，schema 与运行时类型一体。
> - LLM 端看到的 `inputSchema: JsonObject`（JSON Schema）是上游协议层从 `TSchema` **自动降解**的产物（`ToolDescriptor`/`ToolProtocolDescriptor`），并非插件手写。
> - **落地影响**：当前 `schema.ts` 的手写 `SUBMIT_PROPOSAL_SCHEMA`（Draft-07 常量）不能直接作为 `parameters` 交给 `defineToolPlugin`，需改写为 `Type.Object({ adjustments: Type.Array(...), baseWeights: ..., ... })` 的 TypeBox 声明；手写校验器 `validateSubmitProposalParams` 可保留作 fail-closed 二次护栏。

**源码落点**：
- 五闸+改写拦截：`tool_result_persist` hook，`PluginHookToolResultPersistEvent{message:AgentMessage}` → `Result{message?}`（能改写工具结果消息，docs：「Rewrite the assistant message produced from a tool result」）
- staging 留痕：`after_tool_call` hook（插件侧返回 void，只读观察者，正好只落盘不干预）
- ⚠️运行环境边界：`tool_result_persist` 仅对 OpenClaw-owned transcript 生效，Codex-native harness 下失效；ClawX 默认走 OpenClaw-owned transcript（已确认），岔路甲成立
- 语义提案入参形状校验：`submit_proposal` 的 TypeBox `TSchema`（`schema.ts`，上游 `parameters` 只收 TSchema；手写校验器留作 fail-closed 二次护栏）
- 人审 requireApproval 仅 `before_tool_call` 独有，本架构不再使用（人审移至 M3）

**改造步骤**：
1. `execute`：解析语义提案 → 查本地映射表（先用最简单单维度线性例）→ 归一化截断 `w = clip((算法权重+ΣΔ)/sum, 0, 1)` → 返回权重提案，直接放行；
2. `tool_result_persist`：`toolName===submit_proposal` 守卫 → 跑五闸 → 不过则改写 `content` 为「❌未通过:原因」+`isError=true` 回喂，过则放行并 APPLIED 写 `staging/audit/<case_id>.jsonl`；
3. `after_tool_call`：把权重提案写入 `staging/proposals/<case_id>.md` 留痕；
4. 生效执行函数不注册为模型工具；回喂重试由 agent loop 天然驱动，无需 loop 外编排。

**工程量**：🔧 小（映射表最简例 + 三 hook 接线，五闸复用 M1）。

---

### M1+M2 合章：完整时序（岔路甲，工具出口先于自然语言出口）

> 这是 M1（五闸）与 M2（execute 产权重 + tool_result_persist 校验回喂）合起来运转时的**权威时序**（2026-09-02 岔路甲），也是整个合规回路的骨架。一句话：**工具出口负责"真"（映射+闸门+审计），自然语言出口负责"美"（组织语言、解释依据），且"美"必须建立在"真"到手之后、经过对账之前不放行。人审已移出本回路（仅存在于 M3）。**

用户看到的报告 = 受约束的权重结果 + 业务方案 + "被验证的思考过程"。这三样的原料**全部来自工具回路**，自然语言只是最后的装帧。

```
用户提问
  │
  ▼
【第 1 轮】模型思考（thinking，不可信，不展示）
  │  输出：tool_use = submit_proposal(语义提案A，如"离职率影响:+1")
  ▼
execute 直接放行执行（不拦不审）
  │  查本地映射表：语义提案 → 权重变化（如"SLA权重×120%"）→ 归一化截断
  │  返回权重提案（返回值回流模型看）
  ▼
tool_result_persist hook 跑五闸（M1，仅对 toolName===submit_proposal 触发）──► 若不过：
  │    改写 ToolResultMessage.content = "❌未通过:<原因>，请重新提案" + isError=true
  │    模型收到失败结果 → 带着原因重新思考 → 提交提案B（这就是"退回再思考"，agent loop 天然驱动）
  │    （限重试 N 次👤，超限则改写为"无法合规调整，维持算法权重"）
  ▼ 若通过
APPLIED 写审计 staging/audit/<case_id>.jsonl
  │    tool_result 携带 {生效后权重:{...}, 版本号, traceId}
  │    after_tool_call（只读）落 staging/proposals/<case_id>.md 留痕
  ▼
【第 2 轮】模型基于 tool_result 组织报告（自然语言出口此时才打开）
  │    原料：tool_result 里的真实数值 + 审计轨迹
  ▼
message_sending 出站对账（第二道防线：报告数字与审计不符即 cancel）
  ▼
用户看到报告
```

**逻辑顺序四要点：**

1. **工具出口永远先于自然语言出口。** 报告是"第 2 轮"的产物——模型必须先把提案送进管线（execute 映射 + tool_result_persist 校验）、拿到真实结果（`tool_result`），才被允许开口写报告。若模型第一轮就想直接输出"建议调整风险权重到 0.24"而不调工具，出站 hook 的对账会发现"无对应审计记录的数字声明"，`block` 并要求重走管线。
2. **"退回再思考"由改写后的 `tool_result` 驱动，不是模型自觉。** 五闸不过时 `tool_result_persist` 把工具结果改写成失败原因（`isError=true`）喂回模型，agent loop 天然会基于失败原因重试——重试发生在**同一次用户提问的内部循环**里，用户无感知，只看到最终合规的结果。
3. **报告里"思考过程"的正确来源：不是模型的 thinking，而是把审计轨迹（提案A被拦→原因→提案B→生效）由代码渲染成人类可读的叙事。** 例：
   > "首次方案因风险维度调整幅度超限（-0.15）被闸门拦截，修正为 -0.06 后提交；依据 case#8842 近 90 天回撤 18%（已回源验证）；生效后当前权重：风险 0.24 / 成长 0.44 / 流动性 0.32。"

   这段话每个事实都来自审计日志——模型只负责润色句式，**事实骨架由代码模板生成**。既满足"展示被验证正确的思考过程"，又不依赖模型那张不可信的嘴。
4. **数字的呈现受收口规则约束：** 报告中的权重数值，**要么**由代码渲染卡片，**要么**出站对账通过，二选一。

**结论：模型的思考过程只作燃料，不作展品；展出的"思考过程"是审计轨迹的代码级重演。** 这条时序把 M1（五闸 + toolName 守卫，挂在 `tool_result_persist`）、M2（execute 权重映射 + 改写回喂重试 + `after_tool_call` 留痕）、以及出站收口（`message_sending` 对账，见技术文档 §4.2.1）三者钉死在同一条回路上。人审已移出本回路，仅存在于 M3。

---

### M3　交互沉淀为知识文件

**业务目的**：用户与 agent 的交互中值得复用的知识，自动抽取 → 人审 → 落到工作区根自定义 `.md` 与 per-agent `agent.md`。

**方法**：不用内建 memory flush 的默认口径（其提示词在核心 `src/auto-reply/reply/memory-flush.ts`，不可纯 config 改），自建提炼通道：cron/会话结束触发 → 读会话 transcript → 按自定义标准提炼 → 写 staging → 人审 → 合并入正式文件 → 注入上下文。

**源码落点**：
- 记忆宿主门面：`src/plugin-sdk/memory-host-core.ts`（`registerMemoryCapability` / `registerMemoryCorpusSupplement`，把自定义知识文件纳入上下文——active-memory 扩展同款路径）
- 文件即上下文：`src/agents/system-prompt.ts` 的 `EmbeddedContextFile[]` 管道
- 内建自动机制参照：memory flush（软阈值触发、静默 turn、受限 append）与 `agents.defaults.compaction.memoryFlush.{enabled,model,softThresholdTokens}` 配置
- 触发器：`src/cron` / heartbeat

**改造步骤**：
1. 插件 `knowledge-harvester`：注册 cron 任务（如每日/会话结束后）拉取会话 transcript；
2. 提炼 prompt 自定义（标准：可复用的判断规则、纠正记录、口径变更、事实性结论），输出结构化 JSON；
3. 写入 `staging/knowledge/<date>.md` 提案区；
4. 人审通过后合并进 `KNOWLEDGE.md`（工作区根新建）与各 agent 目录的 `agent.md`；
5. 插件经 `memory-host-core` 注册 corpus supplement，使这些文件后续会话自动注入系统提示。

**工程量**：🛠 中（插件 + 提炼逻辑 + 人审接线，周级）。

---

### M4　主/子 agent 设定更新（soul 层）

**业务目的**：把会话中提炼出的"行为模式/身份要素"回写主 agent 的 SOUL.md / IDENTITY.md，子 agent 有独立设定。

**方法**：主 agent 直接回写文件（`IDENTITY.md` 有结构化合并支持）；子 agent 利用 multi-agent 布局的 agent 专属目录放独立 `agent.md`/SOUL 文件；所有写入过人审。

**源码落点**：
- `src/agents/identity-file.ts`：`mergeIdentityMarkdownContent` 字段级合并写
- `src/agents/workspace.ts`：五件套创建；防子 agent spawn 重建根级可选文件——即 agent 专属子目录布局是一等支持
- 子 agent 继承语义：`src/agents/openclaw-tools.types.ts`（spawn 时传 workspace，子 agent 继承；要独立设定则指向专属目录）
- 系统提示语义：`system-prompt.ts` 已标注 "SOUL.md: persona/tone…unless higher-priority instructions override"

**改造步骤**：
1. 提炼管线产出"设定类"知识时，写入 `staging/soul-proposals/`；
2. 人审通过 → 主 agent：合并写 `SOUL.md`（自由文本追加）与 `IDENTITY.md`（走字段级合并，防破坏结构）；
3. 子 agent：写入 `<agentDir>/agent.md`（per-agent 目录），并纳入该 agent 的 bootstrap 注入；
4. 文件生效时机：bootstrap 文件每轮 prepare 重读，**写完下一轮对话即生效**，天然热更新。

**工程量**：🛠 中。

---

### M5　全局知识层（跨项目复用）

**业务目的**：OpenClaw 无原生全局记忆层（验证：无 `~/.openclaw` 全局 AGENTS/MEMORY 加载证据），自建"总档案馆"承载跨项目可复用知识条款。

**方法**：建全局目录 `~/.knowledge-base/`（按主题分文件），插件注册为全局记忆 corpus；项目知识仍留各 workspace。检索默认 grep + 索引摘要进系统提示；条目超阈值（数百条）再叠加向量层。

**源码落点**：
- `src/plugin-sdk/memory-host-core.ts`：注册全局 corpus supplement
- 向量扩展参照：`extensions/memory-lancedb`（可选加速层）
- 分层策略：全局 = 通用条款；workspace `MEMORY.md` = 项目专属事实

**改造步骤**：
1. 建 `~/.knowledge-base/`（含 `INDEX.md`：每条款一行摘要，供注入系统提示）；
2. M3 人审时增加去向选择：项目级（workspace 文件）或全局级（知识库）；
3. 插件启动时读 INDEX.md 注入；agent 按需 grep/read 详情文件；
4. 可选：接 `memory-lancedb` 做语义召回，命中候选后仍 read 原文（文件是事实源，向量只是索引）。

**工程量**：🛠 中。

---

### M6　渠道接入

**业务目的**：WhatsApp + 邮箱 + 办公 IM 全渠道触达。

**方法**：全部用现成件，零改造。

**源码落点与步骤**：
| 渠道 | 实现 | 注意 |
|---|---|---|
| WhatsApp（个人号） | `extensions/whatsapp`（baileys，扫码登录） | 非官方协议有封号风险，用专用号；渠道设计为可替换件 |
| 邮箱 | `skills/himalaya`（IMAP/SMTP） | 技能层，配好账户即用 |
| Slack / Teams / 飞书 | `extensions/slack` / `msteams`（+`teams-meetings`）/ `feishu` | 官方 SDK 级渠道插件，带配对/审批/消息生命周期 |

渠道消息全部汇入 Gateway 统一会话与策略链——**M1/M2 的闸门对所有渠道一视同仁**，无需逐渠道重造。

**工程量**：⚙️ 现成配置。

---

### M7　云端控制面

**业务目的**：云端服务器实时指导各本地 OpenClaw 实例，统一下发口径文件/知识条款/人格设定（覆盖 SOUL.md、SKILL.md、config）。

**方法**：反向同步拓扑（本地零入站暴露）：本地跑云同步插件主动出站长连云端 → 拉取配置版本清单 → **变更先落 staging 提案 → 本地人审通过 → 才正式生效** → 上报留痕。云端是"提案方"，不是"命令方"。

**源码落点**：
- 控制面协议：`packages/gateway-protocol`（WS/JSON-RPC 全 schema）+ `packages/gateway-client`
- 配置写入 RPC：`config.set` / `config.patch` / `config.apply`（`src/gateway/server-methods/config.ts`，自带删改护栏；`config-write-flow.ts` 计算热重载/重启 plan）
- 文件覆盖 RPC：`agents.files.set`（白名单 `WORKSPACE_BOOTSTRAP_FILENAMES`：SOUL/USER/AGENTS/MEMORY/BOOTSTRAP）；IDENTITY.md 走 `agents.update` 结构化合并
- 认证：`gateway.auth.mode` = token/password/trusted-proxy + 设备配对 + `auth-rate-limit`
- 审计：`src/gateway/server-methods/audit.ts`

**改造步骤**：
1. 云端建"实例注册表 + 配置版本清单"服务；
2. 本地插件 `cloud-sync`：出站长连/轮询云端，比对版本；
3. 有新版 → 下载至 `staging/cloud/<version>/` → 触发本地人审（M2 通道）；
4. 人审通过 → 调 `config.patch`（配置）/ `agents.files.set`（文件）生效 → 上报结果；
5. 网络层走 Tailscale（设备级加密）或纯反向连接，**绝不裸暴露公网**。

**工程量**：🛠 中（云端服务 + 同步插件）。

---

### M8　技能生产线与月度回归

**业务目的**：借鉴 Hermes Curator 思路，让 agent 的经验自动固化为技能；每月用金标准集回归防漂移。

**方法**：自建生产线（OpenClaw 无运行时技能 CRUD 工具面）：cron/空闲触发 → 子 agent 审查近期知识与会话 → 起草新技能/技能补丁 → staging → 人审 → 落 `skills/`。纪律抄 Hermes：**只归档不删除、归档可恢复、pinned 豁免、审查用便宜的辅助模型**。

**源码落点**：
- 子 agent spawn：`src/agents/openclaw-tools.types.ts` 继承语义；multi-agent `agents.entries`
- cron：`src/cron`
- 技能目录与安装：`skills/`、`onboard-skills` 生命周期
- 回归参照内建配置：`agents.defaults.compaction.memoryFlush.model` 可为审查/回归配本地模型（如 ollama/qwen3:8b）省钱

**改造步骤**：
1. cron 任务 `skill-curator`：每周/空闲时 spawn 子 agent，读近期 `KNOWLEDGE.md` 增量与会话摘要；
2. 子 agent 产出技能草稿（SKILL.md 格式）或既有技能补丁，落 `staging/skills/`；
3. 人审通过 → 落 `skills/custom/` → 触发生命周期安装；
4. 月度回归：cron 回放 20-30 个金标准 case，计算漂移指标（平均调整量偏差 >0.03 或方向翻转率 >15% 告警）；prompt 文本进版本管理。

**工程量**：🏗 大（唯一的大件，数周级）。

---

## 五、实施路线图

| 阶段 | 内容 | 依赖 | 里程碑 |
|---|---|---|---|
| P0 环境（1 周） | 部署 OpenClaw、接入渠道（M6）、跑通五件套 | 无 | agent 在各渠道可对话 |
| P1 核心闭环（2-3 周） | M1 五道闸门 + M2 生效校验与回落 | P0 | 权重微调全链路合规上线 |
| P2 知识沉淀（2 周） | M3 提炼管线 + M4 设定回写 | P1 | 知识文件开始积累 |
| P3 全局与多 agent（2 周） | M5 全局知识层 + 子 agent 独立设定 | P2 | 跨项目复用打通 |
| P4 云端控制（2-3 周） | M7 云同步插件 + 云端服务 | P1 | 多实例集中纳管 |
| P5 进化与回归（3-4 周） | M8 技能生产线 + 月度回归 | P2/P3 | 自进化闭环运转 |

P1 是业务上线最小集；P2 之后各阶段可并行度较高。

---

## 六、安全与合规清单

1. **闸门不可绕过性审计**：枚举 agent 可达的全部副作用通道（工具/网络/文件/交付），逐一确认"只读 / 必经闸门 / 被沙箱拦截"三选一——重点防"旁路生效"；
2. **云端控制面**：token/password 认证 + 设备配对 + Tailscale/反向连接 + 专用低权限身份 + 全量审计（谁、何时、改哪台、改什么）；
3. **渠道风险**：baileys 属非官方协议，WhatsApp 用专用号，渠道按可替换件设计；
4. **技能供应链**：只装审核过的技能，社区技能先跑安全扫描（ClawHub 有恶意包记录）；
5. **生效权限最小化**：生效执行函数不注册为模型工具；五闸校验失败一律 fail-closed 回落算法权重（M3 人审超时另默认安全态）；
6. **基线安全**：OpenClaw 高权限特性（exec/文件写）按官方 security 文档加固（回环绑定、最小权限密钥、沙箱）。

---

## 七、验收标准

| 类别 | 指标 |
|---|---|
| 闸门有效性 | 注入攻击用例、超界用例、编造依据用例 100% 被拦截；误拦率 <5% |
| 流程韧性 | 模型缺席/乱输出时流程不中断，100% 回落算法权重 |
| 生效校验闭环 | 提案→execute 映射→tool_result_persist 五闸→改写回喂/APPLIED 写审计全留痕；校验失败回落算法权重 |
| 知识沉淀 | 知识条目经人审入库；后续会话能检索引用；全局条款跨项目可见 |
| 设定更新 | SOUL/agent.md 变更下一轮生效；子 agent 设定独立于主 agent |
| 云端控制 | 云端下发→stating→人审→生效全链路 <1 分钟；无入站端口暴露 |
| 防漂移 | 月度回归两个漂移指标可产出、超阈值告警 |

---

## 附录：源码锚点速查

| 用途 | 路径 |
|---|---|
| hook 决策语义 | `src/plugins/hook-decision-types.ts` |
| 工具调用前策略链 | `src/agents/agent-tools.before-tool-call.policy.ts` / `.approval.ts` |
| 生效校验接缝契约 | `PluginHookToolResultPersistResult.message`（改写 `ToolResultMessage.content`+`isError` 回喂 LLM） |
| 人审接入契约（仅 M3 用） | `PluginHookBeforeToolCallResult.requireApproval`（由上游审批策略链消费） |
| 记忆宿主门面 | `src/plugin-sdk/memory-host-core.ts` |
| 根记忆文件定位 | `src/memory/root-memory-files.ts`（canonical `MEMORY.md`） |
| 身份文件合并写 | `src/agents/identity-file.ts` |
| 内建自动记忆抽取 | `src/auto-reply/reply/memory-flush.ts` + config `agents.defaults.compaction.memoryFlush.*` |
| 系统提示装配 | `src/agents/system-prompt.ts`（`buildProjectContextSection`） |
| 云端 RPC | `packages/gateway-protocol` / `gateway-client`；`config.set|patch|apply`；`agents.files.set` |
| 认证 | `src/gateway/auth-resolve.ts`（none/token/password/trusted-proxy） |
| 渠道 | `extensions/whatsapp`（baileys）、`skills/himalaya`、`extensions/slack|msteams|feishu` |
