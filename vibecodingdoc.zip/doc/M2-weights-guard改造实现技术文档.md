# M2 weights-guard 改造实现技术文档

> 本文记录 weights-guard 从 M1“机器五闸”扩展到 M2“生效校验、审计、留痕与出站对账”闭环的实现过程（岔路甲架构，2026-09-02 定）。内容以当前源码及 `openclaw@2026.7.1-2` 实测 hook 契约为准。人审已移出 M2 工具链路，仅存在于 M3。

---

## 1. 总体目标与全局约束

M2 的目标不是新增一组孤立校验，而是在 M1 五闸之后建立完整的生效与报告闭环：

```text
submit_proposal
  → execute：语义提案 → 权重映射（查映射表）→ 直接放行执行，返回权重提案
  → tool_result_persist：跑 M1 五闸
       不过 → 改写 ToolResultMessage.content="❌未通过:原因"+isError=true → 回喂 LLM 重试
       过   → APPLIED JSONL 审计
  → after_tool_call：只读落 staging 留痕
  → Agent 第 2 轮据 tool_result 生成报告（正文携带 [case:<case_id>]）
  → message_sending 出站对账（第二道防线）
```

全局约束如下：

1. execute 不拦不审，只做「语义→权重」映射并返回提案；生效校验全部由 tool_result_persist 五闸负责。
2. 解析失败、五闸异常、审计缺失、数字无法证实均 fail-closed。
3. 五闸不过时改写工具结果回喂 LLM，驱动模型重新提案，而非阻断执行。
4. 报告事实以 APPLIED 审计轨迹为准，不以模型推理过程为准。
5. 工具出口先于自然语言出口；出站对账是最后一道安全闸。
6. 人审移出 M2 工具链路（不再用 `requireApproval`），仅存在于 M3。
7. M2 继续采用 A 路：业务逻辑留在 guard-suite，ClawX resources 仅保留薄接线。

## 2. 上游真实接口基线

### 2.1 生效校验出口（tool_result_persist）

M1 五闸挂在 execute 之后的 `tool_result_persist` hook（唯一能改写工具结果回喂 LLM 的挂载点）。真身 `PluginHookToolResultPersistEvent{message:AgentMessage,toolName?,...}` → `Result{message?}`：

```ts
// 五闸不过：改写工具结果消息为失败原因，置 isError=true，回喂 LLM 重试
return { message: rewriteToolResult(event.message, `❌未通过:${decision.reason}，请重新提案`) };
// 五闸通过：返回 undefined 原样放行，交后续 APPLIED 写审计
```

改写目标 `ToolResultMessage{role:"toolResult",toolCallId,toolName,content:(Text|Image)[],isError,...}`：文本放 `content`，失败置 `isError=true`。`after_tool_call` 只读（返回 `void`），仅落 staging 留痕，拦不了改不了。插件不再使用 `requireApproval`（该出口仅 `before_tool_call` 独有，人审已移出 M2）。

### 2.2 出站出口

真实出站 hook 为 `message_sending`：

- 正文位于 `event.content`。
- 拦截返回 `{ cancel: true, cancelReason }`。
- 放行返回 `undefined`。
- event 与 ctx 均不天然携带业务 `case_id`。

因此 M2 使用报告正文可见 footer `[case:<case_id>]` 关联审计记录。

## 3. 仓库拓扑与职责

| 文件 | 职责 |
|---|---|
| `plugins/weights-guard/src/schema.ts` | `submit_proposal` JSON Schema 与运行期形状校验 |
| `plugins/weights-guard/src/execute.ts` | `submit_proposal` 的 execute：语义→权重映射，直接放行返回提案 |
| `plugins/weights-guard/src/handler.ts` | 目标工具守卫、`tool_result_persist` 五闸执行与结果改写、`after_tool_call` 留痕 |
| `shared/src/staging.ts` | 待审提案写入 `staging/proposals` |
| `shared/src/audit.ts` | APPLIED JSONL 审计读写 |
| `plugins/weights-guard/src/fallback.ts` | execute 映射失败时兜底纯算法权重（人审三分诊已移出 M2） |
| `plugins/weights-guard/src/report-claims.ts` | footer 与报告数字声明抽取 |
| `plugins/weights-guard/src/outbound.ts` | `message_sending` 出站对账 |
| `plugins/weights-guard/src/bundle-entry.ts` | 控制自包含 bundle 的运行时导出 |
| `ClawX/resources/openclaw-plugins/weights-guard/index.mjs` | ClawX 薄入口：注册 submit_proposal execute + tool_result_persist/after_tool_call/message_sending 三 hook |

## 4. T1～T7 实施过程

| 任务 | 实现结果 | 关键产物 |
|---|---|---|
| T1 生效校验 | execute 映射放行 + tool_result_persist 五闸改写回喂 | `execute.ts`、`handler.ts`、`types.ts` |
| T2 staging | 建立待审 Markdown 提案区 | `shared/src/staging.ts` |
| T3a 审计 | 建立 APPLIED JSONL 真值轨迹 | `shared/src/audit.ts` |
| T3b 出站对账 | footer 关联、数字抽取、审计比对 | `report-claims.ts`、`outbound.ts` |
| T4 留痕与兜底 | after_tool_call 落 staging + execute 映射失败兜底算法权重 | `handler.ts`、`fallback.ts` |
| T5 工具契约 | 固化 `submit_proposal` Schema | `schema.ts` |
| T6 真实接线 | bundle 导出及 ClawX execute + 三 hook 注册 | `bundle-entry.ts`、`index.mjs` |
| T7 漂移订正 | 蓝图统一到真实 hook、字段和路径 | 两份 OpenClaw 改造文档 |

## 5. T1：execute 映射放行 + tool_result_persist 五闸契约

**execute 段**：`executeSubmitProposal` 承担「语义提案→权重映射」。查映射表把语义调整（如“离职率影响:+1”）翻译成权重变化（如“SLA 权重×120%”），生产期调 API、测试期本地补位，归一化后直接放行执行，返回权重提案。返回值回流模型看（string→文本，JSON→details），不进 hook，不拦不审。

> **备注：LLM 填「语义提案」的工具入参 schema。** LLM 调用 `submit_proposal` 时按 `parameters` schema 产出语义提案，入参形如 `{ adjustments: [{ dimension: "离职率影响", delta: +1 }], baseWeights: [...] }`（`adjustments` 逐条语义调整 + `baseWeights` 算法基线权重）；`executeSubmitProposal` 收到 `Static<TParamsSchema>` 类型的入参后查映射表翻译成权重变化。
>
> **⚠️ 入参格式硬约束（真身调研，2026-09-02）：openclaw 插件侧只接受 TypeBox `TSchema`。** 依据 `openclaw/plugin-sdk/tool-plugin`：`defineToolPlugin` 工具工厂签名 `<TParamsSchema extends TSchema>(def: { parameters: TParamsSchema; execute: (params: Static<TParamsSchema>, ...) => ... })`，`parameters` 泛型约束死为 `TSchema`；LLM 端 `inputSchema: JsonObject`（`ToolDescriptor`）由协议层从 `TSchema` 自动降解。**落地影响**：`schema.ts` 现有手写 `SUBMIT_PROPOSAL_SCHEMA`（Draft-07 常量）须改写为 `Type.Object({...})` 的 TypeBox 声明才能交给 `defineToolPlugin`；手写 `validateSubmitProposalParams` 保留作 fail-closed 二次护栏。（详见方案文档 M2 §「方法」备注。）

**五闸段**：`handleToolResultPersist` 先用 `event.toolName === "submit_proposal"` 做白名单式守卫。非目标工具结果直接放行；目标工具结果从 `ToolResultMessage` 取出 execute 产出的权重，跑 M1 五闸（`runAllGates` 纯计算逻辑）。解析失败或五闸异常均 fail-closed 视为不过。

```ts
// 不过：改写工具结果回喂 LLM 重试
if (decision.kind === "block") {
  return { message: rewriteToolResult(event.message, `❌未通过:${decision.reason}，请重新提案`) };
}
return undefined; // 过则原样放行
```

关键设计：

- execute 直接放行，五闸在结果落库前才校验；两段职责分离。
- 五闸不过时把 `ToolResultMessage.content` 改写为失败原因、`isError=true`，回喂 LLM 驱动重新提案，而非阻断执行。
- block 判定必须 fail-closed：解析异常、缺权重、五闸抛错都视为不过。
- 非目标工具结果不改写；人审不在本链路（不再用 `requireApproval`）。

## 6. T2：staging 待审提案

待审提案写入：

```text
staging/proposals/<case_id>.md
```

`writeStagingProposal` 校验 `caseId`、权重数组和路径安全，创建目录后写入可审阅 Markdown，并附加：

```html
<!-- status: PENDING_REVIEW -->
```

任何路径穿越、非法权重或 I/O 异常都返回 block。成功结果携带 `stagingPath`。

当前边界必须明确：staging 模块及契约测试已经完成，但当前 `handler.ts` 主链尚未在 `after_tool_call` 调用 `writeStagingProposal`；不能把“模块可用”描述为“已在真实 tool_result_persist/after_tool_call 链路自动落盘”。

## 7. T3a：APPLIED 审计真值

审计路径为：

```text
staging/audit/<case_id>.jsonl
```

每行一条记录：

```ts
{
  status: "APPLIED",
  caseId,
  appliedWeights,
  version,
  traceId,
  timestamp
}
```

`appendAppliedRecord` 负责二次校验并追加写入；`loadAuditTrail` 读取全部合法记录，并取最大 `version` 对应的权重作为最新真值。

文件不存在返回空轨迹，损坏 JSON 行被跳过。该行为不会形成静默放行：出站层在无 APPLIED 真值时会拦截所有数字声明。

## 8. T4：after_tool_call 留痕与 execute 映射兜底

五闸通过后，`after_tool_call` 只读 hook（返回 `void`，拦不了改不了）落 staging 留痕；APPLIED 权重以 tool_result_persist 通过时写入的审计为准。execute 段的 `mapProposalToDeltas` 若映射失败（如映射表缺项、API 异常），按 `fallbackToAlgorithm` 兜底为纯算法权重：

| 场景 | 行为 |
|---|---|
| 五闸通过 | after_tool_call 落 staging，APPLIED 写审计 |
| execute 映射成功 | 返回权重提案，交五闸校验 |
| execute 映射失败 | 允许兜底时用纯算法权重，否则 fail-closed 让五闸拦下 |

每次成功写入前读取现有轨迹，按最大版本号加一。权重映射使用“维度名 → 数值”，键名必须与报告声明一致。

当前边界需明确：`after_tool_call` 留痕与兜底逻辑已实现并通过独立测试，但尚未在主链完成运行时接线，文档不能宣称已由 OpenClaw 自动触发。人审三分诊（approved/rejected/timeout）已移出 M2，仅存在于 M3。

## 9. T5：`submit_proposal` 工具契约

`SUBMIT_PROPOSAL_SCHEMA` 同时承担上游工具声明和运行期形状真值两项职责。顶层必填字段为 `adjustments`、`baseWeights`、`allowedDimensions`、`caseRawText` 和 `profileCache`。

运行期先执行 `validateSubmitProposalParams`，再进入五闸。Schema 通过只代表结构合法，不代表证据真实，也不代表提案可以生效。非目标工具不进入权重五闸，因为它们不会触发权重生效。

## 10. T3b：报告抽取与出站对账

### 10.1 case 关联与声明抽取

由于 `message_sending` 不携带业务 case 标识，报告末尾必须包含：

```text
[case:<case_id>]
```

`extractCaseId` 全局扫描 footer，多次出现时取最后一个，并拒绝路径分隔符和空白等非法字符。`extractClaims` 只识别“维度 = 数值”等强结构声明，不猜测模糊自然语言。

### 10.2 对账规则

`reconcileReport` 按以下顺序执行：

1. 从 `event.content` 提取 case_id；缺失即 block。
2. 抽取报告数字声明；纯定性报告可放行。
3. 读取该 case 最新 APPLIED 审计；无真值时拦截数字声明。
4. 校验声明维度存在于审计。
5. 使用 `config.evidenceTolerance` 比较报告值与审计值。
6. 任一异常或不一致均 block。

`handleMessageSending` 将中性 block 映射为：

```ts
return { cancel: true, cancelReason: decision.reason };
```

## 11. T6：bundle 与 ClawX 三 hook 接线

### 11.1 自包含 bundle

`bundle-entry.ts` 只导出薄入口所需的运行时 API，包括 `executeSubmitProposal`、`handleToolResultPersist`、`handleAfterToolCall`、`handleMessageSending`、`reconcileReport`、`DEFAULT_CONFIG`、`TARGET_TOOL_NAME` 和 `isGuardedTool`。共享包被内联进 ESM bundle，ClawX resources 不承担业务实现。

### 11.2 ClawX 薄入口

薄入口注册 `submit_proposal` 的 execute 与 `tool_result_persist`、`after_tool_call`、`message_sending` 三个 hook。execute 做语义→权重映射直接放行；tool_result_persist 五闸不过则改写工具结果回喂；after_tool_call 只读留痕；message_sending 调用 `handleMessageSending`。各层接线均 fail-closed：五闸异常视为不过并回喂，出站异常返回 cancel。

## 12. T7：蓝图漂移订正

M2 完成后同步订正总体方案和源码改造文档：

| 历史漂移 | 真实实现 |
|---|---|
| before_tool_call 人审 requireApproval | execute 映射放行 + `tool_result_persist` 五闸改写回喂（人审移出 M2） |
| 旧出站 hook | `message_sending` |
| 旧正文路径 | `event.content` |
| session 关联 case | 正文 footer `[case:<case_id>]` |
| 固定数值容差 | `config.evidenceTolerance` |
| 旧 proposals 路径 | `staging/proposals/<case_id>.md` |
| 分散审计路径 | `staging/audit/<case_id>.jsonl` |

## 13. 测试矩阵与验收

| 测试文件 | 当前用例数 | 主要覆盖 |
|---|---:|---|
| `handler.test.ts` | 36 | 五闸、工具守卫、结果改写回喂、fail-closed |
| `schema.test.ts` | 18 | Schema 与运行期形状护栏 |
| `fallback.test.ts` | 16 | 三分诊、回落、版本递增、异常阻断 |
| `report-claims.test.ts` | 13 | footer 和数字声明抽取 |
| `outbound.test.ts` | 11 | 审计、维度、容差和 cancel 映射 |
| `staging.contract.test.ts` | 10 | 待审提案落盘与路径安全 |
| `audit.contract.test.ts` | 13 | JSONL 追加、读取和最新版本语义 |

上述数字按当前测试文件统计，不等同于全仓测试总数。T6 已完成 ClawX node/web TypeScript 检查；`handler.test.ts` 36 项和 `outbound.test.ts` 11 项均通过，入站与出站定向测试合计 47 项。

修改 shared 出口后，必须先重建 shared 声明，再执行下游 typecheck 和 bundle，避免下游读取旧 `dist` 产生假报错。

## 14. 关键问题与修复结论

1. 生效校验从 before_tool_call 人审 `requireApproval` 修正为 execute 映射放行 + `tool_result_persist` 五闸改写回喂；人审移出 M2。
2. 出站 hook 统一为 `message_sending`，正文统一读取 `event.content`。
3. case_id 采用正文可见 footer，避免构造跨 hook 隐式状态。
4. 容差统一使用 `config.evidenceTolerance`。
5. 提案与审计统一归拢到 `staging/`。
6. 模块实现完成不等于运行时端到端接线完成，文档必须保留真实边界。

## 15. 当前边界与后续工作

M2 已完成 execute 语义→权重映射放行、`tool_result_persist` 五闸改写回喂、ClawX 三 hook 接线、`message_sending` 出站拦截，以及 APPLIED 审计读取和数字对账。

仍需后续补齐：

1. 在合法提案主链调用 `writeStagingProposal`，确保待审文件真实落盘。
2. 在主链接线 `tool_result_persist` 五闸与 `after_tool_call` 留痕，验证不过时改写结果确实回喂 LLM 重试。（人审适配层属 M3，不在 M2）
3. 明确工具执行、staging 状态与 APPLIED 审计之间的事务顺序。
4. 为完整链路补充端到端测试，而不只依赖模块契约测试。

## 16. 可复用模板总结

M2 将业务模式插件扩展成四段式合规回路：

```text
机器闸门（execute 后 tool_result_persist 校验）
  → 不过改写工具结果回喂 LLM 重试
  → 过则可追溯生效审计 + after_tool_call 留痕
  → 自然语言出口事实对账
```

后续业务插件应复用以下原则：中性决策与 hook 映射分层；execute 只映射放行、五闸在 `tool_result_persist` 校验并改写结果回喂；生效事实写入结构化、可版本化审计；出站报告只引用审计可证明的数字；无法解析、关联、读取或比对时统一 fail-closed；薄入口只接线，核心逻辑留在可独立测试和打包的 monorepo。

