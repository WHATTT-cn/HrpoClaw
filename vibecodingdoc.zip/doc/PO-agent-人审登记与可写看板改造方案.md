# PO Agent 改造方案：人审登记 skill + 可写数据看板

> 本文档面向「回退到 test 分支、FDE agent 改造代码已被清空」的场景，独立给出对 **PO agent** 复刻 FDE agent 两项能力的完整改造方案。阅读本文档无需依赖 FDE 现存代码——所有关键实现（人审触发链、可写看板）均在此重述。

---

## 一、背景与目标

FDE agent 改造中沉淀了两个可复用的交互能力：

| 编号 | 历史问题 | FDE 上的落地形态 |
| --- | --- | --- |
| 问题一 | 人审弹窗是否由大模型发起调用的工具触发？若是，写一条 skill 固化流程 | `record_maintenance` 工具 + `before_tool_call` 的 `requireApproval` 人审 + `maintenance-record-logging` skill |
| 问题二 | 参照只读看板做一个**支持数据修改**的看板（模型在对话中确认闭环后勾选新增一条记录并显示在看板） | `维修记录.json`（可写 JSON）+ `MaintenanceRecordDashboard`（读 JSON、可刷新） |

**目标**：在 PO agent 上复刻这两项能力，使 PO 从「只读指引 + 静态画像看板」升级为「可经人审写入结构化数据 + 可写数据看板」。

---

## 二、PO Agent 现状梳理

### 2.1 Agent 预置（`ClawX/electron/utils/agent-config.ts`）

- `PRESET_PO_AGENT_ID = 'po'`、`PRESET_PO_AGENT_NAME = 'PO'`。
- `ensurePresetPoAgent()`：幂等创建 `po` agent（`inheritWorkspace: true`），并调用 `ensurePresetPoExperienceFile()`。
- `ensurePresetPoExperienceFile()`：幂等把 `Experience.md`（HRBP 线下经验标签示例集）写入 `~/.openclaw/workspace-po/`；已存在则跳过。
- **PO 无任何 skill 预置、无 JSON 数据文件预置。**

### 2.2 插件（`ClawX/resources/openclaw-plugins/weights-guard/index.mjs`）

- `weights-guard`：**仅** `before_prompt_build` 纯指引注入（读《供应商画像.md》《Experience.md》并原文回显真实事实）。
- **不注册工具、不拦截 `before_tool_call`、不做人审。** 权限闸门链路完全缺失。

### 2.3 看板（`ClawX/src/pages/Chat/SupplierPortraitDashboard.tsx`）

- 数据来源 `src/data/supplier-portrait-table.ts`（硬编码 TS 字面量），**纯静态只读**。
- 按物流仓下拉切换 → 按供应商聚合 → 每行 `RowCard` 展示指标。
- 在 `Chat/index.tsx` 中按 `currentAgentId === PRESET_PO_AGENT_ID` 挂载到左半区。

### 2.4 与 FDE 的能力差距

| 能力 | FDE | PO 现状 |
| --- | --- | --- |
| 模型触发的写工具 | ✅ `record_maintenance` | ❌ 无 |
| `before_tool_call` 人审闸门 | ✅ `requireApproval` | ❌ 无 |
| 登记 skill | ✅ `maintenance-record-logging` | ❌ 无 |
| 可写数据文件 | ✅ `维修记录.json` | ❌ 仅静态 TS |
| 可写看板 | ✅ `MaintenanceRecordDashboard`（读 JSON + 刷新） | ❌ 静态只读 |

---

## 三、问题一改造：人审登记 skill（模型触发工具 → 人审弹窗 → 写库）

### 3.1 结论：人审弹窗确由大模型调用工具触发

人审触发链（FDE 已验证，PO 复刻同构）：

```
模型识别闭环 → 调用写工具(record_*) 
  → 插件 before_tool_call 钩子命中 isRecordTool 
  → handleBeforeToolCall 返回 { requireApproval } 
  → 前端弹出人审确认框 
  → 用户 allow → onResolution 回调写 JSON 
  → 用户 deny → 不写库
读工具(read_*) 只读不拦截；接线层异常一律 fail-closed（block，不放行）。
```

**关键点**：写入动作**不在** `execute` 里（execute 仅兜底回执），真正落库在 `before_tool_call → requireApproval.onResolution`，保证「未经用户确认绝不写库」。

### 3.2 PO 语义映射

PO 的业务闭环不是「维修记录」，而是「**用工决策定案**」。建议登记对象：一次已确认的用工分单决策（哪个物流仓、哪个供应商、承接人数/档级、决策依据）。字段建议：

| 字段 | 含义 |
| --- | --- |
| `decisionNo` | 决策单号（插件自动递增，如 `PO-2026-001`） |
| `date` | 决策日期 `YYYY-MM-DD` |
| `warehouse` | 物流仓 |
| `supplier` | 供应商 |
| `headcount` | 承接人数 / 档级 |
| `basis` | 决策依据（引用画像 + 经验库事实） |

> 字段可按实际业务调整；下方实现以此六字段为例。

### 3.3 新增插件 `po-decisions`（结构对齐 maintenance-records）

在 `ClawX/resources/openclaw-plugins/` 下新建 `po-decisions/`，接线层完全对齐 `maintenance-records/index.mjs`：

- `registerTool(record_decision)`：承载「登记一条用工决策」意图；`execute` 仅兜底回执（不落库）。
- `registerTool(read_decision)`：读取已有决策（无入参、不走人审、供查重）。
- `registerHook('before_prompt_build')`：注入指引，教模型识别决策闭环并调用工具。
- `registerHook('before_tool_call')`：拦截 `record_decision` → `requireApproval` 人审 → `onResolution` 写 `~/.openclaw/workspace-po/用工决策.json`；`read_decision` 与其他工具放行；异常 fail-closed。

薄入口 `index.mjs` 骨架（业务逻辑放 `handler.bundle.mjs`，与 maintenance-records 同构）：

```js
import { definePluginEntry } from "openclaw/plugin-sdk/core";
import { homedir } from "node:os";
import { readFile, writeFile, mkdir, access } from "node:fs/promises";
import { dirname } from "node:path";
import {
  handleBeforeToolCall, buildPromptInjection, resolveConfig,
  resolveDecisionPath, RECORD_TOOL_NAME, READ_TOOL_NAME, isRecordTool,
  RECORD_DECISION_PARAMETERS, READ_DECISION_PARAMETERS, readRecords,
} from "./handler.bundle.mjs";

const PLUGIN_ID = "po-decisions";
const docFs = {
  async readFile(p) { return readFile(p, "utf8"); },
  async writeFile(p, c) { await mkdir(dirname(p), { recursive: true }); await writeFile(p, c, "utf8"); },
  async exists(p) { try { await access(p); return true; } catch { return false; } },
};

export const pluginEntry = definePluginEntry({
  id: PLUGIN_ID,
  name: "PO Decisions",
  description: "Register workforce-allocation decisions with human approval.",
  register(api) {
    const config = resolveConfig(api?.pluginConfig);
    const decisionPath = resolveDecisionPath(homedir());

    api.registerTool({
      name: RECORD_TOOL_NAME, label: "登记用工决策",
      description: "把一次已确认的用工分单决策登记为决策记录；调用后弹人审确认框由用户决定是否入库。",
      parameters: RECORD_DECISION_PARAMETERS,
      async execute(_id, params) {
        return { content: [{ type: "text", text: "已收到用工决策登记请求，等待人工审批确认后写入看板。" }], details: { toolName: RECORD_TOOL_NAME, params } };
   },
    });

    api.registerTool({
      name: READ_TOOL_NAME, label: "读取用工决策",
  description: "读取已有全部用工决策，供模型查重。",
      parameters: READ_DECISION_PARAMETERS,
      async execute() {
        try {
       const records = await readRecords(docFs, decisionPath);
   const text = records.length ? `当前共有 ${records.length} 条用工决策：\n\n` + records.map(r => `决策单号: ${r.decisionNo}\n日期: ${r.date}\n物流仓: ${r.warehouse}\n供应商: ${r.supplier}\n承接: ${r.headcount}\n依据: ${r.basis}`).join("\n\n") : "暂无用工决策记录。";
          return { content: [{ type: "text", text }] };
    } catch (err) {
          return { content: [{ type: "text", text: `读取失败：${err instanceof Error ? err.message : String(err)}` }] };
        }
      },
    });

    api.registerHook("before_prompt_build", async () => {
      try { return buildPromptInjection(); } catch { return undefined; }
    });

    api.registerHook("before_tool_call", async (event) => {
      try {
        const toolName = event?.toolName;
        if (!isRecordTool(toolName)) return undefined;
        const result = handleBeforeToolCall({
       toolName, params: event?.params ?? {}, config,
          deps: { fs: docFs, filePath: decisionPath,
            onPersisted: (p, w) => console.log(`[po-decisions] 决策已${w ? "写入" : "命中幂等"}：${p.supplier}`),
       onError: (p, e) => console.error(`[po-decisions] 写入失败（${p.supplier}）：${e instanceof Error ? e.message : String(e)}`),
          },
   pluginId: PLUGIN_ID,
     });
  if (result?.block) return { block: true, blockReason: result.blockReason };
        if (result?.requireApproval) return { requireApproval: result.requireApproval };
     return undefined;
      } catch (err) {
        return { block: true, blockReason: `po-decisions 接线层异常，已拦截：${err instanceof Error ? err.message : String(err)}` };
   }
    });
  },
});

export default pluginEntry;
```

> `handler.bundle.mjs` 需导出：`RECORD_TOOL_NAME`/`READ_TOOL_NAME`/`isRecordTool`/`RECORD_DECISION_PARAMETERS`/`READ_DECISION_PARAMETERS`/`resolveConfig`/`resolveDecisionPath`/`readRecords`/`buildPromptInjection`/`handleBeforeToolCall`。可直接复制 maintenance-records 的 monorepo 源码改字段名与路径（`维修记录.json` → `用工决策.json`；工单号 `WO-240-xxx` → 决策单号 `PO-2026-xxx`）。
> **注意**：工具入参 `parameters` 走 TypeBox `TSchema`（非手写 JSON Schema），沿用 maintenance-records 的 schema 定义方式。

### 3.4 新增登记 skill（预置进 PO workspace）

在 `agent-config.ts` 中仿 `PRESET_FDE_MAINTENANCE_SKILL_*` 增加 PO 版：

- 常量 `PRESET_PO_DECISION_SKILL_SLUG = 'po-decision-logging'`。
- 常量 `PRESET_PO_DECISION_SKILL_CONTENT`：SKILL.md 模板串。frontmatter（`name`/`description`/`version`/`metadata.openclaw.skillKey` + `emoji`）+ 正文（触发条件三同时 / 作业步骤 / 铁律 / 边界）。
- `ensurePresetPoDecisionSkillFile()`：幂等写 `~/.openclaw/workspace-po/skills/po-decision-logging/SKILL.md`。
- 在 `ensurePresetPoAgent()` 的 **两个分支**（已存在分支 + 新建分支）都追加 `await ensurePresetPoDecisionSkillFile();`。

skill 正文要点（对齐 FDE `maintenance-record-logging`）：

1. **触发条件三同时**：① 决策三/四要素齐备（物流仓/供应商/承接人数/依据已确认）；② 用户明确要求登记；③ 先 `read_decision` 查重。
2. **作业步骤**：查重 → 组织字段（不编造决策单号，由插件递增）→ 调 `record_decision` → 等待人审（不能代点确认、不能声称已写入）→ 回执。
3. **铁律**：要素未确认不得登记；不得绕过人审；不编造单号与内容；与「决策指引」分离。

> **模板串反引号坑（务必注意）**：SKILL.md 模板串内要输出字面反引号（如 `` `read_decision` ``）时，**只需单个反斜杠转义** `` \` ``；写成双反斜杠 `` \\` `` 会导致 `\\` 变字面反斜杠、反引号提前闭合，`typecheck:node` 报一片 TS1005/TS1127 假错。

---

## 四、问题二改造：可写用工决策看板

### 4.1 与 FDE 看板同构

FDE `MaintenanceRecordDashboard` 关键设计（PO 复刻）：

- 固定路径常量 `MAINTENANCE_FILE_PATH = '~/.openclaw/workspace-fde/维修记录.json'`（支持 `~` 展开）。
- `readTextFile(path)` 读文件 → `parseRecords` 容错解析（非法/缺失一律回退空列表，绝不抛错阻断渲染）。
- 顶部「刷新」按钮手动重读（登记新记录后刷新即显示）；`useEffect` 首次加载。
- 每条记录 `RecordCard` 圆角卡片，`Field` 统一渲染。

### 4.2 新增 `SupplierDecisionDashboard.tsx`

在 `ClawX/src/pages/Chat/` 新建，读 `~/.openclaw/workspace-po/用工决策.json`：

```tsx
import { useCallback, useEffect, useState } from 'react';
import { RefreshCw, ClipboardList } from 'lucide-react';
import { readTextFile } from '@/lib/file-preview-client';

interface DecisionRecord {
  decisionNo: string; date: string; warehouse: string;
  supplier: string; headcount: string; basis: string;
}
interface DecisionsDoc { records: DecisionRecord[]; }

const DECISION_FILE_PATH = '~/.openclaw/workspace-po/用工决策.json';

function parseRecords(raw: string): DecisionRecord[] {
  try {
    const parsed = JSON.parse(raw) as Partial<DecisionsDoc> | null;
    if (!parsed || !Array.isArray(parsed.records)) return [];
    return parsed.records.filter(
      (r): r is DecisionRecord =>
        !!r && typeof r.decisionNo === 'string' && typeof r.supplier === 'string',
    );
  } catch { return []; }
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-0.5">
   <span className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</span>
      <span className="text-sm leading-relaxed text-foreground">{value || '—'}</span>
    </div>
  );
}

function RecordCard({ record }: { record: DecisionRecord }) {
  return (
<div className="rounded-xl border border-black/5 bg-black/[0.02] p-3 dark:border-white/5 dark:bg-white/[0.02]">
      <div className="mb-2 flex items-center gap-2">
        <span className="rounded-md bg-sky-500/10 px-1.5 py-0.5 text-[11px] font-medium text-sky-600 dark:text-sky-400">{record.decisionNo}</span>
        <span className="text-xs text-muted-foreground">{record.date || '日期未填写'}</span>
        <span className="text-xs text-muted-foreground">· {record.warehouse}</span>
      </div>
      <div className="space-y-2">
        <Field label="供应商" value={record.supplier} />
<Field label="承接人数/档级" value={record.headcount} />
     <Field label="决策依据" value={record.basis} />
      </div>
    </div>
  );
}

export function SupplierDecisionDashboard() {
  const [records, setRecords] = useState<DecisionRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
 const result = await readTextFile(DECISION_FILE_PATH);
      if (!result.ok || typeof result.content !== 'string') { setRecords([]); return; }
      setRecords(parseRecords(result.content));
  } catch (e) {
  setError(e instanceof Error ? e.message : '读取用工决策失败'); setRecords([]);
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { void load(); }, [load]);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="shrink-0 border-b border-black/5 px-4 py-3 dark:border-white/5">
     <div className="flex items-center justify-between">
          <h2 className="flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
<ClipboardList className="h-3.5 w-3.5" />
    用工决策看板
      </h2>
          <button type="button" onClick={() => void load()} disabled={loading}
    className="inline-flex items-center gap-1 rounded-md border border-black/10 bg-background px-2 py-1 text-[11px] font-medium text-foreground transition-colors hover:bg-black/5 disabled:opacity-50 dark:border-white/10 dark:hover:bg-white/10">
         <RefreshCw className={loading ? 'h-3 w-3 animate-spin' : 'h-3 w-3'} />
       刷新
    </button>
  </div>
        <p className="mt-2 text-[11px] text-muted-foreground">共 {records.length} 条决策 · PO 用工分单</p>
      </div>
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-4">
      {error && <div className="rounded-lg border border-red-500/30 bg-red-500/5 px-3 py-2 text-xs text-red-600 dark:text-red-400">{error}</div>}
    {!error && records.length === 0 && !loading && <p className="px-1 text-xs text-muted-foreground">暂无用工决策记录。</p>}
    {records.map((record, idx) => <RecordCard key={`${record.decisionNo}-${idx}`} record={record} />)}
  </div>
    </div>
  );
}

export default SupplierDecisionDashboard;
```

### 4.3 挂载策略（二选一）

PO 现在已被 `SupplierPortraitDashboard`（静态画像）占据左半区。两种方案：

- **方案 A（Tab 切换，推荐）**：在 PO 左半区加一个「画像 / 决策」Tab，`SupplierPortraitDashboard` 与 `SupplierDecisionDashboard` 并列，用户可切换查看。既保留画像只读，又新增可写决策看板。
- **方案 B（替换）**：直接把 PO 左半区换成 `SupplierDecisionDashboard`。简单但丢失画像看板。

`Chat/index.tsx` 挂载点（现有）：

```tsx
{currentAgentId === PRESET_PO_AGENT_ID && (
  <aside className="hidden w-1/2 shrink-0 border-r ... lg:flex lg:flex-col">
    <SupplierPortraitDashboard />   {/* 方案A：改为 Tab 容器同时含 SupplierDecisionDashboard */}
  </aside>
)}
```

### 4.4 种子数据预置（可选）

若希望看板首次即有内容，仿 FDE `ensurePresetFdeMaintenanceFile()` 在 `agent-config.ts` 增 `ensurePresetPoDecisionFile()`：幂等写 `~/.openclaw/workspace-po/用工决策.json`，根结构 `{ records: [...] }`，字段与看板/插件一致，并在 `ensurePresetPoAgent()` 两分支调用。已存在则跳过（避免覆盖插件追加的记录）。

---

## 五、改造清单（回退后可照此逐项施工）

### 5.1 后端 monorepo（`openclaw-guard-suite/plugins/po-decisions/`）

- [ ] 复制 `maintenance-records` 插件源码为 `po-decisions`，改字段名（维修三要素 → 决策六字段）、路径（`维修记录.json` → `用工决策.json`）、单号前缀（`WO-240-` → `PO-2026-`）、工具名（`record/read_maintenance` → `record/read_decision`）。
- [ ] `parameters` 保持 TypeBox `TSchema` 形式。
- [ ] tsup 打包出 `handler.bundle.mjs`。

### 5.2 ClawX 内建插件（`ClawX/resources/openclaw-plugins/po-decisions/`）

- [ ] 新建 `index.mjs` 薄入口（见 3.3）+ `openclaw.plugin.json`（描述 PO 决策登记 + 人审）。
- [ ] 放入打包好的 `handler.bundle.mjs`。
- [ ] 确认插件安装/加载路径把 `po-decisions` 纳入（对齐 maintenance-records 的注册方式，检查 `plugin-install.ts`）。

### 5.3 Agent 预置（`ClawX/electron/utils/agent-config.ts`）

- [ ] 增 `PRESET_PO_DECISION_SKILL_SLUG` + `PRESET_PO_DECISION_SKILL_CONTENT`（注意反引号单反斜杠转义）。
- [ ] 增 `ensurePresetPoDecisionSkillFile()`（幂等写 SKILL.md）。
- [ ] 可选增 `ensurePresetPoDecisionFile()`（幂等写种子 JSON）。
- [ ] 在 `ensurePresetPoAgent()` 两分支追加上述 `ensure*()` 调用。

### 5.4 前端看板（`ClawX/src/pages/Chat/`）

- [ ] 新建 `SupplierDecisionDashboard.tsx`（见 4.2）。
- [ ] `Chat/index.tsx` PO 挂载区按方案 A/B 接入（见 4.3）。

### 5.5 验证

- [ ] `pnpm typecheck:node` 通过（重点查 skill 模板串反引号转义）。
- [ ] 若改了 `shared` 出口，先重建 `shared/dist` 再 typecheck（guard-suite monorepo project references 陷阱）。
- [ ] 重启应用触发 `ensurePresetPoAgent()` 落盘 skill/种子到 `workspace-po`。
- [ ] 手测闭环：与 PO 对话确认一次用工决策 → 要求登记 → 模型调 `record_decision` → 弹人审 → allow → 刷新看板出现新条目；deny 则不写入。

---

## 六、两问协同关系

问题一（人审登记 skill）与问题二（可写看板）是**同一条数据管线的两端**：

- **写端（问题一）**：模型触发工具 → 人审闸门 → `onResolution` 写 `用工决策.json`。权限收敛在 `before_tool_call`，模型不能绕过用户直接写库。
- **读端（问题二）**：看板读同一个 `用工决策.json` → 刷新即见新记录。

两者靠**同一个 JSON 文件契约**（`{ records: [...] }` + 六字段）解耦：插件只管经人审写，前端只管读渲染，字段名对齐即可联通，无需前后端直接通信。这与 FDE 的 `维修记录.json` 完全同构，是可复用的「模型提议 → 人审 → 落库 → 看板」标准形态。