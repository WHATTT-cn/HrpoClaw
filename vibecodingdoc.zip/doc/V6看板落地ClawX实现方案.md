# V6 四板块 · ClawX 应用落地实现方案（已确认版）

> **本文定位**：`doc/供应商条件绩效画像表_V6口径梳理.md` 只解决「Excel 原始数据怎么清洗成四板块」的**数据逻辑**；
> 本文解决「四板块怎么进 ClawX 应用」的**工程落地**——真源归属、派生链路、产物矩阵、前端接线、Agent 契约。
> **状态**：✅ 已确认全部 10 项裁决（见 §7），进入实施阶段。

**关键裁决摘要**：
- 周期：月桶 + 预设周期档（体量×8，后续可升级任意日期）
- 跨仓人头：同一周期内员工不跨仓（去重人头跨仓 Σ 可行）
- 板块三：物流仓**单选**（EB/Wilson/档级依赖样本基准）
- Agent 侧：**暂缓切换**，先只改看板（P5 推后，避免分单能力断层）
- 履约 Tab：**移除用工决策台账**，保留 PO 日记，板块四入职数据在日历上以事件显示
- 旧链路：**直接下线**（供应商画像.json / 旧 Suppliers.md / v5 JSON 全部退役）
- Python：开发机离线跑，产物提交 Git（暂不进 `pnpm build`）
- 入库：仅 `src/data/v6/*.json` 进 Git，Excel 与产出 xlsx 全部 `.gitignore`
- 目录：统一保留 `scripts/v6/`，移除 `data/v6/*.py` 镜像
- 口径：先按默认值跑通，后续再裁决 21 项细节

---

## 1. 现状基线（改造前）

### 1.1 三条既有数据链路

| 链路 | 真源 | 派生脚本 | 产物 | 消费方 |
|---|---|---|---|---|
| **A · 供应商画像** | `src/data/迪拜8仓…v5_2026-01_08.json`（业务侧产出）<br>`src/data/supplier-portrait-table.ts` 仅类型标注+转发 | `weights-guard/scripts/gen-portrait-md.mjs`<br>`pnpm --filter weights-guard gen:portrait` | ① `workspace-po/Suppliers.md`<br>② `workspace-po/供应商画像.json`<br>③ `ClawX/shared/po-supplier-portrait.json` | `SupplierPortraitDashboard`<br>`RegionHealthDashboard`<br>weights-guard agent |
| **B · 用工决策** | `src/data/supplier-decision-table.ts`（手写字面量） | `ClawX/scripts/gen-decisions.mjs`<br>`pnpm gen:decisions` | ① `workspace-po/用工决策.json`<br>② `ClawX/shared/po-supplier-decisions.json` | `SupplierDecisionDashboard`<br>po-decisions 插件 |
| **C · PO 日记** | 无真源（用户界面录入） | 无 | `workspace-po/PO日记.json` | `SupplierDecisionDashboard` 内嵌 |

**两种真源模式并存**：
- **模式 A（数据型）**：外部产出 JSON → TS 只做类型标注与转发 import → 脚本读 JSON 派生。
- **模式 B（手写型）**：TS 内写字面量 → 脚本用 `typescript.transpileModule` 动态 import TS → 派生。

> V6 是纯机器产出的大体量数据，**必须走模式 A**（模式 B 只适合几十行手写记录）。

### 1.2 四个必须同步改动的接线点

1. **前端 Tab**：`src/pages/Chat/index.tsx:56` `PoDashboardTab = 'region' | 'portrait' | 'decision'`，默认 `'region'`。
2. **运行时读取**：三看板均用 `readTextFile('~/.openclaw/workspace-po/*.json')` 实时读（非构建期快照），带刷新按钮。
3. **Electron 预置**：`electron/utils/agent-config.ts` 的 `ensurePresetPo{Portrait,Decision,Diary}File()` —— **幂等兜底**（已存在则跳过），刷新靠重跑 gen 脚本覆盖。
4. **Agent 契约**：`agent-config.ts` 的 PO agent prompt + `po-dashboard-analysis` skill，均声明「必须基于 `Suppliers.md` 真实数值，禁止编造」。

### 1.3 前端已具备的能力（可直接复用，不用重造）

- 多选层级筛选：`LevelFilter` + `生效选项()`（空选=全选）+ `toggle()`。
- 实时聚合：`RegionHealthDashboard.tsx:85` `加权均值()`（以 `样本人数` 为权重）。
- 容错解析：`parsePortrait()` 结构不符回退空表，绝不崩溃。
- 空值语义：`num()` 把 `null` 渲染为「—」——**与 V6「占位字段禁止显示为 0」的铁律天然一致**。

---

## 2. 目标架构（改造后总链路）

```
【离线加工层 · Python，开发机执行，不随应用分发】
  data/v6/*.xlsx (3 个原始 Excel, 40MB)
        │  scripts/v6/{common,board1..4,metric_dict}.py
        ▼
  run_all.py  ──┬─→ data/v6/out/*.xlsx        （43 个，人工审阅/交付用，不进应用）
                └─→ ClawX/src/data/v6/*.json  （★真源数据文件，进 Git）

【真源层 · TS，唯一数据更新入口】
  ClawX/src/data/v6-board-table.ts
    · 类型标注（引 TypeBox schema 的 Static 类型）
        · 转发 import 上述 JSON
        · 前端专属映射（仓库层级表：洲际/片区/物流仓）
  ClawX/src/data/v6/schema.ts  （由 doc/v6_board_schema.ts 迁入，TypeBox 契约）

【派生层 · gen 脚本，一条命令全量覆盖】
  ClawX/scripts/gen-v6-boards.mjs   (pnpm gen:v6)
        ├─→ workspace-po/区域健康.json    （板块一+二）
        ├─→ workspace-po/采购下单.json    （板块三）
        ├─→ workspace-po/履约追踪.json    （板块四）
        ├─→ workspace-po/Suppliers.md     （★agent 权威表，见 §3.5）
        └─→ ClawX/shared/po-v6-*.json     （electron 预置种子）

【应用层】
  Electron ensurePresetPoV6Files()  幂等兜底首次写入
  区域健康看板 ← 区域健康.json    （板块一 KPI + 板块二供应商表）
  采购下单看板 ← 采购下单.json    （板块三条件组卡片）
  履约追踪看板 ← 履约追踪.json    （板块四入职台账）+ 用工决策.json + PO日记.json
  PO agent     ← Suppliers.md      （只读权威表）
```

**核心不变量**（你要求保持的映射关系，本方案完整保留）：
> TS 真源是唯一数据更新入口 → 一条 gen 命令全量派生 → 看板 json（运行时读）+ 工作区 md（agent 读）+ shared 种子（预置兜底）。
> Python 只是把「业务侧手工产出 JSON」这一步换成了「脚本自动产出 JSON」，**真源层与派生层的契约完全不变**。

---

## 3. 关键设计决策

### ★D1 · Python 与 TS 真源的衔接点

| 选项 | 做法 | 评价 |
|---|---|---|
| 甲（**推荐**） | Python 产出 JSON 落进 `src/data/v6/`；TS 只做类型标注+转发 | **与链路 A 现状完全同构**，零新范式；JSON 进 Git 可 diff 可回滚；应用侧不依赖 Python |
| 乙 | Python 直接生成 `.ts` 文件 | 生成的 TS 巨大且不可手改，破坏「TS 真源」语义 |
| 丙 | 前端直接读 `data/v6/out/json/` 44 个文件 | 绕过 TS 真源，违反你的不变量约束 |

**取甲。** Python 的定位是「**离线数据加工**」：开发机跑一次，产物提交进仓库；**终端用户机器不需要 Python/pandas，Excel 也不随应用分发**。

### ★D2 · 切片爆炸 vs 交互筛选（本方案最关键的技术决策）

**矛盾**：V6 `run_all.py` 按「2 周期 × 7 范围」预生成 43 个切片文件；但看板筛选器是「周期范围 + 物流仓**多选**」——物流仓多选有 2⁷−1 = 127 种组合，周期若允许任意起止日期则组合无穷。**预生成全部切片不可行。**

**解法：Python 产出「最细粒度可加事实表 + 多粒度人头附表」，前端按筛选器实时重算。**

依据：`RegionHealthDashboard` 已在做前端实时聚合，这是既有范式的自然延伸。

**指标可加性分类**：

| 类别 | 指标 | 前端处理 |
|---|---|---|
| **可加**（直接 Σ） | 考勤工时、加班工时、计划出勤人次、出勤人次、考勤异常人次、异常已处理人日、异常待处理基数、窗口内离职人数、期末在职人数、入职总人数、30/90天留存人数 | Σ 后即得 |
| **比率**（由可加分子分母现算） | 出勤率、考勤异常率、加班工时占比、异常处理进度、离职率、三方员工占比、30/90天留存率、供给占比 | 先 Σ 分子分母再相除，**不可对比率做平均** |
| **结构型**（由 by供应商 人头重算） | 活跃供应商数量/名单、头部供应商数量/占比/名单、CR3集中度、最大单家供给占比 | 对聚合后的供应商人头排序重算 |
| **不可加 ①去重人头** | 供给人数、出勤人数、考勤异常人数 | 见下方「人头附表」 |
| **不可加 ②峰值** | 历史最大供给量（全历史日在职峰值） | 见下方「峰值处理」 |
| **不可加 ③统计量** | 档级、EB 收缩出勤率、Wilson 区间宽、置信度 | 见下方「板块三特判」 |

**去重人头 —— 多粒度人头附表**：同一员工可能跨条件组（换班次/工种），跨条件组求和会重复计数。故 Python **按各聚合层级分别预计算人头**，前端按当前筛选层级取对应值：
- `人头_周期×仓`、`人头_周期×仓×供应商`、`人头_周期×仓×供应商×条件组`
- 跨仓合并时直接 Σ —— **前提假设：同一员工在同一周期内不跨仓**（★A1 需验证，见 §7）。若不成立，需追加 `人头_周期×多仓组合` 或改用员工 ID 位图。

**峰值处理**：历史最大供给量按「仓×供应商」预算好；跨仓 Σ 是**上界近似**（各家峰值不同日），V6 schema 已注明此语义，前端需加脚注说明。

**板块三特判**：档级/EB/Wilson/置信度依赖切片样本量 n，必须在**最终展示粒度**上算。板块三筛选器是**物流仓单选**，组合数 = 仓数 × 周期档数，**可以预生成**。故板块三走「预生成切片」，板块一/二/四走「事实表实时重算」。

### ★D2-b · 周期粒度：与现有区域健康看板的处理逻辑对比

**先说结论：现有区域健康看板根本没有「周期」这个维度。** 这不是「换一种周期筛选方式」，而是**从零新增一根时间轴**。

#### 现状逐条拆解（`RegionHealthDashboard.tsx`）

| 方面 | 现有做法 | 证据 |
|---|---|---|
| **周期从哪来** | 不存在周期筛选器。周期被**烘焙进文件名**：`迪拜8仓供应商条件绩效画像表_v5_2026-01_08.json`，整份数据 = 2026-01~08 这一个固定窗口的成品快照 | `supplier-portrait-table.ts:15` |
| **换周期怎么办** | 换整个真源 JSON 文件 + 改一行 import + 重跑 `gen:portrait`。**属于发版行为，不是用户交互** | `supplier-portrait-table.ts:4-5` 注释明写「换版本时替换 JSON 并改下面这一行 import」 |
| **筛选器只有什么** | 洲际 / 片区 / 物流仓 三级，**全是空间维度** | `RegionHealthDashboard.tsx:388-412` |
| **数据行的粒度** | `画像行` = 供应商 × 工种 × 班次 × 用工性质 × 技能等级 × 量档。**没有任何日期/月份字段** | `supplier-portrait-table.ts:13` 注释定义的唯一键 |
| **比率怎么聚合** | `加权均值()`：对**成品比率**按 `样本人数` 加权平均 | `RegionHealthDashboard.tsx:85` |

#### 三个必须正视的差异

**差异 1 · 周期从「发版参数」变成「交互参数」**

现在：周期是**构建期常量**，用户在界面上无法改变，一份文件一个周期。
V6 后：周期是**运行期变量**，用户点一下就要换一套数值。

这才是 Q1 的真正含义 —— 不是「下拉 vs 日期选择器」哪个好看，而是**要不要引入这根时间轴、以及它的最小刻度是多少**。现有架构在这件事上没有任何可复用的先例。

**差异 2 · 聚合数学从「加权平均近似」升级为「分子分母精确重算」**

现有 `加权均值()` 是在对**已经算好的比率**做加权平均：

```
现有：考勤率_区域 ≈ Σ(考勤率_行 × 样本人数_行) / Σ样本人数_行
V6 ：出勤率_区域 = Σ出勤人次 / Σ计划出勤人次      （精确）
```

当 `样本人数` 恰好等于该比率的真实分母时两者等价；一旦不等（如 `离职率` 的分母是期末在职人数、`人效` 的分母是人天而非人数），现有算法就是**有偏近似**。

V6 方案下发可加的分子分母原子量，聚合结果**严格精确**。这是升级不是降级——但也意味着 `加权均值()` 这个函数在 V6 板块一/二中**不再适用**，需要换成 `Σ分子 / Σ分母` 的新聚合器。

**差异 3 · 现有代码已存在一处口径缺陷，V6 必须修正**

```ts
// RegionHealthDashboard.tsx:330 及 355
供给能力: 真实行.reduce((s, 行) => s + 行.历史最大供给量, 0)
```

这是把**同一供应商在不同条件组（工种/班次/技能等级/量档）上的历史峰值直接相加**。同一批人换个班次就被重复计一次峰值，结果系统性高估区域供应能力上限。V6 的「历史最大供给量」按「仓×供应商」预算好，正是为了避免这个问题——**迁移时必须改掉这段 reduce**，不能照搬。

（对照：同一段代码里 `供应商数` 用 `new Set(...)` 去重是对的，说明作者意识到了行级重复问题，只是漏了峰值字段。）

#### 建议方案

**事实表以「自然月」为最小周期桶，筛选器给预设周期档 + 可选的「自定义月份区间」。**

| 选项 | 体量 | 可 Σ 性 | 离职率期末法 | 评价 |
|---|---|---|---|---|
| **月桶（推荐）** | ×8（2026-01~08） | 分子分母均可跨月 Σ | 需额外下发每月期末在职快照 | 体量可控，覆盖绝大多数分析诉求 |
| 日桶 | ×240，放大 30 倍 | 可 Σ | 同样需每日期末快照 | 事实表行数 = 条件组数 × 240，JSON 体积与前端聚合开销均不可接受 |
| 不分桶（照搬现状） | ×1 | — | — | 等于没有时间轴，不满足 V6 诉求 |

**离职率的特殊处理**：「期末法」的分母是**窗口期末在职人数**，不是月份分母的和。故月桶事实表需额外携带 `期末在职人数_每月`，跨月合并时**取区间最后一个月的值**（而非 Σ）。这条规则必须在前端聚合器里显式编码，否则会算错。

**若你确需任意起止日期**：需在 Python 侧改为按日建表，并接受 ①JSON 体积膨胀 30 倍 ②期末在职需按日快照 ③前端聚合从「最多 8 个桶相加」变成「最多 240 个桶相加」。技术上可行，但收益/成本比明显更差，除非业务确实要看「某月 5 号到次月 12 号」这类非自然月区间。

### ★D3 · 产物矩阵（每板块 Excel + TSchema 两种格式）

| 产物 | 路径 | 格式 | 用途 | 是否进 Git |
|---|---|---|---|---|
| 交付 Excel | `data/v6/out/*.xlsx` | xlsx（数据 Sheet + 指标口径 Sheet） | 人工审阅、业务交付 | ★D3-a 待定 |
| 真源 JSON | `ClawX/src/data/v6/*.json` | JSON | TS 真源转发对象 | 是 |
| TSchema 契约 | `ClawX/src/data/v6/schema.ts` | TypeBox | 类型 + 运行时校验 | 是 |
| 看板 JSON | `workspace-po/{区域健康,采购下单,履约追踪}.json` | JSON | 看板运行时读 | 否（运行时产物） |
| Agent MD | `workspace-po/Suppliers.md` | Markdown | agent 只读权威表 | 否 |
| 预置种子 | `ClawX/shared/po-v6-*.json` | JSON | electron 首启兜底 | 是 |

`doc/v6_board_schema.ts` 现在只是文档，**需迁入工程**成为真正的编译期类型 + 运行时校验源：gen 脚本用 `Value.Check()` 校验后才落盘，前端解析时二次校验，防止口径漂移静默污染看板。

### ★D4 · gen 脚本编排

新增 `ClawX/scripts/gen-v6-boards.mjs`，`pnpm gen:v6`：
1. 读 `src/data/v6-board-table.ts`（模式 B 的 transpile 方式，兼容 TS 内的层级映射表）或直接读 JSON（模式 A）；
2. TypeBox 全量校验；
3. 派生 3 个看板 JSON + `Suppliers.md` + 3 个 shared 种子；
4. **原子写入**（先写 `.tmp` 再 `rename`，复刻 `gen-decisions.mjs` 做法，避免看板读到半截 JSON）；
5. 打印行数统计与断言结果。

Python 侧保留 `run_all.py` 的 119 条断言，并**新增一条 CI 级校验**：真源 JSON ↔ TypeBox schema 双向对账零偏差。

### ★D5 · 三看板与四板块的映射及组件改造强度

| 看板 Tab | 承载板块 | 现有组件 | 改造强度 |
|---|---|---|---|
| 区域健康 `region` | 板块一（1 行 KPI）+ 板块二（供应商表） | `RegionHealthDashboard.tsx` | **中**：筛选器保留，KPI 区重写（35 字段），新增板块二表格区 |
| 采购下单 `portrait` | 板块三（条件组 × 供应商） | `SupplierPortraitDashboard.tsx` | **大**：仓从「多选」改「**单选**」，字段全换（见 §3.6），新增档级/置信度/EB 标识 |
| 履约追踪 `decision` | 板块四（入职台账） | `SupplierDecisionDashboard.tsx` | **大**：★D5-a 板块四与现有「用工决策+PO日记」是**并存还是替换**？三者语义完全不同 |

`仓库层级表`（`supplier-portrait-table.ts:107`）当前**只登记了 1 个仓**，V6 覆盖 **6 个实仓 + 未知**，必须补齐 5 行，否则新仓全部落入「未分区」。
**利好**：V6 仓名（`阿联酋迪拜定制8号仓`）与看板展示名一致，旧真源的 `迪拜定制8号仓` ↔ 展示名错位问题**自动消失**，`真源物流仓` 字段可退化。

### ★D6 · 字段口径断层（**业务影响最大，务必确认**）

板块三虽在「条件组 × 供应商」粒度上对标旧画像表，但**关键字段全变**：

| 旧画像行 | V6 板块三 | 影响 | **P6 落地后状态** |
|---|---|---|---|
| 考勤率 | 出勤率 | 改名，语义相近 | ✅ 实算 |
| 供给率 | 供给满足率 | 需求台账未接入 | ✅ **业务方指定常量 100%**（非实算） |
| 到岗天数 | 供给时效 | 需求台账未接入 | ✅ **业务方指定分桶**（板块一/二 14 天；板块三按需求量桶 7/14/30；板块四按入职总人数套同桶） |
| 人效 | **件效**（人效字段废弃） | 产量数据未接入 | ✅ **按仓写死常量**，5 号仓/未知仓 null |
| 价格 | 价格 | 价卡未接入 | ✅ **价卡实算**，仅 8 号仓有值，其余 5 仓 null |
| 历史最大供给量 | 仅板块二有（板块三无） | ⚠️ 下沉粒度不同 | 未变 |
| — | 新增 考勤异常率、档级、置信度、区间宽度pp | 新能力 | ✅ 实算 |

**原后果（已消除）**：PO agent 的「合理用工数」「供应商分单」两大核心任务，其算法依赖 **价格（求综合成本）、件效（任务量→用工数换算）、供给率（超额下单抵缺口）、历史最大供给量（分单上限）** —— 四项已于 P6/P6″ 全部接入，§D6 口径断层已全部消除（余下仅静默供应商两项占位，不参与上述算法）。

#### ★D6 裁决结论（已定，P6 已落地）

| 议题 | 裁决 | 口径 |
|---|---|---|
| **价格数据源** | 接入 `data/v6/价卡/` 12 个 GJ xlsx（未编码的 1 家忽略） | 价格键粒度 `(供应商, 工种)`；双向工种归一 `PRICE_JOB_ALIAS`；单位 **AED/人·小时** |
| **价格仓码映射** | **A 保守口径** | 只取 `C0080000051` 给 8 号仓，其余 5 仓 **null**；与 V5 一致，零推断风险 |
| **供给满足率** | 业务方指定**恒 100%** | `common.py::supply_rate_of()` ↔ `v6-board-table.ts::供给满足率常量` **双侧同源**，台账接入后须同步下线 |
| **人效** | **字段废弃**，原逻辑并入件效 | 板块三不再输出 `人效` 列 |
| **件效常量** | 按仓写死 | 1号 24.27 / 2号 29.38 / 3号 29.38 / 4号 56.87 / 6号 27.15 / 7号 0 / 8号 21.92 |
| **件效缺口 + 单位** | **A** | 5 号仓与「未知」仓 **null**（标注未给值）；4/7 号仓常量**保留作扩仓预留**；单位 **AED/人·小时** |

**空值归因机制**：新增 `common.py::data_status_of(wh, fields, extra)`，按白名单裁剪字段生成「表级 null 原因」文案；行级 null（8 号仓内不在价卡的供应商）由前端 tooltip 追加「本行价卡未覆盖」说明。
**指标字典状态枚举**扩为 5 类：`_OK 已实算` / `_AUX 中间量` / `_PH 无数据源-占位` / `_BIZ 业务方指定常量` / `_D4 价卡实算`。

---

## 4. 各板块落地细则

### 4.1 板块一 → 区域健康 Tab（上半区 KPI）

- **数据形态**：整体 1 行 × 35 字段。改造后由前端从事实表实时聚合得出，不再是静态一行。
- **筛选器**：周期档（下拉）+ 物流仓（多选，沿用 `LevelFilter`）。
- **分区**：① 供给规模（供给人数/历史最大供给量/活跃供应商数/CR3/头部）② 出勤履约（出勤率/人次/工时）③ 异常与加班（异常率/处理进度/加班占比）④ 稳定性（离职率/三方占比）⑤ **业务常量与待接入指标**（供给满足率显实值 100%、供给时效显实值 `14 天`，均附「业务方指定常量」hint；仅静默供应商/价格/件效仍显「—」）。
- **空值铁律**：`null` 必须渲染为「—」或「暂无数据」，**绝不显示 0**（`num()` 已具备此行为）。

### 4.2 板块二 → 区域健康 Tab（下半区供应商表）

- **数据形态**：by 供应商，N 行 × ~25 字段，含供给占比、CR3 贡献、是否头部。
- **交互**：默认按供给人数降序；头部供应商加徽标；行点击可下钻到板块三同供应商（★D5-b 是否要做下钻联动，待定）。
- **聚合**：跨仓多选时按供应商 Σ 可加字段，人头取 `人头_周期×仓×供应商` 再按「不跨仓」假设 Σ。

### 4.3 板块三 → 采购下单 Tab

- **数据形态**：by 条件组（仓×供应商×工种×班次…）。
- **★关键差异**：筛选器为**物流仓单选**（因 EB/Wilson/档级依赖切片内样本量，跨仓合并会改变统计基准）。
- **预生成**：`采购下单.json` 内按 `{仓, 周期档}` 为 key 组织切片数组，前端按筛选取对应切片，不做二次聚合。
- **展示**：条件组卡片 + 档级徽标（①细/②粗/②粗+EB/④基准）+ 置信度（高/中/低）+ 区间宽度 pp；极低置信度行默认折叠。
- **字段口径（P6/P6″ 已落地）**：供给满足率显实值 100%（hint「业务方指定常量」）；价格取价卡实算，非空时附 `价格单位`（AED/人·小时），为 null 时**不渲染单位**并在 tooltip 追加「本行价卡未覆盖」归因；件效显按仓常量；**供给时效按所在需求量桶显实值** `7/14/30 天`，hint 标注所属桶区间 —— 四项口径字段已全部有值。
- **空切片**：V6 已定义 `Board3EmptyPlaceholderRowSchema`，前端需识别并渲染空态提示（而非空白）。

### 4.4 板块四 → 履约追踪 Tab（✅ A5 已定：决策台账下线，入职数据进日历）

- **数据形态**：入职记录主表（by 供应商/仓 聚合）+ 明细行（员工级，含入职日期）。
- **指标**：入职总人数、30/90 天留存人数与留存率、三方员工占比。

**Tab 结构改造（依 A5）**：

| 原有内容 | 处置 | 说明 |
|---|---|---|
| `PoDiaryCalendar`（PO 日记，可写） | **保留，升级为主体** | 日历成为履约追踪 Tab 的核心载体 |
| 用工决策台账（`RecordCard` 列表） | **移除** | 连带下线 `用工决策.json` 全链路，见 §4.7 |
| 板块四入职留存 | **新增，挂到日历上** | 按入职日期聚合为**日历事件** |

**入职事件挂载设计**：

板块四明细行含员工级入职日期，按日期聚合后注入日历：

```
日历单元格（某日）
  ├─ PO 日记条目（原有，用户手写，可写）
  └─ 入职事件（新增，只读，派生自板块四）
       徽标：「入职 12 人」
       点击展开：按供应商/仓分组的明细
                 + 该批次 30/90 天留存追踪状态
```

**关键设计点**：
1. **读写隔离**：日记是可写运行时数据（`PO日记.json`），入职事件是只读派生数据（`履约追踪.json`），**两份文件独立读取、独立刷新**，不得合并写入——否则重跑 gen 会冲掉用户手写日记。
2. **视觉区分**：入职事件需与日记条目在样式上明确区分（建议入职事件用只读徽标样式，不可点击编辑）。
3. **留存追踪的时间语义**：某日入职批次的 30/90 天留存率，其观测窗口可能**超出当前筛选周期**。需明确：留存率随批次固定（入职时点决定），不随筛选周期变化；若观测窗口未满 30/90 天，显示「追踪中」而非 0。
4. **日历跨月**：板块四覆盖 2026-01~08，日历需支持月份切换并在有入职事件的月份给出提示。

### 4.7 用工决策链路下线清单（依 A5 + A6）

A5 要求移除用工决策台账，A6 要求旧链路直接下线。两者合并后需退役的资产：

| 资产 | 类型 | 处置 |
|---|---|---|
| `src/data/supplier-decision-table.ts` | TS 真源 | 删除（类型 `DecisionRecord`/`DecisionsDoc` 若无他处引用一并删） |
| `scripts/gen-decisions.mjs` | gen 脚本 | 删除 |
| `package.json` 的 `gen:decisions` | 脚本入口 | 删除 |
| `shared/po-supplier-decisions.json` | 预置种子 | 删除 |
| `ensurePresetPoDecisionFile()` | electron 预置 | 删除 |
| `~/.openclaw/workspace-po/用工决策.json` | 运行时产物 | 停止生成（已存在的用户文件不主动删，自然废弃） |
| `resources/openclaw-plugins/po-decisions/` | 插件 | ⚠️ **需确认**：`read_decision` 工具若被 agent prompt 引用，下线会导致工具调用失败。见 §7 后续待确认 F1 |
| `SupplierDecisionDashboard.tsx` 的 `RecordCard`/`parseRecords`/`load` | 前端 | 删除，组件重写为「日历 + 入职事件」 |

**旧画像链路（依 A6）同步下线**：

| 资产 | 处置 |
|---|---|
| `src/data/迪拜8仓…v5_2026-01_08.json` | 删除 |
| `src/data/supplier-portrait-table.ts` | 删除，但 **`仓库层级表` 与 `未分区标签` 需迁移**到 `v6-board-table.ts`（层级映射是前端专属知识，V6 JSON 里没有） |
| `weights-guard/scripts/gen-portrait-md.mjs` | 删除 |
| `gen:portrait` 脚本入口 | 删除 |
| `shared/po-supplier-portrait.json` | 删除 |
| `ensurePresetPoPortraitFile()` | 删除 |
| `~/.openclaw/workspace-po/供应商画像.json` | 停止生成 |
| `~/.openclaw/workspace-po/Suppliers.md` | ⚠️ **P5 推后前不能删**，见 §4.8 |

### 4.8 A4 与 A6 的冲突处理（重要）

**冲突**：A4 说「暂缓 agent 侧切换」，A6 说「旧链路直接下线」。但 agent 当前正是靠旧链路产物 `Suppliers.md` 工作的——若立刻删掉旧链路，agent 会失去唯一数据源，等于被动切换，与 A4 矛盾。

**解法：按「产物」而非「链路」分阶段下线。**

| 阶段 | 旧链路代码 | `Suppliers.md` | Agent 状态 |
|---|---|---|---|
| **P1–P4（看板改造期）** | 保留 `gen-portrait-md.mjs` 但**只生成 `Suppliers.md` 一项**，停掉 `供应商画像.json` 与 shared 种子两项产物 | 保留（v5 口径） | 正常工作，能力无损 |
| **P5（agent 切换）** | 完全删除 | 由 `gen-v6-boards.mjs` 重新生成（V6 口径） | 按 §3 D6 结论处理 |

即：**P1 阶段把 `gen-portrait-md.mjs` 从「三产物」裁剪为「单产物」**，只保留 agent 赖以工作的 md，前端消费的两项立刻切到 V6。这样看板与 agent 解耦推进，互不阻塞。

> 若你希望更彻底（P1 就删干净、接受 agent 临时失能），可覆盖此处安排——但那实质是 A4 选 (a) 而非 (c)。

### 4.5 指标字典的落地

V6 的 `metric_dict` 是各板块字段的口径说明。建议双投放：
- **Excel**：作为每个 xlsx 的「指标口径」Sheet（交付用）。
- **应用**：生成 `workspace-po/指标口径.md`，并在看板字段名旁挂 `?` tooltip 读取同一份口径文本 —— 保证「看板显示什么」与「agent 理解什么」同源。

### 4.6 Suppliers.md 的重构（Agent 侧）

现 `Suppliers.md` 是「单表 + 字段释义 preamble」。V6 后建议改为**分节权威表**：

```
# 供应商权威数据表（V6 · 自动生成，勿手改）
## 0. 字段口径与禁用项      ← 明示 null 字段不得参与计算
## 1. 区域整体健康（板块一）
## 2. 供应商维度（板块二）   ← 含历史最大供给量，分单上限依据
## 3. 条件组绩效（板块三）   ← 含档级/置信度，agent 需按置信度加权
## 4. 入职与留存（板块四）
```

**必须同步修改**：`agent-config.ts` 内 PO agent 的 prompt 字段清单、`po-dashboard-analysis` skill 的读取指引、weights-guard 的权重校验规则（若其引用了价格/人效字段）。

---

## 5. 改动清单（文件级）

| # | 文件 | 动作 |
|---|---|---|
| 1 | `scripts/v6/` ← `data/v6/` 镜像收敛 | **删除重复**，统一保留 `scripts/v6/`；Excel 留在 `data/v6/` 并在 `.gitignore` 中排除大文件（★D3-a） |
| 2 | `scripts/v6/export_app_json.py` | **新增**：把事实表+人头附表+板块三切片写入 `ClawX/src/data/v6/*.json` |
| 3 | `ClawX/src/data/v6/*.json` | **新增**（Python 产物，进 Git） |
| 4 | `ClawX/src/data/v6/schema.ts` | **新增**：由 `doc/v6_board_schema.ts` 迁入 |
| 5 | `ClawX/src/data/v6-board-table.ts` | **新增**：类型标注 + 转发 import + 仓库层级表（补齐 6 仓） |
| 6 | `ClawX/scripts/gen-v6-boards.mjs` | **新增**：派生 3 看板 json + Suppliers.md + 3 种子 |
| 7 | `ClawX/package.json` | 加 `gen:v6` 脚本 |
| 8 | `ClawX/shared/po-v6-*.json` | **新增**：预置种子 |
| 9 | `ClawX/electron/utils/agent-config.ts` | 新增 `ensurePresetPoV6Files()`；修改 PO agent prompt 字段清单 |
| 10 | `RegionHealthDashboard.tsx` | 重写 KPI 区 + 新增板块二表格 |
| 11 | `SupplierPortraitDashboard.tsx` | 重写为板块三（仓单选 + 档级/置信度） |
| 12 | `SupplierDecisionDashboard.tsx` | 新增板块四段落（保留原两段） |
| 13 | `po-dashboard-analysis` skill | 更新字段与口径指引 |
| 14 | 旧链路 | ★D7：`supplier-portrait-table.ts` / `gen-portrait-md.mjs` / v5 JSON 是**保留兼容**还是**下线**？ |

---

## 6. 分阶段落地顺序（每阶段可独立验证与回滚）

| 阶段 | 内容 | 验收 | 回滚点 |
|---|---|---|---|
| **P0** | 口径裁决（§7 全部问题）+ Python 侧补 `export_app_json.py`，先跑通产出 `src/data/v6/*.json` | JSON 存在、断言 PASS、schema 校验通过 | 纯新增文件，删除即回滚 |
| **P1** | `schema.ts` + `v6-board-table.ts` + `gen-v6-boards.mjs`，跑 `pnpm gen:v6` | 3 个看板 json 与 Suppliers.md 生成、字段齐全 | 不触碰前端，旧看板照常工作 |
| **P2** | 区域健康 Tab 接板块一+二 | 筛选器跨仓聚合数值 与 Python 预生成切片 逐字段对账一致 | 单组件回退 |
| **P3** | 采购下单 Tab 接板块三 | 档级/置信度展示正确、占位字段显「暂无数据」不显 0 | 单组件回退 |
| **P4** | 履约追踪 Tab 加板块四段落 | 入职留存数值对账一致，原有决策/日记功能不受影响 | 移除新段落 |
| **P5** | Agent 侧：prompt + skill + Suppliers.md 结构切换 | agent 分单任务可正常完成（依赖 §7 Q4 的结论） | 恢复旧 Suppliers.md |
| **P6** | 旧链路下线或标记 deprecated | 无残留引用 | — |

**P2 的对账是整个方案的质量闸门**：前端实时聚合结果必须与 Python 预生成切片逐字段一致，否则说明可加性分类有误。建议 Python 侧保留几个典型切片（如「全周期×全仓」「近3月×2仓」）作为**黄金样本**供前端自动化比对。

---

## 7. ★ 待你确认清单

**数据与切片**
1. **Q1（周期粒度）**：现有区域健康看板**没有周期维度**（周期烘焙在真源文件名里，换周期=换文件+发版）。V6 要新增这根时间轴，选：
   - (a) **月桶 + 预设周期档/自定义月区间**（推荐，体量×8，可 Σ）；
   - (b) 任意起止日期（按日建表，体量×30，期末在职需按日快照）。
   详见 §3 D2-b 的三点差异对比。 
   A1：暂时选择(a) 月桶 + 预设周期档/自定义月区间。后续再升级任意起止日期。
2. **Q2（跨仓人头）**：同一员工在同一周期内**是否可能跨仓**？若可能，去重人头跨仓 Σ 会高估，需换方案。
   A2：统一员工在同一周期内不可能跨仓
3. **Q3（板块三仓单选）**：板块三因统计量依赖样本基准，建议物流仓**单选**。你能接受吗？若必须多选，EB/Wilson/档级只能在合并后重算，需 Python 下发原始 n/k 而非成品统计量。
   A3：板块三设计初始即为单选物流仓，推荐单选且必须单选
**业务口径（最关键）**
4. **Q4（分单能力断层）**：V6 后 价格/人效(件效)/供给满足率 全为 null，PO agent 的「合理用工数测算」与「供应商分单」将失去计算系数。选：
   - (a) 接受能力降级，agent 改为只做定性分析，待数据源接入后恢复；
   - (b) 保留 v5 画像表作为这三项系数的补充源，与 V6 并行（双真源，需定义优先级）；
   - (c) 暂缓 agent 侧切换，先只改看板展示（P5 推后）。
   A4：暂缓 agent 侧切换，先只改看板展示（P5 推后）
5. **Q5（板块四与现有内容）**：履约追踪 Tab 内「板块四入职留存」与现有「用工决策台账 + PO日记」是并存（推荐）还是替换？
   A5：去除现有用工决策台账，保留PO日记，板块四入职留存的数据在PO日记的日历上以事件显示
6. **Q6（旧链路去留）**：`供应商画像.json` / 旧 `Suppliers.md` / v5 JSON 保留兼容还是直接下线？
   A6：直接下线
**工程**
7. **Q7（Python 执行位置）**：确认 Python 仅在开发机离线跑、产物提交进 Git（推荐），而非纳入 `pnpm build` 一键链路？
   A7：暂时仅在开发机离线跑，产物提交进 Git。后续升级再纳入 `pnpm build` 一键链路。
8. **Q8（Excel 与产物入库）**：3 个原始 xlsx（40MB）与 43 个产出 xlsx 是否进 Git？建议均 `.gitignore` 排除，仅提交 `src/data/v6/*.json`。
   A8：仅 `src/data/v6/*.json` 进 Git，其他文件 `.gitignore` 排除
9. **Q9（目录收敛）**：`data/v6/*.py` 与 `scripts/v6/*.py` 重复镜像，统一保留 `scripts/v6/` 可以吗？
   A9：统一保留 `scripts/v6/`
10. **Q10（21 项口径）**：`V6口径梳理.md` 中标注待裁决的 21 项数据口径，是先按文档默认值跑通链路、后续再调，还是必须先全部裁决？
   A10：先按文档默认值跑通链路，后续再裁决。

---

## 8. 风险提示

1. **口径未裁决即落地**：21 项口径带默认值跑通，看板数值可能与业务预期不符 —— 建议 P0 阶段至少裁决影响板块一/二的项。
2. **前端聚合精度**：去重人头与历史最大供给量在跨仓合并时为近似值，需在 UI 上明确标注，避免被当作精确值用于决策。
3. **Agent 能力断层**：§3.6 / Q4，这是本次改造**业务风险最高**的一点。
4. **改造体量**：三个看板组件均需中到大幅重写，P2–P4 是主要工作量，建议逐 Tab 交付验证，不要一次性全改。
5. **双真源期**：若 Q4 选 (b)，需明确「同一字段两源冲突时以谁为准」，否则 agent 会取到矛盾数值。

---

# 9. ✅ 实施计划（基于 A1~A10 裁决展开）

## 9.0 总原则

| 原则 | 说明 |
|---|---|
| 单向依赖 | `data/v6/*.xlsx` → `scripts/v6/*.py` → `src/data/v6/*.json` → `v6-board-table.ts` → `gen-v6-boards.mjs` → 看板/工作区/种子。**任何一环不得反向写回** |
| 阶段隔离 | P0/P1 纯新增，不动任何现有前端；P2/P3/P4 逐 Tab 交付；P5 才做删除 |
| 闸门前置 | P0 末尾产出**黄金样本**，P2 起每个看板都必须跑对账才算验收通过 |
| 空值铁律 | 占位字段一律 `null`，前端渲染「暂无数据」/「—」，**绝不显示 0** |
| 下线时序 | P1 先把 `gen-portrait-md.mjs` 裁剪成单产物（保住 Agent 的 Suppliers.md），P5 才整体删除，避免 Agent 失能窗口 |

---

## 9.1 P0 · Python 侧产物设计

### 9.1.1 新增文件 `scripts/v6/export_app_json.py`（约 400 行）

职责：**只做导出，不改口径**。所有计算复用 `common.py` / `board1~4.py` 已有函数，禁止重复实现。

```
main()
 ├─ C.ensure_dirs() + C.prepare()          # 复用现有预处理
 ├─ build_fact_table(p)                    # 月桶事实表
 ├─ build_headcount_tables(p)              # 三级人头附表
 ├─ build_peak_table(p)                    # 峰值附表（仓×供应商）
 ├─ build_board3_slices(p)                 # 板块三预生成切片（12 组）
 ├─ build_board4(p)                        # 直接调 board4.build(p)
 ├─ build_meta(p)                          # 周期档/仓列表/口径字典/生成时间
 ├─ build_golden_sample(p)                 # 黄金样本（对账闸门）
 └─ dump_all(APP_JSON_DIR)                 # 原子写入 ClawX/src/data/v6/
```

新增路径常量：
```python
APP_DIR = os.path.join(ROOT, "ClawX", "src", "data", "v6")
MONTHS  = pd.period_range("2026-01", "2026-08", freq="M")   # 8 个月桶
```

### 9.1.2 产物清单（8 个 JSON，全部进 Git）

| # | 文件 | 内容 | 预估行数 | 预估体积 |
|---|---|---|---|---|
| 1 | `fact_monthly.json` | 月桶事实表（可加原子量） | ~70,000 | 12~18 MB |
| 2 | `headcount_wh.json` | 人头附表 L1：月×仓 | 48 | <10 KB |
| 3 | `headcount_wh_sup.json` | 人头附表 L2：月×仓×供应商 | ~720 | ~80 KB |
| 4 | `headcount_cond.json` | 人头附表 L3：月×仓×供应商×条件组 | ~70,000 | ~8 MB |
| 5 | `peak_supply.json` | 历史最大供给量（仓×供应商，全历史峰值） | ~90 | <20 KB |
| 6 | `board3_slices.json` | 板块三预生成切片（2 周期 × 6 仓 = 12 组 + meta） | ~3,000 | ~2 MB |
| 7 | `board4_onboarding.json` | 板块四主表 + 明细（全量台账） | 主~400 / 明细~1,800 | ~1 MB |
| 8 | `meta.json` | 周期档、仓列表、口径字典 81 条、占位字段说明、生成时间 | — | ~200 KB |
| 9 | `golden_sample.json` | 黄金样本：6 组场景 × 板块一 35 字段 + 板块二逐行 | — | ~300 KB |

> **A8 执行**：`.gitignore` 追加 `data/v6/*.xlsx`、`data/v6/out/`、`.tmp_v6/`；仅 `ClawX/src/data/v6/*.json` 入库。

### 9.1.3 事实表字段设计（`fact_monthly.json`）

**粒度键（6 列）**：`月份`(YYYY-MM) × `物流仓` × `供应商` × `工种` × `班次` × `用工性质` × `技能等级`

**可加度量（14 列，全部为 Σ 安全）**：

| 字段 | 来源 | 用途 |
|---|---|---|
| 考勤工时 | `g['_ag'].sum()` | 板块一 |
| 加班工时 | `g['_aa'].sum()` | 加班工时占比分子 |
| 计划出勤人次 | `(g['_q']>0).sum()` | 出勤率/异常率**分母** |
| 出勤人次 | `((_q>0)&(_ag>0)).sum()` | 出勤率**分子** |
| 考勤异常人次 | `g['_abn'].sum()` | 异常率分子 |
| 全体人日 | dd_all 计数 | 三方员工占比分母 |
| 三方人日 | third 计数 | 三方员工占比分子 |
| 异常已处理人日 | `slice_cal` 中 `_status ∈ CAL_DONE_STATUS` | 异常处理进度分子 |
| 异常待处理基数 | `slice_cal` 总数 | 异常处理进度分母（★V6 收紧口径） |
| 异常明细_\<类型\> | 按 `_abn_type` 展开为动态列 | 异常明细 dict |

**离职率专用列（另建 `turnover_monthly` 段，粒度 = 月×仓×供应商）**：
- `窗口内离职人数`（可 Σ）
- `期末在职人数`（**不可 Σ，跨月合并必须取区间最后一月值**）

> ⚠️ **实现红线**：前端合并多月时，离职率 = `Σ窗口内离职 / (末月期末在职 + Σ窗口内离职)`。绝不可对期末在职求和。

### 9.1.4 人头附表三级设计（解决去重人头不可加）

```
L1  headcount_wh      : 月 × 仓                     → 供给人数/出勤人数/考勤异常人数/全体出勤人数
L2  headcount_wh_sup  : 月 × 仓 × 供应商            → 供给人数/出勤人数/考勤异常人数
L3  headcount_cond    : 月 × 仓 × 供应商 × 条件组   → 供给人数/出勤人数/考勤异常人数
```

前端取数规则（**必须写进组件注释**）：
| 场景 | 取哪张表 | 跨维度合并方式 |
|---|---|---|
| 板块一 KPI（多仓多月） | L1 | 跨仓 Σ（A2 员工不跨仓保证无重复）；**跨月必须去重**→ 见下 |
| 板块二逐供应商 | L2 | 同上 |
| 板块三 | 不用，走预生成切片 | — |

> ⚠️ **跨月人头去重问题**：同一员工可能连续多月出现，Σ 会重复计数。
> **解法**：附表**每级都下发所有预设周期档的值**（全周期 / 2026-08 / 近3月 / 近6月 …），
> 即 `headcount_*.json` 的键是 `周期档 × 维度` 而非 `月 × 维度`。
> 自定义月区间若不在预设档内，前端显示人头类指标为「近似值」并加 tooltip 标注。

### 9.1.5 峰值附表（修正现有 reduce 求和缺陷）

```python
build_peak_table(p):
    for wh in DUBAI_WAREHOUSES:
        for sup in suppliers_of(wh):
            rows.append({物流仓, 供应商, 历史最大供给量: C.max_supply(h3_filtered)})
```
- 前端跨供应商合并：`Σ 各家峰值`，UI 标注「上界近似（各家峰值不同时点）」
- **禁止**再出现 `真实行.reduce((s,行)=>s+行.历史最大供给量,0)` 的条件组级求和

### 9.1.6 板块三切片矩阵

12 组 = `{全周期, 2026-08} × {6 个单仓}`，直接调 `board3.build(p, w0, w1, wh)`，
每组含：`rows[]`（28 字段）+ `meta`（11 字段留痕）+ 空态占位行（若 `len(df)==0`）。

结构：
```json
{ "slices": { "全周期|阿联酋迪拜定制8号仓": { "rows": [...], "meta": {...} }, ... },
  "periods": ["全周期","2026-08"], "warehouses": [...] }
```

### 9.1.7 黄金样本（P2 质量闸门）

6 组场景：`{全周期, 2026-08} × {全部仓, 8号仓, 8号仓+5号仓}`
每组存 `board1.build()` 全部 35 字段 + `board2.build()` 逐行 23 字段。

**验收断言**：前端用事实表+附表实时聚合出的结果，与黄金样本逐字段比对：
- 数值型：相对误差 `< 1e-6`
- null 字段：必须同为 null
- 名单类：集合相等（顺序无关）

### 9.1.8 P0 验收标准

- [ ] `python3 scripts/v6/export_app_json.py` 退出码 0
- [ ] `ClawX/src/data/v6/` 下 9 个 JSON 全部生成，`meta.json.生成时间` 为当次时间
- [ ] 事实表 Σ计划出勤人次 == `board1.build(全周期, 全部仓)['计划出勤人次']`
- [ ] 事实表 Σ出勤人次、Σ考勤异常人次、Σ考勤工时、Σ加班工时 同样对齐（4 条断言）
- [ ] `run_all.py` 原有 119 条断言仍全 PASS（口径未被污染）
- **回滚**：纯新增文件，`git rm` 即可

---

## 9.2 P1 · TS 真源层与 gen 派生脚本

### 9.2.1 `ClawX/src/data/v6/schema.ts`（迁入 450 行）

- 由 `doc/v6_board_schema.ts` 原样迁入，**只改一处**：确认 `@sinclair/typebox` 已在 `ClawX/package.json` dependencies（若无则加）
- 新增 3 个 Schema 以覆盖 P0 新产物：
  - `FactMonthlyRowSchema`（6 键 + 14 度量 + 动态异常明细）
  - `HeadcountRowSchema`（周期档 + 维度键 + 3 个人头数）
  - `PeakSupplyRowSchema`（物流仓 + 供应商 + 历史最大供给量）
- 导出 `V6AppDataSchema` 顶层聚合（9 个产物的并集），供 gen 脚本一次 `Value.Check()`

### 9.2.2 `ClawX/src/data/v6-board-table.ts`（新增约 500 行）

**定位**：与 `supplier-portrait-table.ts` 同构 —— **只做类型标注 + 转发 import**，不写业务数据。

```ts
import fact from './v6/fact_monthly.json';
import hcWh from './v6/headcount_wh.json';
// … 其余 7 个
import type { Static } from '@sinclair/typebox';
import { FactMonthlyRowSchema, /* … */ } from './v6/schema';

export type 事实表行 = Static<typeof FactMonthlyRowSchema>;
export const 月桶事实表 = fact as unknown as 事实表行[];
// … 其余转发
```

**唯一的业务内容 = 仓库层级表补齐 6 仓**（从 `supplier-portrait-table.ts` 迁移并扩展）：

| 洲际 | 片区 | 物流仓（展示名 = 真源名，V6 已统一） |
|---|---|---|
| 中东区 | 阿联酋区 | 阿联酋迪拜定制8号仓 / 中小件5号仓 / 定制3号仓 / 中小件2号仓 / 定制6号仓 / 大件1号仓 |

> ★ V6 的 `DUBAI_WAREHOUSES` 已是「阿联酋迪拜…」全名，与 v5 的「迪拜定制8号仓」不同，
> 故 `真源物流仓` 字段在 V6 中恒等于 `物流仓`，保留该字段仅为兼容层级表接口。
> `未分区标签` 常量一并迁入。

**同时导出前端聚合器**（避免三个看板各写一份）：
```ts
export function 聚合板块一(事实行: 事实表行[], 人头: …, 峰值: …, 周期: …): Board1Row
export function 聚合板块二(…): Board2Row[]
export function 比率(分子: number, 分母: number): number | null   // 分母 0 → null
```
> ⚠️ **禁止**继续使用旧的 `加权均值()`。所有比率一律 `Σ分子 / Σ分母`。

### 9.2.3 `ClawX/scripts/gen-v6-boards.mjs`（新增约 200 行）

复刻 `gen-decisions.mjs` 的五步范式：

| 步 | 动作 | 失败处理 |
|---|---|---|
| 1 | `ts.transpileModule` 读 `v6-board-table.ts`（保留中文/转义） | 有 Error 诊断 → 抛错退出 |
| 2 | `Value.Check(V6AppDataSchema, data)` | 打印首个 `Value.Errors` 路径后退出 |
| 3 | 派生 5 份产物（见下表） | — |
| 4 | `.{pid}.tmp` + `rename` 原子写入每个目标 | — |
| 5 | 打印各产物行数/字节数统计 | — |

**派生产物矩阵**：

| 产物 | 目标路径 | 消费方 |
|---|---|---|
| 区域健康.json | `~/.openclaw/workspace-po/` + `ClawX/shared/po-v6-region.json` | 区域健康看板 / 预置种子 |
| 采购下单.json | 同上 + `po-v6-purchase.json` | 采购下单看板 |
| 履约追踪.json | 同上 + `po-v6-fulfillment.json` | 履约追踪看板（板块四） |
| 指标口径.md | `~/.openclaw/workspace-po/` | Agent 只读 |
| Suppliers.md | `~/.openclaw/workspace-po/` | Agent 只读（**P1 阶段仍由旧脚本产出，P5 才切到本脚本**） |

`package.json` 新增：`"gen:v6": "node scripts/gen-v6-boards.mjs"`

### 9.2.4 裁剪 `gen-portrait-md.mjs`（A4/A6 冲突处理）

P1 阶段**只删两处产出**，保留 Suppliers.md：
- ✂️ 删除 `~/.openclaw/workspace-po/供应商画像.json` 写入
- ✂️ 删除 `ClawX/shared/po-supplier-portrait.json` 写入
- ✅ 保留 `Suppliers.md` 写入（Agent 命脉，P5 前不可断）

### 9.2.5 P1 验收标准

- [ ] `pnpm gen:v6` 退出码 0，打印 5 份产物统计
- [ ] TypeBox 校验通过（故意改坏一个字段能被拦下 → 反向验证）
- [ ] 三份看板 JSON 在 `~/.openclaw/workspace-po/` 与 `ClawX/shared/` 下均存在且内容一致
- [ ] `pnpm typecheck` 通过
- [ ] **旧看板与旧 Agent 功能完全不受影响**（本阶段不碰前端）
- **回滚**：删除新增文件 + 还原 `gen-portrait-md.mjs` 两处写入

---

## 9.3 P2 · 区域健康看板（板块一 + 板块二）

**文件**：`ClawX/src/pages/Chat/RegionHealthDashboard.tsx`（重写约 600 行）

### 9.3.1 改造项（按优先级）

| # | 改造 | 现状 | 目标 |
|---|---|---|---|
| 1 | **新增周期筛选器** | 无周期维度（烘焙在文件名） | 预设档下拉：全周期 / 2026-08 / 近3月 / 近6月 + 自定义月区间 |
| 2 | **聚合器替换** | `加权均值(行, 字段, 样本人数)` 有偏近似 | `Σ分子 / Σ分母` 精确重算 |
| 3 | **峰值缺陷修正** | `真实行.reduce((s,行)=>s+行.历史最大供给量,0)`（第 330/355 行） | 从 `peak_supply.json` 按「仓×供应商」取值再 Σ |
| 4 | **离职率跨月** | 无 | `Σ离职 / (末月期末在职 + Σ离职)` |
| 5 | **人头类指标** | 条件组求和（重复计数） | 从 `headcount_wh.json` 按周期档直接取 |
| 6 | **KPI 五分区** | 旧 6 字段 | 板块一 35 字段，分供给规模/出勤履约/异常加班/稳定性/占位区 |
| 7 | **新增板块二表格** | 无 | 逐供应商 23 字段，默认供给人数降序，头部（≥50%）加徽标 |
| 8 | **数据源切换** | `供应商画像.json` | `区域健康.json` |

### 9.3.2 KPI 五分区布局

```
[供给规模]  供给人数 · 三方员工占比 · 活跃供应商数量 · CR3集中度 · 最大单家供给占比
[出勤履约]  出勤率 · 计划出勤人次 · 出勤人次 · 出勤人数
[异常加班]  考勤异常率 · 异常处理进度 · 考勤工时 · 加班工时 · 加班工时占比 · 异常明细(可展开)
[稳定性]    离职率 · 窗口内离职人数 · 期末在职人数
[业务常量]  供给满足率 100% · 供给时效 14 天   （实值 + 「业务方指定常量」hint）
[占位区]    静默供应商数量 — · 价格 — · 件效 —   （灰显 + tooltip 说明原因）
```

### 9.3.3 P2 验收标准（★ 质量闸门）

- [ ] **黄金样本对账**：6 组场景 × 板块一 35 字段，数值相对误差 `< 1e-6`，null 字段同为 null
- [ ] 板块二逐行 23 字段对账一致，`Σ供给占比 ≈ 1`（误差 < 1e-9）
- [ ] 切换周期档时数值联动，不需刷新页面
- [ ] 占位字段显示「—」而非 0
- [ ] 跨仓合并时峰值/人头类指标带「近似值」tooltip
- **回滚**：单组件 git revert

---

## 9.4 P3 · 采购下单看板（板块三）

**文件**：`ClawX/src/pages/Chat/SupplierPortraitDashboard.tsx`（重写约 400 行）

| # | 改造 | 说明 |
|---|---|---|
| 1 | 仓筛选器多选→ **单选** | A3 裁决；单选后按 `周期\|仓` 键取 `board3_slices.json` 对应切片 |
| 2 | 周期筛选器 | 仅 2 档（全周期 / 2026-08），与切片矩阵严格对应 |
| 3 | 字段全换 | 28 字段；出勤率显示 EB 收缩值，tooltip 展示 `出勤率_原始` + 样本人数 |
| 4 | 档级徽标 | ①细 / ②粗 / ②粗+EB / ④基准，四色区分 |
| 5 | 置信度列 | 高/中/低/极低 + 区间宽度 pp 显示 |
| 6 | 极低置信度默认折叠 | 提供「显示全部」开关 |
| 7 | 口径四项（P6/P6″ 后已全部有值）| 供给满足率 100% · 供给时效 按桶 7/14/30 天 · 价格 价卡实值（仅 8 号仓）· 件效 按仓常量 |
| 8 | 空切片空态 | `数据状态 == '样本不足-无可用记录'` → 渲染空态卡片 + meta 原始切片数 |
| 9 | meta 留痕区 | 折叠展示 11 字段（EB 先验、过滤前后切片数等） |

**验收**：随机抽 3 个切片，前端展示值与 `board3_slices.json` 逐字段一致；仓单选后 URL/状态不残留多选态；空切片仓（若有）正确显示空态。

---

## 9.5 P4 · 履约追踪看板（板块四 + 日历事件融合）

**文件**：`SupplierDecisionDashboard.tsx`（改造约 300 行）+ `PoDiaryCalendar.tsx` + `po-diary.ts`

### 9.5.1 删除用工决策台账（A5）

- ✂️ 删除 `RecordCard` 组件、`parseRecords()`、决策 `load()`、`用工决策.json` 读取
- ✅ 保留 PO 日记日历，升级为 Tab 主体

### 9.5.2 入职事件融合（最小侵入方案）

**改 `po-diary.ts`（3 处）**：
```ts
export type PoDiaryMarkerKind = 'order' | 'delivery' | 'onboarding';   // ★扩展第三值
export const MARKER_LABEL = { order:'下单', delivery:'预期送达', onboarding:'入职' };
export interface OnboardingEvent {          // ★新增只读事件类型
  dateKey: string; warehouse: string; supplier: string;
  入职总人数: number; 天30留存率: number|null; 天90留存率: number|null;
  追踪中: boolean;                          // 窗口未满
}
```
> `groupMarkersByDate()` **不改**（仍只处理可写日记条目），入职事件走独立 Map。

**改 `PoDiaryCalendar.tsx`（3 处）**：
```tsx
export function PoDiaryCalendar({ externalEvents }: { externalEvents?: OnboardingEvent[] })
// ① MARKER_TONE 新增 onboarding: 'bg-sky-500/10 …'（第三色，与琥珀/绿区分）
// ② dayMarkers 渲染处：并入 externalEventsByDate.get(key) ?? []，只读徽标无删除按钮
// ③ 选中日明细区：入职事件卡片展示 仓/供应商/人数/30·90天留存率（未满显「追踪中」）
```

### 9.5.3 四个关键设计点（落地检查）

| 点 | 要求 | 实现 |
|---|---|---|
| 读写隔离 | 入职事件**绝不进** `persist()` 写链路 | `externalEvents` 只参与渲染，不进 `entries` 状态 |
| 视觉区分 | 可写 vs 只读一眼可辨 | 第三配色 + 无删除按钮 + 右上角「派生」角标 |
| 留存时间语义 | 留存率随批次固定，不随筛选周期变化 | 直接读 `board4_onboarding.json` 主表值，前端不重算 |
| 窗口未满 | 入职日 + 30/90 天 > 今天 | 显示「追踪中」而非 0% |

### 9.5.4 验收标准

- [ ] `externalEvents` 为 `undefined` 时日历行为与改造前**完全一致**（向后兼容）
- [ ] 入职事件不可删除、不可编辑，删除按钮不渲染
- [ ] 新增/删除日记条目后，入职事件仍正常显示（不被 `persist` 覆盖）
- [ ] Σ 日历入职人数 == `board4_onboarding.json`主表 `Σ入职总人数`
- [ ] 现有 testid 全部保留，E2E 不破
- **回滚**：移除 `externalEvents` props 传入即退回原状

---

## 9.6 P5 · 旧链路下线（严格时序）

**前置条件**：P2/P3/P4 全部验收通过，且 `gen:v6` 已能产出 Suppliers.md。

**按 23 处引用点的删除顺序**：

| 步 | 动作 | 涉及文件 |
|---|---|---|
| 1 | 改看板 import：层级表/未分区标签 改从 `v6-board-table.ts` 取 | `RegionHealthDashboard.tsx:10/24/25`、`SupplierPortraitDashboard.tsx:5/6/24`、`SupplierDecisionDashboard.tsx:7/20` |
| 2 | 删 TS 真源与 v5 JSON | `supplier-portrait-table.ts`、`supplier-decision-table.ts`、`迪拜8仓…v5….json`(120.8KB) |
| 3 | 删 gen 脚本与 npm script | `gen-decisions.mjs`、`gen-portrait-md.mjs`、`package.json:38` |
| 4 | 删 shared 种子 | `po-supplier-decisions.json`、`po-supplier-portrait.json` |
| 5 | 改 electron 预置 | `agent-config.ts:860/876/929/952/960/1008` → 新增 `ensurePresetPoV6Files()`，删旧预置 |
| 6 | 清理插件文案 | `po-decisions` 插件 4 处（`handler.bundle.mjs:4/29/384/392`、`index.mjs:7`、`openclaw.plugin.json:4`） |
| 7 | `.gitignore` 追加 | `data/v6/*.xlsx`、`data/v6/out/`、`.tmp_v6/` |

**验收**：全局 grep `supplier-portrait-table|supplier-decision-table|供应商画像.json|用工决策.json|gen:decisions` **零命中**；`pnpm typecheck` + `pnpm build` 通过；Agent 仍能读到 Suppliers.md。

---

## 9.6b P6′ · 字段口径接入（价格 / 件效 / 供给率）· ✅ **已封板**

> **编号说明**：本节为 D6 裁决落地的实施阶段，执行顺序上**先于 §9.6 P5 旧链路下线**（P5 需等字段补齐后一次性下线，避免两轮返工）。与 §9.7「P6 Agent 侧切换」是不同阶段，勿混。

**改动面**：

| 层 | 文件 | 内容 |
|---|---|---|
| Python 常量层 | `scripts/v6/common.py` | 新增 `SUPPLY_RATE_CONST` / `supply_rate_of()` / `PIECE_EFF_BY_WH` / `PRICE_JOB_ALIAS` / 价卡加载函数族（pickle + mtime 缓存）/ `STATUS_FIELDS_FULL` / `data_status_of()` |
| Python 板块层 | `board1.py` `board2.py` `board3.py` `board4.py` `metric_dict.py` | 接入价格/件效/供给满足率；`数据状态` 按字段白名单生成；指标字典状态枚举扩 5 类 |
| TS 类型层 | `ClawX/src/data/v6/schema.ts` | 5 处口径 description 更新 + 新增 `价格单位` 字段 |
| TS 聚合层 | `ClawX/src/data/v6-board-table.ts` | 新增 `供给满足率常量`；板块一/二接口与赋值共 4 处收口，`数据状态` 文案与 Python **逐字对齐** |
| 前端看板 | `RegionHealthDashboard.tsx` | KPI 分区改名「业务常量与待接入指标」；供给满足率由「—」改为实值 + tooltip；板块二表格同步 |
| 前端看板 | `SupplierPortraitDashboard.tsx` | 原「占位四项 map 循环」拆为 4 个独立 `StatCard`，价格单位条件渲染 + 行级 null 归因 tooltip |

**验收闸门（全绿）**：

| 闸门 | 结果 |
|---|---|
| `python3 export_app_json.py` | ✅ 10 JSON + 14 断言 |
| `python3 run_all.py` | ✅ 43 Excel + 119 断言 PASS / 0 FAIL |
| `node scripts/_verify-golden.mjs` | ✅ **黄金样本 py/ts 双侧对账通过（阈值 1e-6）**，6 组场景 |
| `pnpm typecheck` | ✅ node + web 双通过 |
| `npx eslint`（4 个改动文件） | ✅ 零错误 |
| **`pnpm gen:v6`** | ✅ **必跑**：把 TS 真源派生到 `shared/po-v6-*.json` + `~/.openclaw/workspace-po/*.json` |
| **`pnpm run verify:derived`** | ✅ 新增闸门：新鲜度 + 双写一致 + 8 号仓关键字段非空（价格非空率 97.6% = 243/249） |

**★★三段式链路铁律（事故教训）**：数据链路为
`Python 产物 src/data/v6/*.json` → `import` 进 TS 真源 `v6-board-table.ts` → **`pnpm gen:v6`** → `shared/po-v6-*.json`（bundle 种子）+ `~/.openclaw/workspace-po/*.json`（**前端实际读取**）。
P6′ 首次收口时只跑了 Python 侧脚本、**漏跑 `pnpm gen:v6`**，导致 Python 产物已更新但前端消费的两处文件仍停留在改动前，看板上 供给满足率/供给时效/价格/件效 四项全空 —— 而前 5 道闸门全绿（它们只覆盖 Python 产物与 TS 源码两端，无一校验派生产物）。
**结论**：任何改动 Python 产物或 TS 真源的操作，收口 checklist 必须包含 `pnpm gen:v6` + `pnpm run verify:v6`（已把 `verify:derived` 并入 `verify:v6`）。

**验收口径备注**：8 号仓价格允许少量 null —— `Ogram FZ-LLC` 无价卡编码，按业务方要求忽略，故 `verify:derived` 对价格只卡 95% 非空率下限，对 `价格单位/件效/供给满足率` 卡 100% 非空。

**★双侧同源契约**：`供给满足率常量`（TS）与 `SUPPLY_RATE_CONST`（Python）必须同步变更。需求台账接入后须**两侧同时下线**，否则黄金样本对账会立即暴露差异 —— 该字段不在对账跳过集内，是天然的漂移探针。

**遗留**：5 号仓（第二大仓，7928 人日）件效为 null；4/7 号仓仓名为推测拼写，扩仓时需回校；双向工种归一使 `仓储组长岗`/`入库组长岗` 共享 `组长岗` 价。

---

## 9.6c P6″ · 供给时效口径接入（§D6 最后一个 null 字段）· ✅ **已封板**

**业务方给定口径**（三看板三套取值，共用同一分桶阈值）：

| 板块 | 取值规则 | 值域 |
|---|---|---|
| 一（区域整体）| 固定常量 | `14` 天 |
| 二（按供应商）| 固定常量 | `14` 天 |
| 三（采购下单）| 按**需求量桶**取值 | 0-20→`7` / 20-100→`14` / 100以上→`30` |
| 四（履约追踪）| 按**入职总人数**套用同一分桶（裁决 C）| 同上 |

**实现要点**：

1. **常量层单一真源** `common.py`：`SUPPLY_LEAD_REGION_CONST=14` + `SUPPLY_LEAD_BY_BUCKET=[(0,20,7),(20,100,14),(100,9999,30)]` + `SUPPLY_LEAD_UNIT='天'`；分桶阈值与既有 `DEMAND_BUCKETS` 逐字对齐。
2. **★双函数入口**（规避入参语义混淆）：`supply_lead_of(n)` 收**标量**（板块四入职总人数），含 None/NaN 防御；`supply_lead_of_bucket(lo, hi)` 收**桶边界**（板块三），精确匹配失败时降级到 `supply_lead_of(hi)`。
3. **★`data_status_of(..., lead_mode=)` 三态文案**：`region`（默认，板块一/二零改动即正确）/ `bucket` / `headcount`，查 `SUPPLY_LEAD_STATUS_TEXT` 字典，避免文案硬编码在各板块。
4. **★板块三写入点必须在桶展开循环内**：`for lo, hi in DEMAND_BUCKETS` 把每行复制 3 份，若在建行处赋值会导致三桶同值。建行处保留 `None` 并留注释。
5. **TS 侧同源三件套** `v6-board-table.ts`：导出 `供给时效区域常量 / 供给时效单位 / 供给时效分桶 / 供给时效映射()`，板块一/二接口由 `供给时效: null` 放宽为 `number | null`；`schema.ts` 四处描述按板块差异化，使 schema 自身即口径文档。
6. **前端渲染**：区域健康 StatCard 与板块二表格列显 `14 天`（tooltip「业务方指定恒为 14 天，非实算」）；采购下单 StatCard 显行级桶值 `7/14/30 天`，hint 标注所属需求量桶区间；对应 `ph('供给时效')` 占位调用已移除。
7. **★闸门加固** `_verify-derived.mjs` 新增两条：8 号仓每行 `供给时效` 必须与其 `需求量下限~上限` 桶一致（防双侧分桶漂移）；区域健康两板块全部 101 处必须等于常量 14。

**验收**：JSON 14 断言 ✅ / Excel 119 断言 ✅（PASS 119 FAIL 0）/ 黄金样本对账 ✅（`供给时效` 非跳过字段，双侧一致）/ P4 ✅ / 派生产物 6 条（含新增 2 条）✅ / `typecheck` ✅ / `eslint` 零告警 ✅。

**★双侧同源契约**：`供给时效分桶`（TS）与 `SUPPLY_LEAD_BY_BUCKET`（Python）必须同步变更；需求台账接入后两侧同时下线。`metric_dict.py` 四条已从 `_PH` 转 `_BIZ`。

**遗留**：单位展示格式 `14 天` 未经业务方确认；TS 侧板块三/四聚合尚未使用 `供给时效映射()`（当前值由 Python 产物直传），后续若在 TS 侧重算须确保逐字一致。

---

## 9.7 P6 · Agent 侧切换（A4 推后）· ✅ **已封板（详见 §9.9）**

**触发条件**：价格 / 件效 / 供给满足率 / 供给时效 任一数据源接入后启动 —— **四项已于 §9.6b / §9.6c 全部接入，触发条件已满足**。

原待办与结论：① `Suppliers.md` 重构为 5 分节权威数据表 —— **改为直接让 skill 读 V6 JSON 产物，`Suppliers.md` 不再作为分析入口**；② PO agent prompt 字段清单更新 —— ✅；③ `po-dashboard-analysis` skill 口径指引更新 —— ✅（V6 重写 + 三段式迁移）；④ 分单算法系数源切换 —— ✅（条件组维度 + EB/Wilson 口径写入 skill）。

---

## 9.8 交付顺序与风险控制

```
P0(Python产物) → P1(TS真源+gen) ─┬→ P2(区域健康) ─→ 黄金样本对账 ✓
                                 ├→ P3(采购下单)
                                 └→ P4(履约追踪)
                                        ↓ 全部通过
                         P6′(字段口径接入·价格/件效/供给率) ─→ 黄金样本对账 ✓
                                         ↓
                                   P5(旧链路下线) → P6(Agent切换)
```

> **顺序调整说明**：原计划 P4 后直接进 P5，实际执行改为**先做 P6′ 字段口径接入再下线旧链路** —— 因 P5 需删除 `supplier-portrait-table.ts` 的 `人效` 等字段，若字段口径未定会导致两轮返工。

| 风险 | 缓解 |
|---|---|
| 事实表 15~18MB 前端解析卡顿 | P2 先实测；超 500ms 则改按周期档拆分文件 + 按需 lazy load |
| 人头跨月去重 | 附表按「周期档 × 维度」下发；自定义区间标注「近似值」 |
| `PoDiaryMarkerKind` 扩展影响面 | 同步改 `MARKER_LABEL` / `MARKER_TONE` / 类型三处，TS 穷尽检查会强制提醒 |
| 下线过早导致 Agent 失能 | P1 只裁剪不删除，P5 才整体清理 |
| 一次性全改三看板 | 逐 Tab 交付，每个 Tab 独立 commit 与回滚点 |

---

## 9.9 P7 · 三看板 Agent 分析链路横向复制 · ✅ **已封板**

> 把原本仅画像看板具备的「隐形会话 + 刷新重跑 + skill 分析」链路，横向复制到**区域健康 / 采购下单 / 履约追踪**三个 V6 看板，做到**一看板一会话 key、一看板一 skill**。

### 9.9.1 前端：store 由单数泛化为三看板 Record

[`po-dashboard-analysis.ts`](../ClawX/src/stores/po-dashboard-analysis.ts) 改造要点：

1. 新增 `PoBoardKind = 'region' | 'decision' | 'portrait'` 与 `PO_BOARD_KINDS`；`sessionKey / refreshSignal / boardContext` 三个状态由标量升为 **Record<PoBoardKind, T>**。
2. 会话 key 约定 `agent:po:<board>-<ts>`，配套解析器 `parsePoDashboardSessionKey()` 反解 board；`isPoDashboardSessionKey()` 继续供隐形会话过滤复用。
3. `persist` 版本升到 **v2** 并提供 `migrate`：v1 的单数 `sessionKey` 归位到 `portrait`，避免老用户本地脏值导致三 Tab 串味。
4. `requestRefresh(board)` 只自增该看板的 `refreshSignal`，由 Chat 页 `useEffect` 监听触发新一轮分析。

### 9.9.2 前端：三看板上报筛选上下文 + 刷新按钮

三个看板组件在筛选项变化时调用 `setBoardContext(board, summary)`，把「周期档 / 物流仓 / 范围 / 指标维度」等当前筛选拼成一句人类可读摘要；刷新按钮改调 `requestRefresh(board)`。

[`index.tsx`](../ClawX/src/pages/Chat/index.tsx:59) 的 `buildPoDashboardAnalysisPrompt(board, context)` 按 board 三分支拼提示词，并把筛选摘要以 `当前看板筛选范围：…` 注入，**解决 skill 拿不到筛选上下文、全量分析跑偏的问题**。

### 9.9.3 后端：新增 1 份预置知识 + 2 个预置 skill

[`agent-config.ts`](../ClawX/electron/utils/agent-config.ts) 变更：

| 资产 | slug / 文件 | 幂等策略 | 说明 |
|---|---|---|---|
| `Trace.md` | 工作区根 | 存在即跳过 | 四章：口径前提 / 缺口严重度三级 / 档位 A~E 补救措施 / 输出约束 |
| 采购下单 skill | `po-dashboard-analysis` | **三段式迁移** | V6 重写；旧版特征命中（含 `Suppliers.md` + `# 供应商画像看板分析`）才覆盖，用户手工改写版不动 |
| 区域健康 skill | `po-region-health-analysis` | 存在即跳过 | 读 `区域健康.json` + `Rule.md`，产出「供给结构 / 供给质量」两节 |
| 履约追踪 skill | `po-fulfillment-analysis` | 存在即跳过 | 读 `履约追踪.json` + `采购下单.json` + `Trace.md`，按剩余天数分档 |

四项 ensure 已在 `ensurePresetPoAgent()` 的**「新建」与「已存在」两条分支**各登记一次，覆盖新用户与老环境升级。

### 9.9.4 ★ 履约缺口口径裁决（方案 A · 代理量法）

真实下单量字段尚未接入，裁决用**需求量桶下限**做代理基线，并强制 skill 显式标注：

```
预期供给日 = 入职日期 + 供给时效(0-20→7 / 20-100→14 / 100+→30)
剩余天数   = 预期供给日 − 今天（可为负）
需求基线   = 所属条件组的「需求量下限」桶下限(0/20/100)   ← 代理量，非真实下单量
缺口       = 需求基线 − 入职总人数（≤0 视为无缺口）
严重度     = 轻微(<10%且<5人) / 中等(10~30%或5~15人) / 严重(>30%或>15人)
档位       = A >14天 / B 8~14 / C 3~7 / D 0~2 / E <0(已逾期)
```

该 7 步被**逐字写死在 skill 内并标注「不得跳步或改口径」**，防止模型自创缺口算法；履约看板本身不新增筛选 UI。

### 9.9.5 ★ 反幻觉：三个 skill 共享的禁止性条款

| 字段 | 禁止性结论 |
|---|---|
| `供给满足率` = 1.0 | 常量非实算，禁止据此下「履约良好 / 无缺口」结论 |
| `供给时效` = 7/14/30 | 分桶常量，不得解读为响应速度差异 |
| `静默供应商数量·名单` | 占位未接入，不得当作 0 |
| `考勤异常率` | 可 > 1（同人次多类异常），非数据错误 |
| `考勤工时` vs `全体考勤工时` | 口径不同（三方 / 自有+三方），不可混用或相减 |
| `历史最大供给量` | 各家峰值不同日，**禁止相加**当作区域峰值 |
| `价格` / `件效` | 价格仅 8 号仓命中；件效 5 号仓为 null —— 跨仓比价须显式声明缺失 |
| `人头近似` / `峰值近似` | 为 true 时须如实传导「近似值」 |

### 9.9.6 ★ 采购下单产物寻址（易错点）

`采购下单.json` 的 `切片` 是**以 `"周期档|物流仓"` 为 key 的对象**（12 个 key），而非数组：

```
切片["全周期|阿联酋迪拜定制8号仓"] = { rows: Row[30字段], meta: { 原始切片数/过滤后切片数/
      EB先验_全仓池化出勤率/价格命中切片数/件效常量/最终行数 … } }
```

skill 内已写死「必须按当前筛选拼 key 后再取 `rows`，**不要遍历全部 key 把所有仓混在一起比较**」。

### 9.9.7 ★ 模板字面量转义铁律（本阶段两次事故）

skill 正文以 TS 模板字符串内联，两次踩坑：

1. 串内反引号被写成 `\\` + 反引号（双反斜杠）→ 渲染出多余反斜杠。**正确形态为单反斜杠 + 反引号**。
2. 批量替换时把模板串**终止符**也写成了转义反引号 → 模板未终止，连带 31 条编译错误。**终止符必须是裸反引号**。

固化做法：**字符级探针（统计反引号前导反斜杠数）+ 渲染级探针（`new Function` 实际求值并断言无游离反斜杠）双验，再跑 `tsc` + `eslint`**；且优先用精确上下文替换，避免全局替换打断模板串。

### 9.9.8 验收

`probe_render` 四常量 `strayBackslash=0` ✅ / `tsc -p tsconfig.node.json` ✅ / `tsc -p tsconfig.web.json` ✅ / `eslint` 六文件零输出 ✅ / 废弃符号 grep（旧单数 `sessionKey`、`PO_DASHBOARD_ANALYSIS_PROMPT`、`PoDashboardTab`）已清零 ✅。

**遗留**：两个新 skill 采用「存在即跳过」，后续若需修订内容，老环境不会自动更新，需另加迁移特征判定；运行时三 Tab 切换与刷新回放待实机验证。
