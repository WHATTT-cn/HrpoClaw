# OpenClaw 源码改造技术文档（目录 · 脚本 · 模块 · 关键代码）

> 配套文档：《OpenClaw 二次开发改造方案》（业务目的与阶段规划）。本文是其实现层：打开 OpenClaw 这个 monorepo，我们的代码放哪、用什么命令开发验证、自研模块怎么划分、关键代码怎么写。
>
> 基线：openclaw/openclaw @ 2026.8.1（pnpm@11 workspace，Node ≥ 22）。所有代码骨架基于该版本 plugin-sdk 真实 API 形状编写；个别未逐字验证的签名处以注释标注，落地时以所钉版本的 `plugin-sdk:surface` 输出为准。

---

## 第一层：项目架构（目录）

### 1.1 上游仓库地图（我们只碰哪些目录）

```
openclaw/                         # pnpm monorepo（packages: [".", "ui", "packages/*", "extensions/*", "examples/*"]）
├─ src/                           # 核心本体 —— 不改（fork 禁区）
│  ├─ agents/                     #   loop、workspace 五件套、bootstrap、子agent
│  ├─ gateway/                    #   控制面中枢（server-methods/ = RPC 方法表）
│  ├─ plugins/                    #   hook 系统、hook-decision-types、trusted-tool-policy
│  ├─ plugin-sdk/                 #   对插件开放的受控表面（≈ 我们的全部依赖）
│  ├─ memory/                     #   root-memory-files（MEMORY.md 定位/迁移）
│  ├─ cron/  channels/  config/   #   调度 / 渠道 / 配置
├─ packages/                      # 22 个契约包：plugin-sdk、plugin-package-contract、
│                                 #   gateway-protocol、gateway-client、memory-host-sdk…
├─ extensions/                    # 156 个官方插件（我们的参照系：active-memory、deepseek…）
├─ skills/                        # 52 个内置技能（SKILL.md）
└─ package.json                   # 530 个脚本（开发门禁见第二层）
```

**铁律**：我们的代码一行不进 `src/`。要么做成**独立 npm 包**（推荐，彻底解耦），要么开发期挂在 `extensions/` 下蹭 monorepo 工具链、发布后迁出。下面按"独立插件仓库 + 开发期符号链接"组织。

### 1.2 我们的插件仓库目录（新建，独立于上游）

```
openclaw-guard-suite/             # 我们的二开总仓（pnpm workspace）
├─ package.json                   # workspace 根：private, packageManager pnpm
├─ pnpm-workspace.yaml            # packages: ["plugins/*"]
├─ plugins/
│  ├─ weights-guard/              # M1+M2 五道闸门与 tool_result_persist 回喂重试
│  │  ├─ package.json             #   name: "@acme/openclaw-weights-guard"
│  │  ├─ openclaw.plugin.json     #   插件清单（发现/兼容/安装元数据）
│  │  ├─ index.ts                 #   入口：definePluginEntry
│  │  ├─ src/
│  │  │  ├─ gates/                #   五道闸门各一个文件（可单测）
│  │  │  │  ├─ amplitude.ts       #   ① ±0.10 幅度
│  │  │  │  ├─ normalize.ts       #   ② 归一化
│  │  │  │  ├─ whitelist.ts       #   ③ 维度白名单
│  │  │  │  ├─ evidence.ts        #   ④ 事实回查
│  │  │  │  └─ injection.ts       #   ⑤ 注入前置过滤
│  │  │  ├─ execute.ts            #   submit_proposal 的 execute：语义→权重映射放行
│  │  │  ├─ hook.ts               #   tool_result_persist 五闸改写 + after_tool_call 留痕接线
│  │  │  ├─ staging.ts            #   提案落 staging
│  │  │  ├─ schema.ts             #   submit_proposal 的 JSON Schema
│  │  │  └─ fallback.ts           #   回落纯算法权重
│  │  └─ tests/                   #   契约测试 + 闸门单测
│  ├─ knowledge-harvester/        # M3 交互→知识文件（提炼+人审+双层写入）
│  ├─ soul-writer/                # M4 主/子 agent 设定回写
│  ├─ global-brain/               # M5 全局知识层（~/.knowledge-base）
│  ├─ cloud-sync/                 # M7 云端同步（反向拓扑）
│  └─ skill-curator/              # M8 技能生产线 + 月度回归
├─ shared/                        # 公共：staging 读写、审计轨迹、留痕 schema
└─ docs/
```

工作区侧（agent 运行机上）落地目录约定：

```
<workspace>/                      # OpenClaw 工作区（五件套所在）
├─ AGENTS.md  SOUL.md  USER.md  MEMORY.md  IDENTITY.md
├─ KNOWLEDGE.md                   # M3 产出：项目级知识（新建自定义文件）
├─ staging/
│  ├─ proposals/                  #   权重提案（M2）：<case_id>.md
│  ├─ audit/                      #   生效审计（M2）：<case_id>.jsonl
│  ├─ knowledge/                  #   知识提案（M3）
│  ├─ soul-proposals/             #   设定提案（M4）
│  ├─ skills/                     #   技能草稿（M8）
│  └─ cloud/                      #   云端下发待审（M7）
└─ agents/<agentId>/agent.md      # per-agent 设定（M4）

~/.knowledge-base/                # M5 全局知识库
└─ INDEX.md                       # 一行一条摘要，注入系统提示
```

### 1.3 为什么是这个布局

- **插件独立成仓**：上游 `extensions/AGENTS.md` 明令插件只能 import `openclaw/plugin-sdk/*`；独立仓库从物理上保证不越界，且可独立发布到 npm/ClawHub。
- **staging 目录独立于五件套**：人审前的内容不进系统提示——这是"提案不是结果"在文件系统层的体现。
- **KNOWLEDGE.md 放工作区根**：与 MEMORY.md 同级，走同一条"根文件 → 上下文"装配链。

---

## 第二层：脚本（开发与验证命令链）

### 2.1 上游环境（开发机）

```bash
# 获取与安装（钉版本！）
git clone https://github.com/openclaw/openclaw && cd openclaw
git checkout <tag>                # 钉一个具体 release，不要跟 main
pnpm install                      # pnpm@11，仓库有 minimumReleaseAge=2880 防抢跑

# 本地跑起 gateway 与 CLI
pnpm gateway:dev                  # 开发模式起网关
pnpm openclaw -- --help           # CLI 入口
```

### 2.2 我们的插件仓脚本（package.json scripts）

```jsonc
{
  "scripts": {
    "build":        "tsdown",                       // 与上游同构建器，产出 dist/
    "typecheck":    "tsc --noEmit",
    "test":         "vitest run",                   // 闸门单测 + 契约测试
    "test:contract":"vitest run tests/contract",    // 对齐 plugin-sdk 契约形状
    "link:dev":     "openclaw plugins link ./plugins/weights-guard",  // 开发期挂入本地 OpenClaw
    "surface:check":"openclaw plugin-sdk:surface:check", // 校验只用了受控子路径
    "doctor":       "openclaw doctor",              // 安装后体检（doctorContract 钩子）
    "e2e:live":     "openclaw qa:e2e --filter weights-guard"          // 真模型回归
  }
}
```

### 2.3 上游自带头门禁脚本（二开必跑）

| 命令 | 作用 |
|---|---|
| `pnpm plugin-sdk:surface:check` | 校验插件只 import 受控子路径，没偷进 `src/**` |
| `pnpm plugin-sdk:api:diff` | 上游升级时对比 SDK 表面变化，评估我们插件是否受影响 |
| `pnpm test:contracts:plugins` | 插件契约测试 |
| `openclaw config get/set` | 运行时配置读写（我们的 config 项都走它） |
| `openclaw gateway status --deep` | 控制面自检 |

### 2.4 配置项（写入 `~/.openclaw/openclaw.json`，均由我们的插件声明 schema）

```jsonc
{
  "plugins": {
    "entries": {
      "@acme/openclaw-weights-guard": {
        "enabled": true,
        "config": {
          "amplitudeRange": 0.10,        // 闸门①幅度
          "evidenceTolerance": 0.001,    // 闸门④容差
          "approvalTimeoutMinutes": 30,  // 岔路甲已不用（人审移出 M2）；保留字段供 M3 复用
          "fallbackToAlgorithm": true    // 回落开关（execute 映射失败时兜底纯算法权重）
        }
      }
    }
  },
  "agents": { "defaults": { "compaction": { "memoryFlush": {
    "enabled": true,                    // 内建自动抽取保留，作为兜底
    "model": "ollama/qwen3:8b"          // flush/审查用本地模型省钱
  } } } }
}
```

---

## 第三层：模块（六个自研插件的划分与依赖）

```
                 ┌──────────────────────────┐
                 │  shared/（公共库，非插件）  │
                 │  staging 读写 · 人审适配器  │
                 │  留痕 schema · 校验基元     │
                 └────────────┬─────────────┘
        ┌─────────────────────┼──────────────────────────┐
        ▼                     ▼                          ▼
┌───────────────┐   ┌───────────────────┐      ┌──────────────────┐
│ weights-guard │   │ knowledge-harvester│     │   soul-writer    │
│ M1 闸门+拦截   │   │ M3 提炼+知识写入    │     │ M4 设定回写       │
│ M2 staging/人审│──▶│   (人审后写 KNOWLEDGE│────▶│ (人审后写 SOUL/   │
│               │   │   + agent.md)      │     │  IDENTITY/agent.md)│
└───────────────┘   └─────────┬─────────┘      └──────────────────┘
                              ▼
                    ┌───────────────────┐      ┌──────────────────┐
                    │   global-brain    │      │    cloud-sync    │
                    │ M5 全局知识注册     │◀────▶│ M7 云端提案拉取    │──▶ staging/cloud
                    │ (~/.knowledge-base)│     │ (人审后才 files.set)│
                    └───────────────────┘      └──────────────────┘
                              ▲
                    ┌───────────────────┐
                    │   skill-curator   │
                    │ M8 子agent审查+草稿 │──▶ staging/skills（人审后落 skills/）
                    └───────────────────┘
```

**依赖方向只允许向内**：六个插件都依赖 `shared/` 与 `openclaw/plugin-sdk/*`；插件之间不直接 import（对齐上游 `lint:plugins:no-extension-imports` 的纪律），协作全部通过 staging 文件与 RPC。

**各模块与官方接缝的对应**：

| 模块 | 挂接的官方接缝 | 不碰什么 |
|---|---|---|
| weights-guard | `submit_proposal` execute 映射放行 + `tool_result_persist` 五闸改写回喂 + `after_tool_call` 留痕 + `message_sending` 出站对账 | loop、harness |
| knowledge-harvester | `cron` 触发 + 会话读取 + `memory-host-core` 注册 corpus | loop |
| soul-writer | `agents.update`（IDENTITY 结构化合并）+ 工作区文件 | workspace 核心逻辑 |
| global-brain | `registerMemoryCorpusSupplement`（知识进上下文） | 记忆宿主内部 |
| cloud-sync | `gateway-client` RPC（`config.patch`/`agents.files.set`） | gateway 服务端 |
| skill-curator | 子 agent spawn + cron + `skills/` 目录约定 | 技能加载器内部 |

---

## 第四层：关键代码

> 说明：以下骨架基于 openclaw@2026.7.1-2 版 plugin-sdk 的真实 API 形状。M2 岔路甲（2026-09-02 定架构）：`submit_proposal` 的 `execute` 做语义→权重映射并直接放行，五闸搬到 `tool_result_persist`（唯一能改写工具结果回喂 LLM 的挂载点，真身 `PluginHookToolResultPersistEvent`→`{message?}`），`after_tool_call` 只读留痕（真身返回 `void`，拦不了改不了）。蓝图早期设想的 `HookDecision`/`isHookDecision`/`plugin-sdk/hook-decision-types` 均不存在，已丢弃——实际用内部中性 `GuardDecision`（`@acme/guard-shared` 的 allow/block/failClosed），仅在 handler 出口映射成真身 Result。原 `// @verify` 处已按 2026.7.1-2 d.ts 核对。人审仅存在于 M3+，不在 weights-guard 链路。

### 4.1 weights-guard：插件清单与入口

```jsonc
// plugins/weights-guard/openclaw.plugin.json
{
  "id": "weights-guard",
  "name": "Weights Guard",
  "activation": { "onStartup": true },
  "enabledByDefault": true,
  // 实际落地 manifest 无 contracts 字段：纯 hook 插件不注册工具契约
  "configSchema": {                    // 对应 openclaw.json 里 plugins.entries.*.config
    "type": "object",
    "additionalProperties": false,
    "properties": {
      "amplitudeRange":        { "type": "number", "default": 0.10 },
      "evidenceTolerance":     { "type": "number", "default": 0.001 },
      "approvalTimeoutMinutes":{ "type": "number", "default": 30 },
      "fallbackToAlgorithm":   { "type": "boolean", "default": true }
    }
  },
  "compat": { "pluginApi": ">=2026.7.1-2" }   // 钉 API 面，升级先看 api:diff
  // M1 走 A 路（纯本地内建），不走 npm 发布，故无 install.npmSpec
}
```

```ts
// M1 走 A 路（纯本地内建）：薄入口 + tsup 自包含产物双层，核心逻辑在 monorepo。
// 薄入口(ESM)：ClawX/resources/openclaw-plugins/weights-guard/index.mjs
//   —— 仅做 definePluginEntry + 注册 submit_proposal 工具(execute) + registerHook("tool_result_persist" / "after_tool_call" / "message_sending")，转调自包含产物
// 自包含产物：handler.bundle.mjs（tsup 打包 openclaw-guard-suite/plugins/weights-guard/ 的核心逻辑）
import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry"; // 已核实存在
import manifest from "./openclaw.plugin.json" with { type: "json" };
import {
  executeSubmitProposal,
  handleToolResultPersist,
  handleAfterToolCall,
  handleMessageSending,
} from "./handler.bundle.mjs";

export default definePluginEntry({
  id: manifest.id,
  name: manifest.name,
  description: "execute maps proposal→weights; five gates rewrite tool result on failure; outbound reconciliation.",
  register(api) {
    const cfg = { ...DEFAULT_CONFIG, ...(api.pluginConfig ?? {}) };
    // submit_proposal 的 execute：语义→权重映射直接放行，返回权重提案（不拦不审）
    api.registerTool?.("submit_proposal", (params) => executeSubmitProposal(params, cfg));
    // 五闸：结果落库前跑，不过则改写 ToolResultMessage 回喂 LLM 重试
    api.registerHook("tool_result_persist", async (event) =>
      handleToolResultPersist(event, cfg),
    );
    // 只读留痕：APPLIED 后落 staging（返回 void，拦不了改不了）
    api.registerHook("after_tool_call", async (event) =>
      handleAfterToolCall(event, cfg),
    );
    // 第二道防线：出站对账
    api.registerHook("message_sending", async (event) =>
      handleMessageSending(event, cfg),
    );
  },
});
```

### 4.2 weights-guard：execute 映射 + tool_result_persist 五闸（岔路甲，2026-09-02）

```ts
// plugins/weights-guard/src/execute.ts
// execute 承担「语义提案→权重映射」，直接放行执行，返回权重提案（返回值回流模型看，不进 hook）。
// 生产期调 API 取映射，测试期本地补位；先用最简单单维度线性例。
//
// ⚠️ 入参 schema 契约（真身：openclaw/plugin-sdk/tool-plugin）：LLM 填「语义提案」的入参形状形如
//   { adjustments: [{ dimension: "离职率影响", delta: +1 }], baseWeights: [...] }
//   —— defineToolPlugin 的 parameters 字段被泛型约束为 TypeBox TSchema（不接受手写 JSON Schema 对象），
//   execute 收到的 params 类型即 Static<TParamsSchema>；LLM 端 inputSchema:JsonObject 由协议层从 TSchema 自动降解。
//   故 SubmitProposalParams 应由 Type.Object({...}) 的 Static 反推，schema.ts 须用 TypeBox 声明 parameters。
export function executeSubmitProposal(
  params: SubmitProposalParams,
  config: WeightsGuardConfig = DEFAULT_CONFIG,
): SubmitProposalResult {
  const deltas = mapProposalToDeltas(params.adjustments, config); // 查映射表：语义 → 权重变化
  const weights = finalizeWeights(params.baseWeights, deltas);    // 归一化+防御截断
  // 直接返回权重提案；不拦不审。五闸在 tool_result_persist 里对该产出校验。
  return { caseId: params.caseId, weights, dimensions: params.allowedDimensions };
}
```

```ts
// plugins/weights-guard/src/handler.ts
// 五闸挂在 execute 之后的 tool_result_persist hook（唯一能改写工具结果回喂 LLM 的挂载点）。
// 真身：PluginHookToolResultPersistEvent{message:AgentMessage,toolName?,...} → Result{message?}。
export function handleToolResultPersist(
  event: ToolResultPersistEvent | undefined,
  config: WeightsGuardConfig = DEFAULT_CONFIG,
): ToolResultPersistResult | undefined {
  // 五闸只作用于唯一生效通道；其他工具结果不改写，直接放行。
  if (!isGuardedTool(event?.toolName)) return undefined;

  const result = extractToolResult(event?.message);          // 从 ToolResultMessage 取 execute 产出的权重
  const decision = runAllGates(result, config);              // 五闸=纯计算逻辑（复用 M1）；解析异常 fail-closed
  if (decision.kind === "block") {
    // 改写工具结果为失败原因回喂 LLM：content 换成提示、isError 置 true，驱动模型重试。
    return { message: rewriteToolResult(event!.message, `❌未通过:${decision.reason}，请重新提案`) };
  }
  return undefined;                                          // 通过则原样放行，交由后续 APPLIED 写审计
}
```

```ts
// plugins/weights-guard/src/gates/evidence.ts（闸门④示例：事实回查）
// 注：上游 PluginHookToolContext 无 caseRawText / toolCache 字段；
//     M1 的 GateContext 从 event.params 自取派生（caseRawText/profileCache 均派生自 params）。
export function checkEvidence(adj: Adjustment, ctx: GateContext): GateResult {
  // 原文引用必须是 case 原文的子串（防编造 case 事实）；caseRawText 派生自 event.params
  if (!ctx.caseRawText.includes(adj.case_evidence.原文引用))
    return fail("case_evidence 引用不在需求原文中");
  // 画像数值必须与画像证据一致，容差 1e-3（防编造画像数字）；profileCache 派生自 event.params
  const truth = ctx.profileCache[adj.profile_evidence.供应商]?.[adj.profile_evidence.指标];
  if (truth === undefined || Math.abs(adj.profile_evidence.数值 - truth) > ctx.tolerance)
    return fail("profile_evidence 数值与画像库不一致");
  return pass();
}
```

```ts
// plugins/weights-guard/src/fallback.ts（回落：loop 外编排，核心逻辑）
export function finalizeWeights(base: number[], deltas: number[]): number[] {
  const w = base.map((b, i) => b + deltas[i]);
  const sum = w.reduce((a, b) => a + b, 0);
  return w.map((x) => Math.min(1, Math.max(0, x / sum)));   // ② 归一化+防御截断，模型无需知晓
}
```

### 4.2.1 完整时序与出站对账（工具出口先于自然语言出口）

> 权威时序总纲见方案文档「M1+M2 合章：完整时序」。这里给**收口出站对账**的代码接缝——它是时序里最后一道、也是最容易被忽略的门：**模型第 2 轮写报告时，报告中的每个权重数字都必须能在审计轨迹里找到对应的 APPLIED 记录，否则 block 重写。**

回路顺序（岔路甲，钉死三处接缝 tool_result_persist / after_tool_call / message_sending）：

```
第1轮 tool_use=submit_proposal → execute 语义→权重映射直接放行执行(§4.2)，返回权重提案
   → tool_result_persist 跑五闸(§4.2) → [不过：改写 ToolResultMessage.content="❌未通过:原因"+isError=true 回喂 LLM 重试]
   → 过 → APPLIED 写入 staging/audit/<case_id>.jsonl；after_tool_call 只读落 staging 留痕
   → 第2轮 模型据 tool_result 组织报告，并在正文携带 [case:<case_id>] → message_sending 出站对账(第二道防线) → 用户可见
（人审不在本链路，仅存在于 M3）
```

```ts
// plugins/weights-guard/src/outbound.ts（出站对账：message_sending hook）
// 真身 event 文本在 event.content；event/ctx 均无 sessionId、case_id，故从正文 footer 关联审计。
export async function reconcileReport(
  content: unknown,
  config: WeightsGuardConfig = DEFAULT_CONFIG,
  baseDir?: string,
): Promise<GuardDecision> {
  try {
    const caseId = extractCaseId(content);                  // 从 [case:<case_id>] 提取
    if (caseId === null) return block("出站对账：缺少 case 标记（fail-closed）");

    const claims = extractClaims(content);                  // 从报告抽取“维度=数值”
    if (claims.length === 0) return allow();                // 纯定性报告无需数字对账

    const trail = await loadAuditTrail(caseId, baseDir);    // staging/audit/<case_id>.jsonl
    for (const { dimension, value } of claims) {
      const applied = trail.appliedWeights[dimension];
      if (
        applied === undefined ||
        Math.abs(applied - value) > config.evidenceTolerance
      ) {
        return block(`出站对账：${dimension}=${value} 无对应 APPLIED 审计`);
      }
    }
    return allow();
  } catch (err) {
    return block(`出站对账异常，已 fail-closed：${String(err)}`);
  }
}

export async function handleMessageSending(
  event: MessageSendingEvent | undefined,
  config: WeightsGuardConfig = DEFAULT_CONFIG,
  baseDir?: string,
): Promise<MessageSendingResult | undefined> {
  const decision = await reconcileReport(event?.content, config, baseDir);
  if (decision.kind === "block") {
    return { cancel: true, cancelReason: decision.reason };
  }
  return undefined;
}
```

**为何必须有这道门**：若只有 tool_result_persist 五闸，模型仍可"第一轮不调工具、直接在自然语言里编数字"绕过五闸。出站对账把"自然语言里的数字声明"也纳入代码管辖——**数字要么由代码渲染卡片、要么出站对账通过，二选一**（收口规则）。报告里的"思考过程"应由 `audit.ts` 的轨迹渲染成叙事模板，模型只润色句式，不产生新事实。

### 4.3 knowledge-harvester：提炼与知识注入

```ts
// plugins/knowledge-harvester/index.ts
import { definePluginEntry, type OpenClawPluginApi } from "openclaw/plugin-sdk/plugin-entry";
import { registerMemoryCorpusSupplement } from "openclaw/plugin-sdk/memory-host-core"; // 取证：注册接口
import { harvestOnce } from "./src/harvest.js";

export default definePluginEntry({
  id: "knowledge-harvester",
  name: "Knowledge Harvester",
  register(api) {
    // A. 知识文件进上下文：KNOWLEDGE.md + INDEX.md 注册为记忆 corpus（active-memory 同款路径）
    registerMemoryCorpusSupplement(api, {                   // @verify 参数形状
      files: ["KNOWLEDGE.md", "agents/*/agent.md"],
      globalIndex: "~/.knowledge-base/INDEX.md",
    });
    // B. 定时提炼：cron 走 OpenClaw 的 cron 存储运行时（参照 plugin-sdk/cron-store-runtime）
    api.registerHook("session_end", async (ev) => {         // @verify hook 名
      await harvestOnce(api, ev.sessionKey);                // 提炼→staging/knowledge/
    });
  },
});
```

```ts
// plugins/knowledge-harvester/src/harvest.ts（提炼 = 一次独立的受限调用，不复用内建 flush 的口径）
export async function harvestOnce(api: OpenClawPluginApi, sessionKey: string) {
  const transcript = await api.sessions.readTranscript(sessionKey);   // @verify
  const draft = await api.llm.complete({                              // 经 plugin-sdk 调模型
    model: "ollama/qwen3:8b",                                         // 提炼用本地模型，省钱
    temperature: 0,
    prompt: HARVEST_PROMPT,          // ← 我们的抽取标准在这里，100% 自定义
    input: transcript,
  });
  await writeStaging(api, "knowledge", draft);   // 过人审后才合并进 KNOWLEDGE.md / agent.md
}
```

### 4.4 soul-writer：设定回写（IDENTITY 结构化合并）

```ts
// plugins/soul-writer/src/apply.ts
// IDENTITY.md 是结构化记录，走官方合并写，避免破坏字段（取证：gateway agents.update 用
// mergeIdentityMarkdownContent 重写；src/agents/identity-file.ts）
export async function applySoulProposal(api: OpenClawPluginApi, p: ApprovedSoulProposal) {
  if (p.target === "identity") {
    await api.gateway.request("agents.update", {            // @verify 参数形状
      agentId: p.agentId,
      identityPatch: p.fields,                              // 字段级合并，非整文覆盖
    });
  } else {
    // SOUL.md / agent.md 是自由文本：人审后追加到对应文件
    // 主 agent → <workspace>/SOUL.md；子 agent → <workspace>/agents/<id>/agent.md
    await appendWorkspaceFile(api, p.agentId, p.file, p.content);
  }
}
```

### 4.5 cloud-sync：云端提案 → 本地人审 → RPC 生效

```ts
// plugins/cloud-sync/src/sync.ts（M7 设计骨架，尚未接入上游审批真身）
// openclaw@2026.7.1-2 的 OpenClawPluginApi 不提供可直接发起审批的方法；
// cloud-sync 需先实现独立的人审适配层，审批未落定前只能写 staging/cloud，禁止调用 RPC。
import { GatewayClient } from "@openclaw/gateway-client";

export async function syncOnce(api: OpenClawPluginApi, approval: CloudApprovalAdapter) {
  const remote = await fetchCloudManifest(api.config.cloudUrl, api.instanceToken);
  if (remote.version === api.state.get("appliedVersion")) return;

  const proposal = await writeStaging(api, "cloud", remote); // ① 先落 staging/cloud
  const verdict = await approval.request({                    // ② 自建适配层，非 plugin-sdk 现成 API
    proposal,
    kind: "cloud-config-update",
    payload: remote.diff,
    timeoutMinutes: 30,
    timeoutBehavior: "deny",
  });
  if (!verdict.approved) return;

  const gw = new GatewayClient({ url: api.config.gatewayUrl, token: api.config.gatewayToken });
  for (const item of remote.items) {                           // ③ 人审通过才调官方 RPC
    if (item.kind === "config")
      await gw.request("config.patch", { patch: item.patch });
    if (item.kind === "file" && BOOTSTRAP_ALLOWLIST.has(item.name))
      await gw.request("agents.files.set", {
        agentId: item.agentId, name: item.name, content: item.content,
      });
  }
  await api.state.set("appliedVersion", remote.version);       // ④ 上报留痕
}
```

### 4.6 skill-curator：技能生产线（Curator 蓝本）

```ts
// plugins/skill-curator/src/run.ts（纪律照抄 Hermes：只归档不删除、pinned 豁免、辅助模型审查）
export async function curatorRun(api: OpenClawPluginApi) {
  const recent = await readRecentKnowledge(api);             // 近期 KNOWLEDGE.md 增量
  const draft = await api.agents.spawn({                     // 子 agent 审查（继承 workspace）
    task: REVIEW_PROMPT, input: recent,
    model: "ollama/qwen3:8b",                                // 审查用便宜模型
  });                                                        // @verify spawn 参数形状
  if (draft.hasSkillCandidate)
    await writeStaging(api, "skills", draft.skillDraft);     // 人审通过才落 skills/custom/
  // 只归档不删除：archive 走文件移动 + .curator_state 记录，永不物理删除
}
```

### 4.7 契约测试（对齐上游 `test:contracts:plugins` 的姿势）

```ts
// plugins/weights-guard/tests/contract/hook-shape.test.ts
// 断言真身 PluginHookBeforeToolCallResult 形状（block/blockReason/params）；
// openclaw/plugin-sdk/hook-decision-types 子路径不存在，isHookDecision 亦不存在，故不使用。
it("block verdict maps to a valid PluginHookBeforeToolCallResult", () => {
  const v = blockForTest("weights_gate");        // handler 出口映射后的真身 Result
  expect(v).toMatchObject({ block: true });       // 拦截形状：{ block: true, blockReason }
  expect(typeof v.blockReason).toBe("string");
  expect(v.blockReason).not.toContain("sk-");     // blockReason 永不泄露敏感信息
});
```

---

## 第五层：验收与升级兼容

**验收命令链**（CI 必跑）：

```bash
pnpm surface:check        # 没越界 import
pnpm typecheck && pnpm test
openclaw plugin-sdk:api:diff --against <旧版本>   # 每次升级上游前跑
openclaw doctor           # 安装/修复体检
pnpm e2e:live             # 真模型回归（含五道闸门的注入/超界/编造用例）
```

**升级兼容策略**：
1. `openclaw.plugin.json` 的 `compat.pluginApi` 钉主版本；升级上游前先跑 `plugin-sdk:api:diff`；
2. 插件只依赖 plugin-sdk 子路径（受控表面有门禁保护），核心行为变更不会静默波及；
3. staging 目录与留痕文件是我们自己的格式，不随上游升级变化；
4. 月度回归（M8）同时充当"上游升级后行为是否漂移"的哨兵。

**工程量总账**：weights-guard 🔧 · knowledge-harvester 🛠 · soul-writer 🛠 · global-brain 🛠 · cloud-sync 🛠 · skill-curator 🏗 · shared 🔧。全部位于插件/文件/配置层，不 fork 上游任何文件。
