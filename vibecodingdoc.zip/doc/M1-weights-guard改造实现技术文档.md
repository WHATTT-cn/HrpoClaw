# M1 weights-guard 改造实现技术文档

> 知识型合规权重微调 Agent 的安全组件落地实现。核心理念:**LLM 只是提案,代码才是法律**。
>
> 本文档记录 M1 阶段 weights-guard 插件从架构设计、五道闸门、handler 组装、A 路桥接打包、ClawX 安装接线到侧边栏模式页 UI 的完整实现方式,供后续业务模式插件复用。

---

## 1. 总体目标与全局约束

weights-guard 是在 OpenClaw 上做二次开发的合规安全组件,在 `before_tool_call` 阶段对 LLM 提出的权重调整提案做 **fail-closed** 校验:任何越界、无据、被注入或无法判定的改动一律拦截或回落。

**六条不可违背的全局规则:**

1. 不修改 OpenClaw 上游源码任何一行,所有改造以插件形式实现,代码仓库为 `openclaw-guard-suite/`(pnpm monorepo)。
2. 施工蓝图是 `doc/OpenClaw源码改造技术文档.md`,所有标 `// @verify` 处必须先在克隆的上游源码全文检索核对,签名/路径漂移时停下报告等确认。
3. 每完成一个任务运行验收命令并贴输出,验收不过不进入下一任务。
4. 涉及业务规则/阈值/默认值(👤 标出)不许替用户决定,列选项 + 建议等拍板。
5. 安全红线:任何"失败"分支必须 fail-closed(拦截/回落),禁止"解析失败就放行"。
6. 每个闸门、每个 hook 都要有 vitest 契约测试。

---

## 2. 双层架构与上游基线

ClawX 与后端 openclaw 包是双层架构:

- **`ClawX/`** 是 Electron 应用,走 ACP 协议;人审接缝在 [`ClawX/electron/services/acp-chat-service.ts`](../ClawX/electron/services/acp-chat-service.ts) 的 `requestPermission`。
- **真正的 agent runtime** 是被 fork 的后端 openclaw npm 包,版本 `openclaw@2026.7.1-2`,位于 `ClawX/node_modules/openclaw/`。
- **plugin-sdk 真身** 在 `node_modules/openclaw/dist/plugin-sdk/`,经 package.json exports 映射:`./plugin-sdk/plugin-entry` 与 `./plugin-sdk/core` 都导出 `definePluginEntry`。

> **核对纪律:** 核对上游签名一律去 `node_modules/openclaw/dist/`,而非 ClawX 源码(前序曾在 ClawX 源码 grep 零命中误判漂移,真相是 plugin-sdk 为 npm 包导出)。

### 2.1 before_tool_call hook 真身契约(2026.7.1-2 实测)

实测自 `dist/hook-types-DQ9eTy2x.d.ts` + `types-DaHgOqFX.d.ts`,蓝图 2026.8.1 有漂移,以实测为准:

- 拦截契约 = `PluginHookBeforeToolCallResult { params?; block?: boolean; blockReason?: string; requireApproval?{...} }`。
- 返回语义:`return void` = 放行;`return { block: true, blockReason }` = 拦截;`return { params: {...} }` = 改写入参后放行。
- 蓝图中的 `HookDecision` / `isHookDecision` / `plugin-sdk/hook-decision-types` **均不存在**,已丢弃。
- `api.pluginConfig` 是属性 `Record<string, unknown>`(非泛型方法);`api.config` 是 `OpenClawConfig`。
- `registerHook(events: string | string[], handler: InternalHookHandler, opts?)`;`before_tool_call` / `session_end` 在 `PluginHookName` 中。
- `PluginHookToolContext` 无 `caseRawText` / `toolCache`,evidence 上下文从 `event.params` 自取。
- 导入路径 `import { definePluginEntry, OpenClawPluginApi } from "openclaw/plugin-sdk/plugin-entry"` 已核对存在。

---

## 3. 仓库拓扑与目录职责

采用双仓协作模式:

```
SupplierOrderAgent/
├── openclaw-guard-suite/          # 源码工厂(monorepo):闸门/handler/shared + 测试
│   ├── shared/                    # @acme/guard-shared 公共库(GuardDecision/allow/block/failClosed)
│   │   └── src/index.ts
│   ├── plugins/weights-guard/     # weights-guard 插件核心逻辑
│   │   ├── src/
│   │   │   ├── gates/             # 五道闸门(纯函数)
│   │   │   ├── pipeline.ts        # 五闸编排
│   │   │   ├── handler.ts         # before_tool_call 组装层
│   │   │   ├── types.ts           # 业务类型契约
│   │   │ ├── bundle-entry.ts    # tsup 打包入口(选项C)
│   │   │   └── index.ts
│   │   ├── tests/                 # vitest 契约测试(闸门 + handler)
│   │   └── tsup.config.ts         # 打包配置(产物写进 ClawX/resources)
│   └── tests/contract/            # shared 契约测试
│
└── ClawX/                         # 装配打包厂(Electron 外壳)
    ├── resources/openclaw-plugins/weights-guard/   # A 路薄入口 + tsup 产物
    │   ├── handler.bundle.mjs     # tsup 唯一产物(自包含,~11.7KB)
    │   ├── index.mjs              # 薄入口(~3.0KB,仅接线)
    │   ├── openclaw.plugin.json   # manifest(enabledByDefault:true + configSchema)
    │   └── package.json
    ├── electron/                  # 安装接线 + host-api modes 域
    └── src/                       # 侧边栏「模式」页 UI(renderer 扩展)
```

**目录职责(Q6 拍板):**

- **核心逻辑**在 monorepo `plugins/<id>/`(闸门/handler/shared + 测试),可独立 vitest,不依赖上游 hook 类型。
- **`resources/openclaw-plugins/<id>/`** 仅承载薄入口 + tsup 构建产物,不含任何业务逻辑。
- **产物已 commit 进 ClawX Git**,靠 electron-builder 的 `extraResources` 原样搬进包。

### 3.1 关键设计取舍

| 决策点 | 选择 | 理由 |
| --- | --- | --- |
| Q4 加载路径 | A 路(纯本地内建) | 先例 clawx-openai-image;源码放 resources,不走 npm 发布 |
| Q5 安装策略 | 启动恒定安装 + enabledByDefault:true + 模式页可关 | 安全组件默认开启,fail-closed 优 |
| Q6 目录职责 | 核心逻辑放 monorepo,resources 薄入口 | 逻辑可测、产物可审、职责清晰 |
| 桥接方案 | 选项C:tsup 自包含 bundle | 零运行时依赖,resources 只承载产物 |
| 安装接线 | 选项A:复用 ensurePluginInstalled | 对照 clawx-openai-image 先例 |

---

## 4. 公共库 @acme/guard-shared:中性决策模型

所有闸门与 handler 统一使用中性决策类型 `GuardDecision`,仅在 hook 出口映射成上游真身,从而闸门逻辑可独立单测、解耦上游。

```ts
// openclaw-guard-suite/shared/src/index.ts
export type GuardDecision =
  | { readonly kind: "allow"; readonly params?: Record<string, unknown> }
  | { readonly kind: "block"; readonly reason: string };

export function allow(params?: Record<string, unknown>): GuardDecision { ... }
export function block(reason: string): GuardDecision { ... }

/** fail-closed 包装:抛错或返回非法值一律回落 block,绝不放行。 */
export function failClosed(label: string, run: () => GuardDecision): GuardDecision {
  try {
    const decision = run();
    if (decision.kind !== "allow" && decision.kind !== "block") {
      return block(`${label}: 非法决策,已 fail-closed`);
    }
    return decision;
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return block(`${label}: 闸门异常已 fail-closed(${detail})`);
  }
}
```

> **安全红线落地:** `failClosed` 是全局规则 5 的代码化身——任何"失败/无法判定"分支都回落 `block`。每一层(闸门、pipeline、handler、薄入口)都被 `failClosed` 或 try/catch 包裹。

---

## 5. 五道闸门设计

五道闸门均为纯函数,输入业务数据、输出 `GuardDecision`,位于 [`openclaw-guard-suite/plugins/weights-guard/src/gates/`](../openclaw-guard-suite/plugins/weights-guard/src/gates)。

| # | 闸门 | 文件 | 职责 | fail-closed 触发 |
| --- | --- | --- | --- | --- |
| ① | amplitude | `amplitude.ts` | 单维度调整幅度不得超过 ±阈值(默认 0.10) | delta 非数值 / 超幅 |
| ② | normalize | `normalize.ts` | 基准 + 增量归一化,产出最终 weights | 长度不齐 / 非数组 / 结果非法 |
| ③ | whitelist | `whitelist.ts` | 维度必须在允许白名单内 | 维度缺失 / 不在白名单 |
| ④ | evidence | `evidence.ts` | 事实回查(容差 0.001):原文引用须真实存在、画像数值须一致 | 证据缺失 / 回查不符 |
| ⑤ | injection | `injection.ts` | 注入前置过滤(最外层防线) | 命中注入模式 |

### 5.1 编排顺序与短路(pipeline.ts)

**执行顺序:injection → whitelist → amplitude → evidence → normalize**。前四道任一 `block` 即整体 block 并立即短路(不再往下跑,避免脏数据进归一化);前四道全过后跑 normalize 产出最终 weights。

```ts
// openclaw-guard-suite/plugins/weights-guard/src/pipeline.ts
export function runAllGates(input: PipelineInput): GuardDecision {
  return failClosed("pipeline", () => {
    if (!input || typeof input !== "object") return block("pipeline: 输入非法");

    const g5 = injectionGate(adjustments, injectionPatterns);   // ⑤ 注入
    if (g5.kind === "block") return g5;
    const g3 = whitelistGate(adjustments, allowedDimensions);   // ③ 白名单
    if (g3.kind === "block") return g3;
    const g1 = amplitudeGate(adjustments, amplitudeRange);      // ① 幅度
    if (g1.kind === "block") return g1;
    const g4 = evidenceGate(adjustments, context);              // ④ 事实回查
    if (g4.kind === "block") return g4;

    // 安全:提案数不得超过基准维度数,否则会静默丢弃提案(fail-closed 拒绝)
    if (adjustments.length > baseWeights.length) {
      return block(`pipeline: 提案数超过基准维度数,拒绝(fail-closed)`);
    }
    const deltas = toDeltaVector(adjustments, baseWeights.length);
    const g2 = normalizeGate(baseWeights, deltas);              // ② 归一化
    if (g2.kind === "block") return g2;

    const weights = g2.params?.["weights"];
    if (!Array.isArray(weights)) return block("pipeline: normalize 未产出合法 weights(fail-closed)");
    return allow({ weights });
  });
}
```

> **顺序设计理由:** injection 作为最外层防线优先拦截恶意输入;normalize 放最后,只有前四道全过才归一化,确保进归一化的数据已合规。

### 5.2 业务类型契约(types.ts)

```ts
export interface WeightsGuardConfig {
  readonly amplitudeRange: number;      // 闸门1 幅度上限,默认 0.10
  readonly evidenceTolerance: number;   // 闸门4 容差,默认 0.001
  readonly approvalTimeoutMinutes: number; // 人审超时,默认 30
  readonly fallbackToAlgorithm: boolean;   // 失败回落算法,默认 true
}

export interface Adjustment {
  readonly dimension: string;           // 闸门3 白名单校验对象
  readonly delta: number;               // 闸门1 幅度 / 闸门2 归一化输入
  readonly case_evidence?: CaseEvidence;    // 闸门4;缺失必须 fail-closed
  readonly profile_evidence?: ProfileEvidence;
}

export interface GateContext {
  readonly caseRawText: string;         // 闸门4 校验原文引用
  readonly profileCache: Readonly<Record<string, Readonly<Record<string, number>>>>;
  readonly tolerance: number;           // 来自配置 evidenceTolerance
}
```

> **上游解耦:** `GateContext` 从 `event.params` 派生而来(上游 `PluginHookToolContext` 无 `caseRawText`/`toolCache`,故自取)。

---

## 6. before_tool_call handler 组装层

[`handler.ts`](../openclaw-guard-suite/plugins/weights-guard/src/handler.ts) 分两层,便于单测与解耦上游:

1. **`decideFromParams(params, config)`** — 纯函数:从工具入参解析五闸输入 → `runAllGates` → 中性 `GuardDecision`。不依赖任何上游 hook 类型,可独立 vitest。
2. **`toHookResult(decision, originalParams)`** — 把中性决策映射成上游真身:
   - `block` ⇒ `{ block: true, blockReason }`
   - `allow` 且有改写 weights ⇒ `{ params: { ...原params, weights } }`
   - `allow` 且无改写 ⇒ `undefined`(= 放行,上游语义 `return void`)

```ts
export const DEFAULT_CONFIG: WeightsGuardConfig = {
amplitudeRange: 0.1, evidenceTolerance: 0.001,
  approvalTimeoutMinutes: 30, fallbackToAlgorithm: true,
};

export function decideFromParams(params: unknown, config = DEFAULT_CONFIG): GuardDecision {
  return failClosed("handler", () => {
    const rec = asRecord(params);
    if (!rec) return block("handler: 工具入参非法(fail-closed)");
    return runAllGates(buildInput(rec, config));
  });
}

/** 端到端主体:解析入参 → 五闸决策 → 映射真身结果。供薄入口调用。 */
export function handleBeforeToolCall(params: unknown, config = DEFAULT_CONFIG): HookResult | undefined {
  const original = asRecord(params) ?? {};
  return toHookResult(decideFromParams(params, config), original);
}
```

> **入参解析兜底:** `buildInput` 对缺失字段以安全空值兜底(空数组/空串/空对象),交由各闸门 fail-closed 判定,而非直接放行。

---

## 7. A 路桥接与打包(选项C)

### 7.1 tsup 打包入口

[`bundle-entry.ts`](../openclaw-guard-suite/plugins/weights-guard/src/bundle-entry.ts) 只导出薄入口真正需要的 API,保持产物表面最小:

```ts
export { handleBeforeToolCall, DEFAULT_CONFIG } from "./handler.js";
export type { HookResult } from "./handler.js";
export type { WeightsGuardConfig } from "./types.js";
```

### 7.2 tsup 配置

[`tsup.config.ts`](../openclaw-guard-suite/plugins/weights-guard/tsup.config.ts) 把 handler 核心(含 `@acme/guard-shared`)打成单文件 ESM,直接输出到 ClawX 的 A 路 resources 目录:

```ts
export default defineConfig({
  entry: { "handler.bundle": "src/bundle-entry.ts" },
  outDir: "../../../ClawX/resources/openclaw-plugins/weights-guard", // 跨目录写进 ClawX
  format: ["esm"],
  outExtension: () => ({ js: ".mjs" }),   // 薄入口是 ESM,产物须 .mjs
  bundle: true,
  noExternal: ["@acme/guard-shared"],     // 内联 workspace 依赖,产物零运行时依赖
  dts: false,                             // 薄入口只 import 运行时函数,不需 .d.ts
  external: ["openclaw"],                 // openclaw 由宿主提供,绝不打进产物
});
```

**关键约束:**

- `format: esm` + `.mjs`:薄入口 `index.mjs` 是 ESM,产物须为 `.mjs`。
- `bundle + noExternal`:把 `@acme/guard-shared` 内联,产物零运行时依赖(自包含)。
- `outDir` 指向 `ClawX/resources/...`:核心在 monorepo,resources 仅载构建产物(Q6)。
- `dts: false`:薄入口只 import 运行时函数;且本包是 composite 项目引用模式(`tsc -b`),tsup 独立 dts 生成会冲突(TS6307)。类型契约由 monorepo 源码 `tsc -b` 保证。
- `external: ["openclaw"]`:openclaw 由宿主提供,只有薄入口才 `import 'openclaw/plugin-sdk/*'`。

---

## 8. resources 三文件(A 路薄入口)

均在 [`ClawX/resources/openclaw-plugins/weights-guard/`](../ClawX/resources/openclaw-plugins/weights-guard):

### 8.1 index.mjs — 薄入口(仅接线)

职责边界:只做接线,不含任何业务逻辑。五闸核心全部经 tsup 打包成 `handler.bundle.mjs` 由此 import。

```js
import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { handleBeforeToolCall, DEFAULT_CONFIG } from "./handler.bundle.mjs";

export const pluginEntry = definePluginEntry({
  id: "weights-guard",
  name: "Weights Guard",
  register(api) {
    const config = resolveConfig(api?.pluginConfig); // 浅合并进 DEFAULT_CONFIG

    api.registerHook("before_tool_call", async (event) => {
      try {
        const params = event?.params ?? {};
        const result = handleBeforeToolCall(params, config);
        if (result?.block) return { block: true, blockReason: result.blockReason };
        if (result?.params) return { params: result.params };
        return undefined; // 放行
      } catch (err) {
        // fail-closed:接线层任何异常一律拦截,绝不放行
        return { block: true, blockReason: `weights-guard 接线层异常,已 fail-closed:${...}` };
      }
    });
  },
});
```

### 8.2 openclaw.plugin.json — manifest

```jsonc
{
  "id": "weights-guard",
  "entry": "index.mjs",
  "enabledByDefault": true,        // 安全组件默认开启(Q5)
  "configSchema": {                // amplitudeRange/evidenceTolerance/approvalTimeoutMinutes/fallbackToAlgorithm
    "type": "object",
    "additionalProperties": false,
    "properties": { ... }
  }
}
```

> **注意:** manifest 无 `contracts` 字段(纯 hook 插件,不注册工具契约)。

---

## 9. ClawX 安装接线(三处)

对照 clawx-openai-image 先例,在 [`ClawX/electron/utils/plugin-install.ts`](../ClawX/electron/utils/plugin-install.ts) 与 [`main/index.ts`](../ClawX/electron/main/index.ts) 三处接线:

**① 信任白名单** — `TRUSTED_OFFICIAL_EXTENSION_PLUGINS` 加条目:

```ts
'weights-guard': {
  npmName: 'weights-guard-plugin',
  recordSource: 'path',   // 标记为 path 来源(本地内建,非 npm)
},
```

**② 安装函数** — `ensureWeightsGuardPluginInstalled()`:

```ts
export function ensureWeightsGuardPluginInstalled(): Promise<PluginInstallResult> {
  return ensurePluginInstalled(
    'weights-guard',
    buildCandidateSources('weights-guard'), // 从 resources 铺到 ~/.openclaw/extensions/
    'Weights Guard',
  );
}
```

**③ 启动调用** — `main/index.ts` 的 `initialize()` 内 fire-and-forget:

```ts
// weights-guard 是 security/compliance hook 插件,启动即安装
void ensureWeightsGuardPluginInstalled().catch((error) => {
  logger.error('Failed to ensure weights-guard plugin installed', error);
});
```

> **A 路加载机制:** 启动时 `ensurePluginInstalled(dirName, buildCandidateSources(dirName), label)` 把 resources 实体铺到 `~/.openclaw/extensions/<dirName>/`;打包时靠 electron-builder.yml 的 `extraResources`(`resources/`→`resources/`)原样搬进包,**不进 after-pack.cjs 的 BUNDLED_PLUGINS**(那是从 node_modules 复制 npm 包的 B 路机制)。

### 9.1 接线避坑

- `ensureAllBundledPluginsInstalled` 已废弃、无调用者,勿依赖。
- 非渠道插件塞进 `CHANNEL_PLUGIN_MAP` 会被 cleanup 误删,weights-guard 绝不进该表。

---

## 10. 模式页 UI 与 host-api 链路

M1 的运行时闸门(§4-§9)与 UI 完全解耦:UI 只负责读写"是否启用"这一个开关,底层校验逻辑不因 UI 存在与否而改变。UI 采用 ClawX 的 **renderer 扩展框架**(`src/extensions/`),以侧边栏独立"模式"页形态挂载,与"模型/Agents/频道/技能/定时任务"平级。

### 10.1 renderer 扩展定义

在 [`ClawX/src/extensions/weights-guard/index.ts`](../ClawX/src/extensions/weights-guard/index.ts) 注册扩展,声明 `sidebar.navItems`(侧边栏入口)与 `routes.routes`(路由页):

```ts
import { Store } from 'lucide-react';
import { registerRendererExtensionModule } from '../loader';
import type { RendererExtension } from '../types';
import { WeightsGuardModePage } from './WeightsGuardModePage';

export const WEIGHTS_GUARD_EXTENSION_ID = 'weights-guard';
export const WEIGHTS_GUARD_ROUTE_PATH = '/modes';

function createWeightsGuardExtension(): RendererExtension {
  return {
    id: WEIGHTS_GUARD_EXTENSION_ID,
    sidebar: {
      id: WEIGHTS_GUARD_EXTENSION_ID,
      navItems: [{ to: WEIGHTS_GUARD_ROUTE_PATH, icon: Store, label: '模式', testId: 'sidebar-nav-modes' }],
    },
    routes: {
      id: WEIGHTS_GUARD_EXTENSION_ID,
      routes: [{ path: WEIGHTS_GUARD_ROUTE_PATH, component: WeightsGuardModePage }],
    },
  };
}
registerRendererExtensionModule(WEIGHTS_GUARD_EXTENSION_ID, createWeightsGuardExtension);
```

**消费链(框架侧,已就绪,未改动):**

- 侧边栏:[`Sidebar.tsx`](../ClawX/src/components/Sidebar.tsx) 的 `getExtraNavItems()` 收集所有扩展 navItems,与内置项合并渲染。
- 路由:[`App.tsx`](../ClawX/src/App.tsx) 的 `extraRoutes` map 把扩展 routes 渲染为 `<Route>`;`import './extensions/weights-guard'` 副作用触发注册。

### 10.2 模式页组件

[`WeightsGuardModePage.tsx`](../ClawX/src/extensions/weights-guard/WeightsGuardModePage.tsx) 参照 Skills 页布局,只做一件事:读写启用开关,读失败 fail-closed 视为启用。

```tsx
export function WeightsGuardModePage() {
  const [enabled, setEnabled] = useState(true); // 默认 true(enabledByDefault)
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    hostApi.modes.getWeightsGuardEnabled()
      .then(setEnabled)
      .catch(() => setEnabled(true)) // fail-closed:读失败视为启用
      .finally(() => setLoading(false));
  }, []);

  const handleToggle = async (next: boolean) => {
    setSaving(true);
    try {
      await hostApi.modes.setWeightsGuardEnabled(next);
      setEnabled(next);
    } finally {
      setSaving(false);
    }
  };
  // JSX:h1"模式" + 简介"管理和定制HR专项任务" + 开关卡片(Label"供应商管理" + Switch)
}
```

### 10.3 host-api modes 域全链路

开关的持久化经 ClawX host-api 一路打到 electron 主进程,读写 openclaw 配置中 `plugins.entries['weights-guard'].enabled`:

```
前端 hostApi.modes.getWeightsGuardEnabled()   // src/lib/host-api.ts
  → invokeHost('modes.getWeightsGuardEnabled')
  → ipcMain 'host:invoke'                       // electron/ipc-handlers.ts
  → registerCoreServices 服务工厂 → createModesApi()   // electron/services/modes-api.ts
  → getWeightsGuardEnabled()                    // electron/utils/weights-guard-mode.ts
  → 读 plugins.entries['weights-guard'].enabled(无 entry / 读失败 → 返回 true,fail-closed)
```

对称地,`setWeightsGuardEnabled(next)` 落到 [`weights-guard-mode.ts`](../ClawX/electron/utils/weights-guard-mode.ts) 写回同一 entry。

> **fail-closed 贯穿两层:** electron 层 `getWeightsGuardEnabled` 读不到 entry 或异常返回 `true`;UI 层 `.catch(() => setEnabled(true))`。用户永远不会因为"读取失败"而在无防护状态下静默运行。

> **契约域接线(已就绪,未改动):** [`contract.ts`](../ClawX/electron/services/host-contract/contract.ts) 的 modes 域 + [`ipc-handlers.ts`](../ClawX/electron/ipc-handlers.ts) 注册 + [`host-api.ts`](../ClawX/src/lib/host-api.ts) 的 `hostApi.modes` 封装,均在 UI 落地前铺好。UI 形态从"设置页分节"改为"侧边栏独立页"时,这条链路整体复用,只改了 renderer 扩展定义(§10.1)与页面组件(§10.2)。

---

## 11. 打包与刷新流程

因核心逻辑在 monorepo、产物在 ClawX/resources(§7 选项C),两个仓库的关系决定了两类场景:

### 场景 A — 仅打包 ClawX(不改闸门逻辑)

只做 ClawX 侧改动(UI、接线、文案等),`handler.bundle.mjs` 无需重生成:

```bash
cd ClawX
pnpm install
pnpm package    # electron-builder 打包,extraResources 原样搬 resources/
```

### 场景 B — 改了闸门 / handler / shared 逻辑

**必须先在 monorepo 重跑 bundle 刷新产物,否则打进包的是旧逻辑:**

```bash
# 1) monorepo:测试 + 重新打包 handler.bundle.mjs
cd openclaw-guard-suite
pnpm test        # 95 契约测试必须全绿
pnpm bundle      # tsup 重生成 ClawX/resources/openclaw-plugins/weights-guard/handler.bundle.mjs

# 2) 提交刷新后的 handler.bundle.mjs(它虽在 ClawX 目录,却是 monorepo 的构建产物)

# 3) 再打包 ClawX
cd ../ClawX
pnpm package
```

> **打包铁律:** `handler.bundle.mjs` 是 tsup 从 monorepo 源码生成的产物,却物理落在 `ClawX/resources/` 下。改了 `handler.ts` / `pipeline.ts` / 任一 gate / `@acme/guard-shared` 后**必须重跑 `pnpm bundle`**,否则 ClawX 打包搬进去的仍是旧产物,线上跑的是旧逻辑。

> **extraResources 机制:** [`electron-builder.yml`](../ClawX/electron-builder.yml) 把 `resources/`→`resources/` 原样搬进包(A 路),不经 after-pack.cjs 的 `BUNDLED_PLUGINS`(那是从 node_modules 复制 npm 包的 B 路)。

---

## 12. 验收命令

每完成一个任务运行对应验收命令并贴输出,验收不过不进入下一任务(全局规则 3)。

| 场景 | 命令 | 通过标准 |
| --- | --- | --- |
| monorepo 闸门/handler 契约 | `cd openclaw-guard-suite && pnpm test` | 95/95 全绿 |
| monorepo 重生成产物 | `cd openclaw-guard-suite && pnpm bundle` | 生成 `handler.bundle.mjs`(~11.7KB,自包含) |
| ClawX 类型检查 | `cd ClawX && pnpm run typecheck` | node + web 两侧均无错误 |
| 重启验证 | `cd ClawX && pnpm run init && pnpm dev` | 侧边栏出现"模式"入口,页面开关可读写 |

> **纯文档改动**(如本技术文档)无需 typecheck;但**任何代码改动**都须 `pnpm run typecheck` 双侧全绿。

---

## 13. 可复用模板总结

M1 走通的这套脚手架路径,可作为**后续所有业务模式插件**的复用模板。新增一个模式插件时,照下述五步走:

| 步骤 | 位置 | 做什么 |
| --- | --- | --- |
| ① 中性决策模型 | `openclaw-guard-suite/shared` | 复用 `GuardDecision` + `allow/block/failClosed`,新逻辑照 fail-closed 范式写 |
| ② 闸门 + handler | `openclaw-guard-suite/plugins/<新插件>` | 写各道 gate(纯函数)+ pipeline 编排(短路)+ handler 组装,配 vitest 契约测试 |
| ③ tsup 桥接 | `plugins/<新插件>/tsup.config.ts` | 复用选项C:`bundle-entry.ts` → 自包含 `handler.bundle.mjs`,`outDir` 指向 ClawX/resources |
| ④ resources 薄入口 | `ClawX/resources/openclaw-plugins/<新插件>/` | `index.mjs`(仅接线)+ `openclaw.plugin.json`(manifest)+ `package.json` |
| ⑤ ClawX 三处接线 | `electron/utils/plugin-install.ts` + `main/index.ts` | 信任白名单 + `ensureXxxInstalled()` + `initialize()` 内 fire-and-forget 调用 |
| ⑥ 侧边栏页 UI(可选) | `ClawX/src/extensions/<新插件>/` | renderer 扩展(`sidebar.navItems` + `routes.routes`)+ 页面组件 + host-api 域读写开关 |

**复用要点:**

- **核心在 monorepo,产物在 resources**:源码工厂与运行时载荷物理分离,Q6 定调。
- **fail-closed 是模板底色**:每道 gate、每个 hook、UI 读取都要有失败回落分支,禁止"解析失败就放行"。
- **多任务隔离**:不同部门任务的模式插件互不冲突,可按任务独立开关/切换(产品路线图诉求);每个插件独立 id、独立 manifest、独立侧边栏入口。
- **上游零侵入**:全程不改 openclaw npm 包一行;改 ClawX 外壳(src/electron/shared/resources)不算改上游。

---

> 本文档随 M1 实现同步维护。后续新增模式插件时,§13 是最短落地路径;§4-§9 是可照抄的实现细节;§10 是 UI 层可选接线。

