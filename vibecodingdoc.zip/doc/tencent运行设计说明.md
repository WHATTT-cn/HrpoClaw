# 运行方式与实施说明:桌面助手「一句话代办」

> 版本:V2.0(2026-09-09)
> 范围:①从接收一句话指令到任务完成的运行方式与用户介入节点;②在 ClawX(OpenClaw 内核)上的代码级落地方案,可直接作为 AI coding 工具的改造任务书。
> 前置阅读:《项目技术说明书》(既有的 A 路插件机制、三处接线、fail-closed 红线在此完全沿用)

---

## 第一部分:运行方式设计

### 1.1 总体运行流程

```
用户一句话指令
      │
      ▼
① 意图解析与边界判定 ──── 超出边界 ──→ 明确拒接(说明原因)
      │                          ↘ 信息不完备 → 追问一轮,补全失败则拒接
      ▼ 在边界内
② 生成任务计划(Plan):步骤清单 + 每步验收条件 + 风险标记
      │
      ▼
【介入点1 · 计划确认】用户:批准 / 调整步骤 / 取消
      │ 批准
      ▼
③ 逐步执行:执行动作 → 结果回读校验 → record_task_step 落执行记录
      │
      ├─ 命中高风险步骤 ──→ 【介入点2 · 人审弹窗】批准 / 驳回(驳回即暂停,等用户指示)
      ├─ 任一步失败/校验不通过 ──→ fail-closed 自动暂停,报告现场,等用户决策
      ▼
④ 完成汇总:成果清单 + 执行记录回放 + 回滚入口
      │
      ▼
【介入点3 · 结果验收】用户:验收通过 / 要求修正 / 回滚
```

**核心原则(继承项目既有红线)**:
- **LLM 只负责提案,代码(插件闸门/人审)才是法律**——计划确认、执行记录、高风险放行全部由插件层强制,不依赖模型自觉。
- **fail-closed**:任何"失败/无法判定"分支一律暂停并报告,绝不"解析失败就放行",绝不在异常时自行蛮干。

### 1.2 六个运行阶段详述

**阶段① 意图解析与边界判定**
解析指令得到:任务目标、涉及对象(文件/联系人)、完成判定条件。对照能力边界(见《01-能力说明》)三向分流:在边界内→进入规划;信息不完备→追问一轮,补全失败→拒接;超出边界→明确拒接并说明原因,不含糊执行。

**阶段② 生成任务计划**
规划器产出结构化计划,每条步骤含三要素:

| 计划要素 | 内容 | 示例 |
|---|---|---|
| 步骤清单 | 有序步骤,每步指定目标软件与抽象操作 | 步骤3:文件管理器 · 按供应商/月份归档发票 |
| 验收条件 | 每步完成后的机器可校验标准 | 「票据/2026-08/ 下生成 6 个 PDF」 |
| 风险标记 | 标注不可逆步骤,触发人审闸门 | 步骤5「发送邮件」riskLevel: high |

**阶段③ 逐步执行 + 执行记录**
每步:执行动作 → **结果回读**(重读文件系统/界面状态,核对验收条件)→ 调 `record_task_step` 写入 `执行记录.json`。写库不在工具 execute(execute 仅兜底回执防绕审),由 `before_tool_call` 的 `onResolution` 落库——与 maintenance-records 同一模式。

**阶段④ 完成汇总与验收**
产出汇总报告:成果清单、执行记录回放、回滚入口。用户在介入点3 验收,可要求修正或回滚。

### 1.3 用户介入节点(三节点 + 异常隐式节点)

| 介入点 | 时机 | 用户动作 | 助手等待状态 | 超时行为 |
|---|---|---|---|---|
| **介入点1 · 计划确认** | 计划生成后、动手前 | 批准 / 调整步骤 / 取消 | 挂起,不动任何文件 | 超时自动取消,不执行 |
| **介入点2 · 高风险人审** | 命中不可逆步骤时 | 批准 / 驳回(可查看草稿全文) | 暂停在该步骤 | 超时默认**驳回**(timeoutBehavior: deny) |
| **介入点3 · 结果验收** | 任务完成后 | 验收 / 要求修正 / 回滚 | 任务结束,等待反馈 | 无超时,记录保持可查 |
| **隐式节点 · 异常暂停** | 任一步失败/校验不通过 | 重试 / 跳过 / 终止回滚 | fail-closed 暂停并报告现场 | — |

**设计哲学:用户从"操作员"变为"审批员"。** 全程只在三个(异常时四个)节点做决策,不触碰任何软件操作。

---

## 第二部分:实施总览——改造地图

新增**第三条 agent 链路 `assistant`**,与 PO / FDE 完全对称:一纯指引插件 + 一工具人审插件 + 一看板 + 三处接线。

### 2.1 对称性速查

| 维度 | PO 链路 | FDE 链路 | **assistant 链路(新增)** |
|---|---|---|---|
| 纯指引插件 | weights-guard | equipment-guard | **todo-guard** |
| 工具人审插件 | experience-capture | maintenance-records | **task-ledger** |
| 写工具 | record_po_experience | record_maintenance | **record_task_step** |
| 读工具 | 无 | read_maintenance | **read_task_ledger** |
| 数据文件 | Experience.md | 维修记录.json | **执行记录.json**(workspace-assistant) |
| 前端看板 | SupplierPortraitDashboard | MaintenanceRecordDashboard | **TaskLedgerDashboard** |
| agent id | po | fde | **assistant** |

### 2.2 改造文件清单(AI coding 直接照此施工)

| # | 仓库/目录 | 文件 | 动作 | 仿照对象 |
|---|---|---|---|---|
| 1 | openclaw-guard-suite | `plugins/todo-guard/src/guidance.ts` | 新建 | weights-guard/src/guidance.ts |
| 2 | openclaw-guard-suite | `plugins/todo-guard/src/bundle-entry.ts` | 新建 | weights-guard 同名(只导出指引函数) |
| 3 | openclaw-guard-suite | `plugins/todo-guard/tsup.config.ts` 等工程文件 | 新建 | weights-guard 全套(outDir 相对路径指 ClawX) |
| 4 | openclaw-guard-suite | `plugins/task-ledger/src/handler.ts` | 新建 | maintenance-records/src/handler.ts |
| 5 | openclaw-guard-suite | `plugins/task-ledger/src/bundle-entry.ts` + 工程文件 | 新建 | maintenance-records 全套 |
| 6 | openclaw-guard-suite | `plugins/*/src/*.test.ts` | 新建 | 既有插件测试,typecheck+test 必须全绿 |
| 7 | ClawX | `resources/openclaw-plugins/todo-guard/{index.mjs, openclaw.plugin.json, handler.bundle.mjs}` | 新建(bundle 产物) | weights-guard 目录 |
| 8 | ClawX | `resources/openclaw-plugins/task-ledger/{index.mjs, openclaw.plugin.json, handler.bundle.mjs}` | 新建(bundle 产物) | maintenance-records 目录 |
| 9 | ClawX | `electron/utils/plugin-install.ts` | 改:TRUSTED 注册表 +2,ensure 函数 +2 | 既有四插件条目,recordSource:'path' |
| 10 | ClawX | `electron/main/index.ts` | 改:fire-and-forget 调两个 ensure | 既有调用处 |
| 11 | ClawX | `electron/utils/agent-config.ts` | 改:新增 PRESET_ASSISTANT | PRESET_PO / PRESET_FDE |
| 12 | ClawX | `src/pages/Chat/index.tsx` | 改:按 currentAgentId 挂载看板 | PRESET_PO_AGENT_ID 条件挂载处 |
| 13 | ClawX | `src/components/TaskLedgerDashboard.tsx` | 新建 | MaintenanceRecordDashboard.tsx |

### 2.3 数据契约:`执行记录.json`(单一权威源)

路径:`~/.openclaw/workspace-assistant/执行记录.json`,JSON 数组,每步一条:

```json
{
  "taskId": "task-20260909-001",
  "instruction": "把下载目录的发票整理归档并发邮件给财务小王",
  "stepNo": 3,
  "action": "按供应商/月份归档发票 PDF",
  "targetApp": "文件管理器",
  "verify": "票据/2026-08/ 下生成 6 个 PDF",
  "status": "success",
  "riskLevel": "normal",
  "timestamp": "2026-09-09T14:32:07+08:00",
  "detail": "移动 发票_滴滴出行_0803.pdf 等 6 个文件"
}
```

- `status` 枚举:`success` / `blocked`(人审驳回) / `failed`(执行失败) / `rolled-back`(回滚)。
- `riskLevel` 枚举:`normal` / `high`;**`high` 是触发 requireApproval 弹窗的唯一依据**,由插件代码判定,模型无法自我豁免。
- 字段命名为本链路权威定义,看板与插件共用,禁止各自改名(沿用项目"字段命名与权威源严格一致"红线)。

---

## 第三部分:插件实施(源码工厂 openclaw-guard-suite)

> 以下骨架给出结构与关键决策点;**实现时必须打开 weights-guard / maintenance-records 的现有源码逐行对照**,复用其 A 路模板、类型导入与 failClosed 包装,不要凭本文件重写。

### 3.1 todo-guard(纯指引型)

**目录**:`openclaw-guard-suite/plugins/todo-guard/`,工程文件(tsup.config.ts / package.json / tsconfig.json)整体复制 weights-guard 并改插件 id;`tsup.config.ts` 的 `outDir` 用相对路径指 `../../../ClawX/resources/openclaw-plugins/todo-guard`。

**`src/guidance.ts` — `buildGuidance()` 注入内容四铁律**:

1. **边界铁律**:承接/不承接任务清单(直接嵌入《01-能力说明》第二、三节);边界外任务必须明确拒接并说明原因;信息不完备先追问一轮,补全失败再拒接。
2. **流程铁律**:先输出结构化计划(步骤 + 验收条件 + riskLevel 风险标记)→ 等用户确认 → 再执行;**未获计划确认前禁止任何写操作**。
3. **记录铁律**:每执行一步必须调用 `record_task_step` 登记;高风险步骤在计划中必须标 `riskLevel:'high'`;执行前可调 `read_task_ledger` 查重防重复执行。
4. **异常铁律**:任一步执行失败或验收条件不通过,立即停止后续步骤,向用户报告现场(已完成几步、卡在哪、产生了什么中间产物),等待用户决策,不得自行重试超过一次。

**`src/bundle-entry.ts`**:只导出 `buildPromptInjection` / `buildGuidance`(对照 weights-guard 的 bundle-entry,不带任何遗留拦截逻辑进产物)。

**ClawX 侧薄入口 `resources/openclaw-plugins/todo-guard/index.mjs`**(对照 weights-guard/index.mjs):

```js
// 薄入口只做接线:SDK 由宿主提供,业务逻辑在 handler.bundle.mjs
import { definePluginEntry } from 'openclaw/plugin-sdk/entry';
import { buildPromptInjection } from './handler.bundle.mjs';

export default definePluginEntry({
  register(api) {
    api.registerHook('before_prompt_build', () => {
      try {
        return buildPromptInjection(); // { prependSystemContext }
      } catch {
        return undefined; // 注入失败静默降级,不阻断对话
      }
    });
  },
});
```

### 3.2 task-ledger(工具+人审型)

**目录**:`openclaw-guard-suite/plugins/task-ledger/`,工程文件整体复制 maintenance-records 并改插件 id。

**`src/handler.ts` 关键函数**(对照 maintenance-records/src/handler.ts):

- `RECORD_STEP_PARAMETERS`:纯 JSON Schema 字面量(规避裸模块依赖),必填 `taskId/stepNo/action/targetApp/verify/status/riskLevel`,`instruction/timestamp/detail` 可选。
- `parseToolParams(params)`:校验必填字段与枚举值;不合法返回 null(调用方 fail-closed)。
- `resolveLedgerPath()`:`~/.openclaw/workspace-assistant/执行记录.json`。
- `isRecordTool(toolName)` / `isReadTool(toolName)`:双工具分流判定。
- `handleBeforeToolCall(params)`:
  - 非目标工具 → 快速短路放行;
  - `read_task_ledger` → 直读放行,不人审;
  - `record_task_step` → 返回 `requireApproval` 人审;**`riskLevel:'high'` 时审批载荷升级展示完整上下文**(如邮件草稿全文、收件人、附件),批准即放行该高风险动作本身——人审闸门与执行记录复用同一通道,不新增机制;
  - `onResolution(allow)` → 写入 JSON;写入幂等(同 taskId+stepNo 命中不重复写),读取解析失败回退空列表。
- 任何异常分支 → `{ block: true }`(fail-closed,经 `failClosed(label, run)` 包装器统一兜底)。

**ClawX 侧薄入口 `resources/openclaw-plugins/task-ledger/index.mjs`** 四处接线(对照 maintenance-records/index.mjs):

```js
import { definePluginEntry } from 'openclaw/plugin-sdk/entry';
import {
  RECORD_STEP_PARAMETERS,
  handleBeforeToolCall,
  buildPromptInjection,
  readLedger,          // read_task_ledger 的 execute:直读 JSON 返回
  recordStepFallback,  // record_task_step 的 execute:仅兜底回执,防绕过人审
} from './handler.bundle.mjs';

export default definePluginEntry({
  register(api) {
    // 1) 写工具:承载"登记执行记录"意图,落库在 before_tool_call 的 onResolution
    api.registerTool({
      name: 'record_task_step',
      description: '登记一句话代办任务的单步执行记录(高风险步骤触发人审)',
      parameters: RECORD_STEP_PARAMETERS,
      execute: recordStepFallback,
    });
    // 2) 读工具:无入参、不走人审,供模型查重与看板刷新
    api.registerTool({
      name: 'read_task_ledger',
      description: '读取执行记录台账',
      parameters: { type: 'object', properties: {} },
      execute: readLedger,
    });
    // 3) 指引注入:教模型"先计划、每步一记录、高风险必人审"
    api.registerHook('before_prompt_build', () => {
      try { return buildPromptInjection(); } catch { return undefined; }
    });
    // 4) 拦截器:写工具人审 + fail-closed
    api.registerHook('before_tool_call', (event) => {
      try { return handleBeforeToolCall(event); } catch { return { block: true }; }
    });
  },
});
```

**`openclaw.plugin.json`**(对照 maintenance-records):暴露 `approvalTimeoutMinutes`(默认 5)/ `timeoutBehavior`(默认 `deny`)。

**多插件互斥**:toolName 白名单只认 `record_task_step` / `read_task_ledger`,与既有 `record_po_experience` / `record_maintenance` / `read_maintenance` 互不命中;agent 预置按链路隔离,三个 agent 各自的插件集不交叉。

---

## 第四部分:ClawX 侧三处接线 + 前端看板

### 4.1 三处接线(与既有四插件对称落三处)

1. **`electron/utils/plugin-install.ts`**:`TRUSTED_OFFICIAL_EXTENSION_PLUGINS` 追加 todo-guard / task-ledger 两条,均 `recordSource:'path'`;新增 `ensureTodoGuardPluginInstalled` / `ensureTaskLedgerPluginInstalled`,把插件铺到 `~/.openclaw/extensions/`。
2. **`electron/main/index.ts`**:启动时 fire-and-forget 调这两个 ensure 函数。
3. **`electron/utils/agent-config.ts`**:`ensurePreset` 幂等预置 `PRESET_ASSISTANT`(id `'assistant'`,绑定两插件)。注意既有坑:硬编码长文本模板串内字面反引号须单反斜杠转义。

### 4.2 前端看板 TaskLedgerDashboard(仿 MaintenanceRecordDashboard)

- `src/pages/Chat/index.tsx`:加 `PRESET_ASSISTANT_AGENT_ID='assistant'`,按 `currentAgentId` 条件挂载。
- `src/components/TaskLedgerDashboard.tsx`:`readTextFile` 读 `~/.openclaw/workspace-assistant/执行记录.json`(支持 `~` 展开),解析失败容错回退空列表,刷新按钮联动;按 taskId 分组渲染步骤卡片:步骤号/动作/目标软件/验收条件/状态(success 绿、blocked 红、failed 红、rolled-back 黄)/风险标记(high 红点)/时间戳。

---

## 第五部分:构建、验收与发布

```bash
# 1) 源码工厂:改完逻辑,验收必须全绿
cd openclaw-guard-suite && pnpm typecheck && pnpm test

# 2) 打产物,跨目录写进 ClawX/resources(两个插件各一次)
cd plugins/todo-guard && pnpm bundle
cd ../task-ledger && pnpm bundle

# 3) 提交 ClawX 里更新后的 handler.bundle.mjs(关键!),再打包
cd ../../ClawX && pnpm install && pnpm package
```

**沿用既有红线**:产物是 Git 追踪的,改逻辑必须先 bundle 再提交;blueprint 核对一律去 `node_modules/openclaw/dist/*.d.ts` 实测;git push 须经明确指令且仅限 test 分支。


